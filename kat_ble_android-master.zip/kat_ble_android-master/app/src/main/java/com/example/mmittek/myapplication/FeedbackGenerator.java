package com.example.mmittek.myapplication;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Observable;
import java.util.Observer;


class FeedbackState extends Observable {

    protected KatStaticPosition mActivePosition;
    protected int mFeedbackMode;
    protected float mActivePositionScore;
    protected FeedbackStrength.Strength mFeedbackStrength;


    public FeedbackState() {
        reset(false);
    }

    public void reset() {
        reset(true);
    }

    public void reset(boolean notifyObservers) {
        mActivePosition = null;
        mFeedbackMode = FeedbackMode.FEEDBACK_MODE_OFF.ordinal();
        mActivePositionScore = 0.0f;
        mFeedbackStrength = FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF;

        setChanged();
        if(notifyObservers) notifyObservers();
    }

    public void setActivePosition(KatStaticPosition activePosition) {
        setActivePosition(activePosition, true);
    }

    public void setActivePosition(KatStaticPosition activePosition, boolean notifyObservers) {
        if(activePosition != mActivePosition) {
            mActivePosition = activePosition;
            setChanged();
            if(notifyObservers) notifyObservers();
        }
    }

    public void setFeedbackMode(FeedbackMode feedbackMode) {
        setFeedbackMode(feedbackMode, true);
    }

    public void setFeedbackMode(FeedbackMode feedbackMode, boolean notifyObservers) {
        if( mFeedbackMode != feedbackMode.ordinal() ) {
            mFeedbackMode  = feedbackMode.ordinal();
            setChanged();
            if(notifyObservers) notifyObservers();
        }
    }


    public void setActivePositionScore(float positionScore) {
        setActivePositionScore(positionScore, true);

    }

    public void setActivePositionScore(float positionScore, boolean notifyObservers) {
        if(positionScore != mActivePositionScore) {
            mActivePositionScore = positionScore;
            setChanged();
            if(notifyObservers) notifyObservers();
        }
    }

    public void setFeedbackStrength(FeedbackStrength.Strength feedbackStrength) {
        setFeedbackStrength(feedbackStrength, true);
    }


    public void setFeedbackStrength(FeedbackStrength.Strength feedbackStrength, boolean notifyObservers) {
        if( !feedbackStrength.equals(mFeedbackStrength) ) {
            mFeedbackStrength = feedbackStrength;
            setChanged();
            if(notifyObservers) notifyObservers();
        }

    }

    public final FeedbackStrength.Strength getFeedbackStrength() {
        return mFeedbackStrength;
    }

    public final float getActivePositionScore() {
        return mActivePositionScore;
    }

    public final int getFeedbackMode() {
        return mFeedbackMode;
    }

    public final KatStaticPosition getActivePosition() {
        return mActivePosition;
    }
}

/**
 * Created by mmittek on 9/26/16.
 */
public class FeedbackGenerator extends Observable implements Observer {

    protected boolean mAcousticFeedbackEnabled = false;
    protected boolean mKineticFeedbackEnabled = false;
    protected boolean mLaserDiodesEnabled = false;
    protected int mFeedbackMode = FeedbackMode.FEEDBACK_MODE_OFF.ordinal();
    protected float mGlobalToleranceScale = 1.0f;
    protected int mCurrentlyInPosition = -1;
    protected HashMap<String, Float> mCurrentParamValues;
    protected HashMap<String, Float> mParamsFeedbackScale;
    protected HashMap<String, Boolean> mParamsFeedbackState;
    protected KatDeviceController sKatDeviceController;
    protected KatDevice mKatDevice = null;


    public final int getFeedbackMode() {
        return mFeedbackMode;
    }

    public FeedbackGenerator(KatDevice katDevice) {
        mKatDevice = katDevice;
        mParamsFeedbackScale = new HashMap<String, Float>();
        mParamsFeedbackState = new HashMap<String, Boolean>();
        mCurrentParamValues = new HashMap<String, Float>();
        resetFeedbackSettings();
    }

    public void setAcousticFeedbackEnabled(boolean enabled) {
        if(enabled != mAcousticFeedbackEnabled) {
            mAcousticFeedbackEnabled = enabled;
            setChanged();
            notifyObservers();
        }
    }

    public final boolean isAcousticFeedbackEnabled() {
        return mAcousticFeedbackEnabled;
    }

    public void toggleParamFeedbackState(String paramName) {
        if(!mParamsFeedbackState.containsKey(paramName)) {
            mParamsFeedbackState.put(paramName, false);  // we are toggling!
        } else {
            mParamsFeedbackState.put(paramName, !mParamsFeedbackState.get(paramName));  // toggle
        }
        setChanged();
        notifyObservers();
    }

    public final boolean isParamUsedForFeedback(String paramName) {
        if(!mParamsFeedbackState.containsKey(paramName)) {
            mParamsFeedbackState.put(paramName, false);
        }
        return mParamsFeedbackState.get(paramName);
    }

    public void setKineticFeedbackEnabled(boolean enabled) {
        if(enabled != mKineticFeedbackEnabled) {
            mKineticFeedbackEnabled =enabled;
            setChanged();
            notifyObservers();
        }

    }
/*
    public final FeedbackState getFeedbackState() {
        return mCurrentFeedbackState;
    }
*/
    public final boolean isKineticFeedbackEnabled() {
        return mKineticFeedbackEnabled;
    }

    protected FeedbackGenerator() {
//        DataHub.getInstance().addConsumer(this);
        resetFeedbackSettings();
    }

    public void resetFeedbackSettings() {
        // Active positions
//        activePositions = new HashSet<KatStaticPosition>();

//        for(String paramName : mKatDevice.getKatDataBuffer().getDataParamNames()) {
//            mCurrentParamValues.put( paramName, 0.0f );
//            mParamsFeedbackScale.put( paramName, 1.0f );
//            mParamsFeedbackState.put( paramName, false );
//
//        }

//        // Zero-out the param values
//        mCurrentParamValues = new HashMap<String, Float>();
//        for(String paramName : DataHub.getInstance().getDataParamNames()) {
//            mCurrentParamValues.put( paramName, 0.0f );
//        }
//
//
//        // Reset the scales
//        mParamsFeedbackScale = new HashMap<String, Float>();
//        for(String paramName : DataHub.getInstance().getDataParamNames()) {
//            mParamsFeedbackScale.put( paramName, 1.0f );
//        }
//
//        // Enable all params for feedback by default
//        mParamsFeedbackState = new HashMap<String, Boolean>();
//        for(String paramName : DataHub.getInstance().getDataParamNames()) {
//            mParamsFeedbackState.put( paramName, false );
//        }
        mAcousticFeedbackEnabled = false;
        mKineticFeedbackEnabled = false;
        mFeedbackMode = FeedbackMode.FEEDBACK_MODE_OFF.ordinal();

        setChanged();
        notifyObservers();
    }

    public void setParamToleranceScale(String param, float toleranceScale) {
        mParamsFeedbackScale.put(param, toleranceScale);

        setChanged();
        notifyObservers();
    }

    public final float getParamToleranceScale(String param) {
        Float scale = mParamsFeedbackScale.get(param);
        if(scale == null) {
            scale = 1.0f;
            mParamsFeedbackScale.put(param, scale);
            setChanged();
            notifyObservers();
        }
        return scale;
    }

    public void setGlobalToleranceScale(final Float globalToleranceScale) {
        mGlobalToleranceScale = globalToleranceScale;
        setChanged();
        notifyObservers();
    }


    public void setFeedbackMode(int feedbackMode) {
        mFeedbackMode = feedbackMode;
    }

//    public void consumeData(String name, Object data) {
//        if(name.equals("feedbackMode")) {
//            mFeedbackMode = (int)data;
//          //  Log.d("feedback generator", "feedback mode set to " + data);
//        } else if(name.equals("acousticFeedbackEnabled")) {
//           // Log.d("feedback gen", "acoustic feedback: " + data);
//            mAcousticFeedbackEnabled = (boolean)data;
//            sKatDeviceController.setAcousticFeedbackEnabled(mAcousticFeedbackEnabled);
//        } else if(name.equals("kineticFeedbackEnabled")) {
//            mKineticFeedbackEnabled = (boolean)data;
//            sKatDeviceController.setKineticFeedbackEnabled(mKineticFeedbackEnabled);
//          //  Log.d("feedback gen", "kinetic feedback: " + data);
//        } else if(name.equals("laserDiodesEnabled")) {
//            sKatDeviceController.setLaserDiodesEnabled((boolean)data);
//            mLaserDiodesEnabled = (boolean)data;
//        } else if(name.equals("positionStatus")) {
//            if(data instanceof KatStaticPosition) {
//                KatStaticPosition position = (KatStaticPosition)data;
//                if(position.isOn()) {
//                    activePositions.add(position);
//                } else {
//                    activePositions.remove(position);
//                }
//            }
//        } else if(name.equals("globalToleranceScale")) {
//            mGlobalToleranceScale = (float)data;
//        }
//
//        // Check for value changes for params
//        for(String paramName: DataHub.getDataParamNames()) {
//            if(name.equals(paramName)) {
//                mCurrentParamValues.put(name, (float)data);
//                recalculateFeedback();
//                return;
//            }
//        }
//
//        // Check for feedback changes for params
//        for( String paramName : DataHub.getDataParamNames() ) {
//            String feedbackParamName = paramName + "Enabled";
//            if(name.equals(feedbackParamName)) {
//                mParamsFeedbackState.put( paramName, (boolean)data );
//                return;
//            }
//           // Log.d("feedback generator", paramName + " in feedback: " + mParamsFeedbackState.get(paramName) );
//        }
//
//    }


    public final int getCurrentlyInPosition() {
        return mCurrentlyInPosition;
    }

    private void recalculateFeedback() {

        ArrayList<PositionResponse> positionResponses = new ArrayList<PositionResponse>();

        float normalizedDifferenceSum = 0f;
        ArrayList<Float> normalizedDifferences = new ArrayList<Float>();
        int N = 0;

        KatStaticPosition[] activePositions = mKatDevice.getActivePositions();

        if( (mFeedbackMode == FeedbackMode.FEEDBACK_MODE_OFF.ordinal()) || (activePositions == null) || (activePositions.length == 0))  {
            mKatDevice.setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF);
            return;
        }

        for(KatStaticPosition position: activePositions) {
            Bundle positionStatsBundle = position.getStatistics();
            PositionResponse positionResponse = new PositionResponse();
            positionResponse.Position = position.getID();
            positionResponse.PositionObj = position;

            for(String paramName: mParamsFeedbackState.keySet()) {
                if(mParamsFeedbackState.get(paramName) == false) continue;  // skip the parameter when not considered
                ParameterStats parameterStats = (ParameterStats)positionStatsBundle.getSerializable(paramName+"Stats");
                if(parameterStats == null) continue;

                Float paramScale = mParamsFeedbackScale.get(paramName);


                Double paramMean = parameterStats.getMean();
                Double paramVariance = parameterStats.getVariance();

                if((paramMean.isNaN()) || (paramVariance.isNaN()) || (paramVariance <= 0)) continue;
                Float paramCurrentValue = mCurrentParamValues.get(paramName);
                if(paramCurrentValue == null) continue;

                float normalizedDifference = 0;
                if(parameterStats.isAngle()) {
                    normalizedDifference = (float)Math.abs( Utils.angleDifference((double)paramCurrentValue, paramMean) )/ (float)(  Math.sqrt(paramVariance));
                } else {
                    normalizedDifference = Math.abs( paramCurrentValue - (float)(double)paramMean ) / (float)(  Math.sqrt(paramVariance));      // riddick again!
                }

                normalizedDifference /= paramScale;

                // positionResponse.paramScale = paramScale;
                if( normalizedDifference < positionResponse.minParamResponse ) {
                    positionResponse.minParamResponse = normalizedDifference;
                }
                if( normalizedDifference > positionResponse.maxParamResponse ) {
                    positionResponse.maxParamResponse = normalizedDifference;
                }

                normalizedDifferences.add(normalizedDifference);
                normalizedDifferenceSum += normalizedDifference;
                N++;
            }
            positionResponses.add( positionResponse );
        }


        PositionResponse[] positionResponsesArr = positionResponses.toArray(new PositionResponse[positionResponses.size()]);


        if(mFeedbackMode == FeedbackMode.FEEDBACK_MODE_IN.ordinal()) {
            for(int i=0; i<positionResponsesArr.length; i++) {
                // All params within boundaries for at least one position
                if(positionResponsesArr[i].maxParamResponse <= 3*mGlobalToleranceScale) {
                    mKatDevice.setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_HIGH);
                    mCurrentlyInPosition = positionResponsesArr[i].Position;
                  //  mKatDevice.setOnlyOneStaticPositionActive( positionResponsesArr[i].PositionObj, true, true );
                    return;
                }
            }
            // Return should not let this code to execute
            mKatDevice.setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF);
            mCurrentlyInPosition = -1;
         //   mKatDevice.setAllStaticPositionsActive(false, true);
        } else if(mFeedbackMode == FeedbackMode.FEEDBACK_MODE_OUT.ordinal()) {
          //  mKatDevice.setAllStaticPositionsActive(false, true);
            mCurrentlyInPosition = -1;
            int numOut = 0;
            for(int i=0; i<positionResponsesArr.length; i++) {
                // At least one param of all positions needs to be OUT
                if (positionResponsesArr[i].maxParamResponse > 3*mGlobalToleranceScale ) {
                    numOut++;
                }
            }
            if(numOut == positionResponsesArr.length) {
                mKatDevice.setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_HIGH);
            } else {
                // Return should not let this code to execute
                mKatDevice.setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF);

            }
        } else if(mFeedbackMode == FeedbackMode.FEEDBACK_MODE_OFF.ordinal()) {
                mKatDevice.setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF);
        }
    }


    @Override
    public void update(Observable o, Object arg) {
        if((mFeedbackMode != FeedbackMode.FEEDBACK_MODE_OFF.ordinal()) && ((o instanceof KatDataParam)) ) {
            KatDataParam dataParam = (KatDataParam)o;
            String paramName = dataParam.getName();
            Object value = dataParam.getValue();
            if(value instanceof Float) {
                mCurrentParamValues.put(paramName, (Float) value);
                recalculateFeedback();
            }
        }
    }
}
