package com.example.mmittek.myapplication;

/**
 * Created by mmittek on 7/20/16.
 */
public class Data2D extends Data1D {
    protected float mY;

    public Data2D(long timestamp, float x, float y) {
        super(timestamp, x);
        mY = y;
        mDimensions = 2;
    }

    public Data2D(final byte[] rawBytes) {
        super(rawBytes);
        mDimensions = 2;
        if(rawBytes.length >= 12) {
            mY = getByteArraySliceAsFloat(rawBytes, 8);
        }
    }

    public Data2D(long timestamp, float xy[]) {
        super(timestamp, xy[0]);
        mDimensions = 2;
        mY = xy[1];
    }

    public float[] toArray() {
        float xy[] = { mX, mY };
        return xy;
    }

    public final float getY() {
        return mY;
    }

    public void addY(float y) {
        float newY = mY + y;
        setY(newY);
    }

    public void setY(float newY) {
        if(newY != mY) {
            mY = newY;
            hasChanged();
            notifyObservers();
        }
    }


    @Override
    public String toString() {
        return super.toString() + ", " + mY;
    }

}
