package com.example.mmittek.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.AttributeSet;

public class AccBarPlot extends ParamViewBase {

    protected float mValue;
    protected float mMax;
    protected float mMin;

    public AccBarPlot(Context context) {
        super(context);
        init();
    }

    public void setRange(float min, float max) {
        mMin = min;
        mMax = max;
    }

    public AccBarPlot(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public AccBarPlot(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public AccBarPlot(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    public void setValue(float v) {
        mValue = v;
    }

    @Override
    protected void newDataValue(float value) {
        if(value != mValue) {
            setValue(value);
            invalidate();
        }
    }

    public void init() {
        setRange(-15,15);
        setValue(-1.5f);

    }

    protected float scaleValue(float value, float canvasHeight) {
        return -value / ((mMax-mMin)/(canvasHeight));

    }




    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mPaint.reset();
        float canvasHeight = getHeight();
        float canvasWidth = getWidth();


        mPaint.setTextSize(mTextSize);
        if(mDrawPositions) {
            mPaint.setColor(Color.BLUE);
            canvas.drawText("ON " + Utils.roundFloat(mValue,2) + "", 15, mTextSize*1.1f, mPaint);

        } else {
            mPaint.setColor(Color.GRAY);
            canvas.drawText("OFF " + Utils.roundFloat(mValue,2) + "", 15, mTextSize*1.1f, mPaint);
        }

        if(mDescription != null) {
            canvas.drawText(mDescription, 15, canvasHeight-15, mPaint);
        }


        // outline
        mPaint.setColor(Color.LTGRAY);
        mPaint.setStrokeWidth(5);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(0,0,canvasWidth,canvasHeight, mPaint);


        canvas.translate(0, canvasHeight/2);




        // Positions
        if( (mDrawPositions) && ( myPositions != null ) && (myPositions.size() >0) ) {
//        if( (mDrawPositions) && ( mPositions != null ) && (mPositions.length >0) && (mExpectedStatisticNames != null) && (mExpectedStatisticNames.length > 0)) {
            for(KatStaticPosition position : myPositions) {

                mPaint.setStyle(Paint.Style.FILL);
                mPaint.setColor(position.getColor());
                mPaint.setAlpha(200);

                float positionScale = mGlobalToleranceScale;

                Bundle stats = position.getStatistics();
                if(stats == null) continue;
                    ParameterStats paramStats = (ParameterStats)stats.getSerializable(mParamName + "Stats");

/*
                    Float paramScale = 1.0f;
                    if(mParamFeedbackScales != null) {
                        paramScale = mParamFeedbackScales.get( mParamName );
                    }
                    if(paramScale == null) {
                        paramScale = 1.0f;
                    }
*/

                    float meanScaled = scaleValue( (float)paramStats.getMean() , canvasHeight);
                    float stdevScaled = mParamFeedbackScale*positionScale*scaleValue((float)Math.sqrt(paramStats.getVariance()), canvasHeight  );

                  //  if( mFeedbackMode == FeedbackMode.FEEDBACK_MODE_IN ) {

                        canvas.drawRect(0, meanScaled+3.0f*stdevScaled, canvasWidth, meanScaled-3.0f*stdevScaled,mPaint);
/*
                    } else if( mFeedbackMode == FeedbackMode.FEEDBACK_MODE_OUT ) {
                        canvas.drawRect(0, -canvasHeight/2, canvasWidth,meanScaled+3.0f*stdevScaled , mPaint);
                        canvas.drawRect(0, meanScaled-3.0f*stdevScaled, canvasWidth, canvasHeight/2,mPaint);
                    }
*/
                    mPaint.setColor(position.getColor());
                    mPaint.setStrokeWidth(5);
                    mPaint.setStyle(Paint.Style.STROKE);
                    canvas.drawLine(0, meanScaled, canvasWidth, meanScaled, mPaint);


            }

        }
        // Draw the axis
        mPaint.setColor(Color.BLACK);
        mPaint.setStrokeWidth(5);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawLine(0,0,canvasWidth,0, mPaint);

        // Draw the value
        float scaledValue = scaleValue(mValue, canvasHeight);

        mPaint.setColor(Color.RED);
        mPaint.setStrokeWidth(5);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawLine(0, scaledValue, canvasWidth, scaledValue, mPaint);

    }


}
