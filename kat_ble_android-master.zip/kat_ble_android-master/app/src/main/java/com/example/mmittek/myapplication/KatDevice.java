package com.example.mmittek.myapplication;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.os.Handler;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.UUID;

/**
 * Created by mmittek on 3/6/2017.
 */

public class KatDevice extends Observable  {

    protected BluetoothGatt mBluetoothGatt = null;
    private BluetoothGattCallback mBluetoothGattCallback = null;
    private BluetoothDevice mBluetoothDevice = null;
    private Context mContext = null;
    private boolean isConnected = false;
    private KatTracker mTracker = null;
    private Handler mHandler = null;
    private boolean mHandlingNotifications = false;
    private boolean mKineticFeedbackEnabled = false;
    private FeedbackStrength.Strength mPreviousFeedbackStrength = FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF;
    private boolean mAcousticFeedbackEnabled = false;
    private FeedbackGenerator mFeedbackGenerator;
    private KatDataBuffer mKatDataBuffer;
//    private HashMap<Integer, KatStaticPosition> mStaticPositions;
    private ArrayList<KatStaticPosition> mStaticPositions;

    public KatDevice(Context context, BluetoothDevice bluetoothDevice) {
        mContext = context;
        mBluetoothDevice = bluetoothDevice;
        mBluetoothGattCallback = initializeGattBluetoothCallback();
        mHandler = initializeMessageHandler();
        mTracker = new KatTracker(mHandler, bluetoothDevice.getAddress());
        mFeedbackGenerator = new FeedbackGenerator(this);

        mKatDataBuffer = new KatDataBuffer(this);
        mStaticPositions = new ArrayList<KatStaticPosition>();
        mStaticPositions.add(new KatStaticPosition(this, 0));
        mStaticPositions.add(new KatStaticPosition(this, 1));
        mStaticPositions.add(new KatStaticPosition(this, 2));



        mKatDataBuffer.subscribeObserverToAllDataParams(mFeedbackGenerator);
    }


    public final KatTracker getTracker() {
        return mTracker;
    }

    public final KatStaticPosition getPosition(Integer i) {
        if(i<mStaticPositions.size()) {
            return mStaticPositions.get(i);
        }
        return null;
    }

    public void subsribeObserverToAllPositions(Observer observer) {
        for(KatStaticPosition position : mStaticPositions) {
            position.addObserver(observer);
        }
    }

    public final KatStaticPosition[] getAllPositions() {
        return mStaticPositions.toArray(new KatStaticPosition[mStaticPositions.size()]);
    }

    public void resetAllPositions() {
        for(KatStaticPosition position : mStaticPositions) {
            position.reset();
        }
    }

    public void setScaleToAllPositions(Double scale) {
        for(KatStaticPosition position : mStaticPositions) {
            position.setScale(scale);
        }
    }

    public KatStaticPosition[] getActivePositions() {
        ArrayList<KatStaticPosition> activePositions = new ArrayList<KatStaticPosition>();
        for(KatStaticPosition position : mStaticPositions) {
            if(position.isActive()) {
                activePositions.add(position);
            }
        }
        return activePositions.toArray(new KatStaticPosition[activePositions.size()]);
    }

    public void stopRecordingOnAllStaticPositions() {
        // Turn off recording for all positions
        for(KatStaticPosition position : mStaticPositions) {
            position.stopRecording(false);
        }
    }

    public void setOnlyOneStaticPositionActive( KatStaticPosition activeOne, boolean active, boolean notifyObservers ) {
        for(KatStaticPosition position :mStaticPositions) {
            if(position == activeOne) {
                position.setActive(active, notifyObservers);
            } else {
                position.setActive(!active, notifyObservers);
            }
        }
    }

    public void setAllStaticPositionsActive(boolean active, boolean notifyObservers) {
        for(KatStaticPosition position : mStaticPositions) {
            position.setActive(active, notifyObservers);
        }
    }

    public final KatDataBuffer getKatDataBuffer(){
        return mKatDataBuffer;
    }

    public final FeedbackGenerator getFeedbackGenerator() {
        return mFeedbackGenerator;
    }

    public final String getMAC() {
        return mBluetoothDevice.getAddress();
    }

    public boolean connect() {
        if((mBluetoothGatt = mBluetoothDevice.connectGatt(mContext, true, mBluetoothGattCallback)) == null) {
            return false;
        }

        synchronized (mBluetoothGatt) {
            if (mBluetoothGatt.connect() == false) {
                return false;
            }
        }

        Log.d(getClass().getName(), "Connected to device with MAC: " + mBluetoothDevice.getAddress());

        KatDevices.getInstance().addConnectedKatDevice(this);
        return true;
    }

    public void disconnect() {
        KatDevices.getInstance().removeConnectedKatDevice(this);
    }


    private void enableNotificationsForCharacteristics(final BluetoothGatt gatt, final BluetoothGattService gattService, final UUID[] characteristicUUIDs, final boolean enable) {

        new Thread(new Runnable(){
            @Override
            public void run() {
                BluetoothGattCharacteristic characteristic;
                BluetoothGattDescriptor descriptor = null;
                UUID uuid;
                for(int i=0; i<characteristicUUIDs.length; i++) {
                    uuid = characteristicUUIDs[i];
                    characteristic = gattService.getCharacteristic( uuid );
                    if(characteristic == null)  continue;
                    descriptor = characteristic.getDescriptor(KatUUIDS.CHARACTERISTIC_CONFIG_DESRIPTOR);

                    synchronized(gatt) {
                        if (gatt.setCharacteristicNotification(characteristic, enable) == false)
                            continue;
                    }

                    if (descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)) {
                        synchronized(descriptor) {

                            synchronized (gatt) {
                                gatt.writeDescriptor(descriptor);
                            }

                            try {
                                descriptor.wait();
                            }catch(InterruptedException e) {

                            }
                        }

                    }
                    Thread.yield();
                }
            }
        }).start();
    }

    private Handler initializeMessageHandler() {
        return new Handler() {
            public void handleMessage(Message m) {
                // Seek bar handling
                if(m.what == KatMessageType.KAT_MESSAGE_TYPE_GLOBAL_SCALE_CHANGED.ordinal()) {
                    Bundle b = m.getData();
                    Double scale = ((double) b.getInt("Scale")) / 10.0;
//                    KatStaticPosition.setScaleToAllPositions(scale);
                    setScaleToAllPositions(scale);
                    mTracker.setScale((float) (double) scale);
                } else if(m.what == KatMessageType.KAT_MESSAGE_TYPE_CHANGE_PARAM_FEEDBACK.ordinal()) {
                    if(mTracker == null) return;
                    Bundle b = m.getData();
                    if(b == null) return;
                    boolean include = b.getBoolean("Included");

                    String[] paramNames = b.getStringArray("ParamNames");
                    if((paramNames == null) || (paramNames.length == 0)) return;
                    for(int i=0; i<paramNames.length; i++) {
                        mTracker.useFeedbackForParam( paramNames[i], include );
                    }

                } else if(m.what == KatMessageType.KAT_MESSAGE_TYPE_SET_FEEDBACK_STRENGTH.ordinal()) {
                    Bundle b = m.getData();
                    FeedbackStrength.Strength strength = (FeedbackStrength.Strength)b.getSerializable("FeedbackStrength");
                    if(strength == null) return;
                    byte[] value = FeedbackStrength.FeedbackStrengthToRawDataArr(strength);

                    ArrayList<UUID> writeToFeedbackCharacteristics = new ArrayList<UUID>();
                    if(mAcousticFeedbackEnabled) {
                        writeToFeedbackCharacteristics.add(KatUUIDS.CHARACTERISTIC_BUZZ_UUID);
                    }

                    if(mKineticFeedbackEnabled) {
                        writeToFeedbackCharacteristics.add(KatUUIDS.CHARACTERISTIC_VIBR_UUID);
                    }
                    setCharacteristicsValue( writeToFeedbackCharacteristics.toArray(new UUID[writeToFeedbackCharacteristics.size()]), value);
                }
                if(m.what == KatMessageType.KAT_MESSAGE_TYPE_NEW_ACCELEROMETER_DATA.ordinal()) {
                    Bundle b = m.getData();
                    float xyz[] = b.getFloatArray("data");
//                    DataHub.getInstance().dataProduced(this, "accelX", (xyz[0]) );
//                    DataHub.getInstance().dataProduced(this, "accelY", (xyz[1]) );
//                    DataHub.getInstance().dataProduced(this, "accelZ", (xyz[2]) );


                    // New, good way of doing things
                    mKatDataBuffer.getAccelX().setValue( (xyz[0]) );
                    mKatDataBuffer.getAccelY().setValue( (xyz[1]) );
                    mKatDataBuffer.getAccelZ().setValue( (xyz[2]) );

                } else if(m.what == KatMessageType.KAT_MESSAGE_TYPE_MAGNETOMETER_DATA.ordinal()) {
                    //Bundle b = m.getData();
                    //Plot2D plot2d = (Plot2D)findViewById(R.id.magnetometerPlot);
                    //plot2d.plotData(new float[]{0,1,2}, b.getFloatArray("data"), 2);
                } else if(m.what == KatMessageType.KAT_MESSAGE_TYPE_SONARS_DATA.ordinal()) {
                    Bundle b = m.getData();
                    float xy[] = b.getFloatArray("data");
//                    DataHub.getInstance().dataProduced(this, "distanceX", (xy[0]));
//                    DataHub.getInstance().dataProduced(this, "distanceY", (xy[1]));

                    // new good way of doing things
                    mKatDataBuffer.getDistanceX().setValue( xy[0] );
                    mKatDataBuffer.getDistanceY().setValue( xy[1] );
                } else if(m.what == KatMessageType.KAT_MESSAGE_TYPE_ORIENTATION_DATA.ordinal()) {
                    Bundle b = m.getData();
                    float xyz[] = b.getFloatArray("data");

//                    xyz[2] += 180;

//                    DataHub.getInstance().dataProduced(this, "angleX", (xyz[0]) );
//                    DataHub.getInstance().dataProduced(this, "angleY", (xyz[1]) );
//                    DataHub.getInstance().dataProduced(this, "angleZ", (xyz[2]) );

                    // new way of doing things
                    mKatDataBuffer.getAngleX().setValue(  (xyz[0]) );
                    mKatDataBuffer.getAngleY().setValue(  (xyz[1]) );
                    mKatDataBuffer.getAngleZ().setValue(  (xyz[2]) );
                } else if(m.what == KatMessageType.KAT_MESSAGE_TYPE_EMG_DATA.ordinal()) {
                    Bundle b = m.getData();
                    float x[] = b.getFloatArray("data");

//                    DataHub.getInstance().dataProduced(this, "emg", (x[0]) );

                    mKatDataBuffer.getEMG().setValue(  (x[0]) );

                }
            }
        };
    }


    public synchronized void setKineticFeedbackEnabled(boolean enabled) {
        mKineticFeedbackEnabled = enabled;
        if(!enabled) {
            setCharacteristicsValue(new UUID[]{KatUUIDS.CHARACTERISTIC_VIBR_UUID}, new byte[] {(byte)0});
        }
    }


    public synchronized void setLaserDiodesEnabled(boolean enabled) {
        if(enabled) {
            setCharacteristicsValue(new UUID[]{KatUUIDS.CHARACTERISTIC_LASX_UUID,KatUUIDS.CHARACTERISTIC_LASY_UUID},new byte[] {(byte)255} );
        } else {
            setCharacteristicsValue(new UUID[]{KatUUIDS.CHARACTERISTIC_LASX_UUID,KatUUIDS.CHARACTERISTIC_LASY_UUID},new byte[] {(byte)0} );
        }
    }

    public synchronized void setAcousticFeedbackEnabled(boolean enabled) {
        mAcousticFeedbackEnabled = enabled;
        if(!enabled) {
            setCharacteristicsValue(new UUID[]{KatUUIDS.CHARACTERISTIC_BUZZ_UUID}, new byte[] {(byte)0});
        }
    }

    public synchronized void setFeedbackStrength(FeedbackStrength.Strength strength) {

        if(strength == mPreviousFeedbackStrength) return;

        // Deal with it later :)
        byte[] value = FeedbackStrength.FeedbackStrengthToRawDataArr(strength);
        ArrayList<UUID> writeToFeedbackCharacteristics = new ArrayList<UUID>();

        //  writeToFeedbackCharacteristics.add(KatUUIDS.CHARACTERISTIC_LASX_UUID);
        //  writeToFeedbackCharacteristics.add(KatUUIDS.CHARACTERISTIC_LASY_UUID);

        if(mAcousticFeedbackEnabled) {
            writeToFeedbackCharacteristics.add(KatUUIDS.CHARACTERISTIC_BUZZ_UUID);
        }
        if(mKineticFeedbackEnabled) {
            writeToFeedbackCharacteristics.add(KatUUIDS.CHARACTERISTIC_VIBR_UUID);
        }


        setCharacteristicsValue( writeToFeedbackCharacteristics.toArray(new UUID[writeToFeedbackCharacteristics.size()]), value);
        mPreviousFeedbackStrength = strength;

    }

    protected void setCharacteristicsValue(final UUID characteristicUUIDs[], final byte[] value) {
        final BluetoothGatt gatt = mBluetoothGatt;
        if(gatt == null) return;

        new Thread(new Runnable(){
            @Override
            public void run() {
                BluetoothGattCharacteristic characteristic;
                for(int i=0; i<characteristicUUIDs.length; i++) {
                    characteristic = gatt.getService(KatUUIDS.KAT_SERVICE_UUID).getCharacteristic(characteristicUUIDs[i]);
                    synchronized (characteristic) {
                        characteristic.setValue(value);

                        synchronized(gatt) {
                            gatt.writeCharacteristic(characteristic);
                        }
                        try {
                            characteristic.wait();
                        } catch (InterruptedException e) {
                            return;
                        }
                    }
                    // Let other threads do their thing
                    Thread.yield();
                }
            }
        }).start();
    }


    private BluetoothGattCallback initializeGattBluetoothCallback() {
        return new BluetoothGattCallback(){

            @Override
            public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
                if(status != BluetoothGatt.GATT_SUCCESS) {
                    return;
                }
                synchronized (characteristic) {
                    characteristic.notifyAll();
                }
            }

            @Override
            public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
                if(status != BluetoothGatt.GATT_SUCCESS) {
                    return;
                }
                synchronized (characteristic) {
                    characteristic.notifyAll();
                }
            }

            @Override
            public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
                if(status != BluetoothGatt.GATT_SUCCESS) {
                    return;
                }
                synchronized(descriptor) {
                    descriptor.notifyAll();
                }
            }


            @Override
            public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {

                if(!mHandlingNotifications) return;

                UUID charUUID = characteristic.getUuid();
                String MAC = gatt.getDevice().getAddress();
                DataBase data = null;
                if(mTracker == null) return;

                if(charUUID.equals(KatUUIDS.CHARACTERISTIC_ACC_UUID)) {
                    mTracker.addAccelerometerData( characteristic.getValue() );
                } else if(charUUID.equals(KatUUIDS.CHARACTERISTIC_ORIENTATION_UUID)) {
                    mTracker.addOrientationData( characteristic.getValue() );

                } else if(charUUID.equals(KatUUIDS.CHARACTERISTIC_SONARS_UUID)) {
                    mTracker.addSonarsData( characteristic.getValue() );
                } else if(charUUID.equals(KatUUIDS.CHARACTERISTIC_EMG_UUID)) {
                    mTracker.addEMGData( characteristic.getValue() );
                }

            }


            @Override
            public void onServicesDiscovered(final BluetoothGatt gatt, int status) {
                String MAC = gatt.getDevice().getAddress();

                if(status != BluetoothGatt.GATT_SUCCESS) {
                    return;
                }

                // Let's connect to the service
                final BluetoothGattService katService = gatt.getService(KatUUIDS.KAT_SERVICE_UUID);
                if(katService == null) return;

                final BluetoothGattService basService = gatt.getService(KatUUIDS.BAS_SERVICE_UUID);


//                // Get the service
//                synchronized (mConnectedDevices) {
//                    mConnectedServices.put(MAC, katService);
//                }
//
//
//
//
                enableNotificationsForCharacteristics(gatt, katService, new UUID[]{
                        KatUUIDS.CHARACTERISTIC_ACC_UUID,
                        KatUUIDS.CHARACTERISTIC_SONARS_UUID,
                        KatUUIDS.CHARACTERISTIC_ORIENTATION_UUID,
                        KatUUIDS.CHARACTERISTIC_EMG_UUID,
                }, true);

                if(basService != null) {
                    enableNotificationsForCharacteristics(gatt, basService, new UUID[]{
                            KatUUIDS.CHARACTERISTIC_BATTERY_LEVEL_UUID,
                    }, true);
                }
//
                mHandlingNotifications = true;

            }




            @Override
            public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
                if(status != BluetoothGatt.GATT_SUCCESS) {
                    return;
                }
                String mMAC = gatt.getDevice().getAddress();

                if(newState == BluetoothGatt.STATE_CONNECTED) {
                    if(!gatt.discoverServices()) {
                        return;
                    }
                    // mConnectedDevices.put(mMAC, gatt);
                    // sendDeviceConnectedMessage(mMAC);
                   // onBluetoothDeviceConnected(gatt);
                    Log.i("main", "Connected!");

                } else if(newState == BluetoothGatt.STATE_DISCONNECTED) {
                //    onBluetoothDeviceDisconnected(gatt);
                    Log.d("main", "Disconnected");
                }

                setChanged();
                notifyObservers();
            }
        };
    }

}
