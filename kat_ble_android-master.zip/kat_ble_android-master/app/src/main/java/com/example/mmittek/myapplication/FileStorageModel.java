package com.example.mmittek.myapplication;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;

public class FileStorageModel extends Storage {
    protected String mFileName;
    protected File mFile;

    protected FileOutputStream mOutputStream;

    public FileStorageModel(Context context, String filename) {
        super(context);
        mFileName = filename;
        mFile = new File(mContext.getFilesDir(), mFileName);

    }

    public FileStorageModel(Context context) {
        super(context);
        // http://stackoverflow.com/questions/5369682/get-current-time-and-date-on-android
        mFileName = getDefaultFileName();
        mFile = new File(mContext.getFilesDir(), mFileName);
    }

    public final String getFileName() {
        return  mFileName;
    }

    public final File getFile() {
        return mFile;
    }

    protected static String getDefaultFileName(String postfix) {
        String defaultFileName;
        Calendar calendar = Calendar.getInstance();
        if(postfix == null || postfix.length() == 0) {
            defaultFileName = Utils.getCurrentTimestampString() + ".csv";
        } else {
            defaultFileName = Utils.getCurrentTimestampString() + "_" +  postfix +  ".csv";

        }
        return defaultFileName;
    }


    protected static String getDefaultFileName() {
        return getDefaultFileName(null);
    }

    @Override
    public boolean open() {
        Log.d("file storage", "opening file " + mFileName);
        if(mFile == null) {
            return false;
        }

        try {
            if (!mFile.createNewFile()  || !mFile.canWrite()) {
                return false;
            }
            mOutputStream = new FileOutputStream(mFile);

        } catch(IOException e) {
            return false;
        }

//        File file = new File(context.getFilesDir(), filename);

        return true;
    }

    public final OutputStream getOutputStream() {
        return mOutputStream;
    }

    @Override
    public void close() {
        Log.d("file storage", "closing file " +mFileName );

        try {
            mOutputStream.flush();
            mOutputStream.close();
            mFile = null;
        }catch(IOException e) {

        }
    }

    public double getFileSize(String filename) {
        File f = new File( mContext.getFilesDir(), filename );
        return f.length();
    }

    public static File writeToExternal(Context context, String filename){
        try {
            File file = new File(context.getExternalFilesDir(null), filename); //Get file location from external source
            InputStream is = new FileInputStream(context.getFilesDir() + File.separator + filename); //get file location from internal
            OutputStream os = new FileOutputStream(file); //Open your OutputStream and pass in the file you want to write to
            byte[] toWrite = new byte[is.available()]; //Init a byte array for handing data transfer
            Log.i("Available ", is.available() + "");
            int result = is.read(toWrite); //Read the data from the byte array
            Log.i("Result", result + "");
            os.write(toWrite); //Write it to the output stream
            is.close(); //Close it
            os.close(); //Close it
            Log.i("Copying to", "" + context.getExternalFilesDir(null) + File.separator + filename);
            Log.i("Copying from", context.getFilesDir() + File.separator + filename + "");
            return file;
        } catch (Exception e) {
            Toast.makeText(context, "File write failed: " + e.getLocalizedMessage(), Toast.LENGTH_LONG).show(); //if there's an error, make a piece of toast and serve it up
        }
        return null;
    }

}