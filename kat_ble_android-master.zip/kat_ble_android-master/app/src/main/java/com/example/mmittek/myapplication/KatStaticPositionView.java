package com.example.mmittek.myapplication;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.Observable;
import java.util.Observer;

public class KatStaticPositionView extends LinearLayout implements View.OnClickListener, Observer {

    protected TextView              mPositionLabelTextView;
    protected ToggleButton          mRecordingToggleButton;
    protected ToggleButton          mPositionActiveToggleButton;
    protected CheckBox              mDataPresentCheckBox;
    protected KatStaticPosition     mKatStaticPosition              = null;
    protected Thread                mBlinkinThread                  = null;
    protected boolean               mBlinking                       = false;
    protected boolean               mBlinkingThreadRunning          = false;
    protected Handler               mMessageHandler;



    public KatStaticPositionView(Context context) {
        super(context);
        init();
    }

    public KatStaticPositionView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public KatStaticPositionView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public KatStaticPositionView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    public void assignPosition(KatStaticPosition position) {
        mKatStaticPosition = position;
        mKatStaticPosition.addObserver(this);

        ViewGroup vg = (ViewGroup)this;
        vg.removeAllViews();


        mPositionLabelTextView = new TextView(getContext());
        mPositionLabelTextView.setText("Position ");
        vg.addView( mPositionLabelTextView );


        mRecordingToggleButton = new ToggleButton(getContext());
        mRecordingToggleButton.setTextOn("Stop");
        mRecordingToggleButton.setTextOff("Record");
        mRecordingToggleButton.setText("Record");
        mRecordingToggleButton.setOnClickListener(this);
        vg.addView(mRecordingToggleButton);

        mPositionActiveToggleButton = new ToggleButton(getContext());
        mPositionActiveToggleButton.setTextOn("Active");
        mPositionActiveToggleButton.setTextOff("Inactive");
        mPositionActiveToggleButton.setText("Inactive");
        mPositionActiveToggleButton.setOnClickListener(this);
        vg.addView( mPositionActiveToggleButton );

        mDataPresentCheckBox = new CheckBox(getContext());
        mDataPresentCheckBox.setChecked( mKatStaticPosition.hasData() );
        mDataPresentCheckBox.setEnabled(false);
        vg.addView(mDataPresentCheckBox);

        // We are only going to get messages from one thread so we will just look at "what"
        mMessageHandler = new Handler(Looper.getMainLooper()){
            public void handleMessage(Message m) {
//                Log.d("position view", "got message!");
                if(m.what == 0) {
                    setPositionLabelTextColor(Color.BLACK);
                } else {
                    setPositionLabelTextColor(Color.RED);
                }
            }
        };

        final Handler handlerInstance = mMessageHandler;

        final KatStaticPositionView positionViewInstance = this;
        mBlinkinThread = new Thread(new Runnable(){
            public void run() {
                boolean blinkState = false;
                while(positionViewInstance.mBlinkingThreadRunning) {
                    if( positionViewInstance.mBlinking ) {
                        blinkState = !blinkState;
                        if(blinkState) {
                            handlerInstance.sendEmptyMessage(1);
                        } else {
                            handlerInstance.sendEmptyMessage(0);
                        }
                    } else {
                        handlerInstance.sendEmptyMessage(0);
                    }
                    try {
                        Thread.sleep(100);
                    }catch(InterruptedException e) {
                        break;
                    }
                }
            }
        });
        mBlinkingThreadRunning =true;
        mBlinkinThread.start();
        invalidate();
    }

    public final KatStaticPosition getPosition() {
        return mKatStaticPosition;
    }

    protected void init() {
        //DataHub.getInstance().addConsumer(this);
    }


    public void consumeData(String name, Object data) {
    }

    public void setPositionLabelTextColor(int c) {
        mPositionLabelTextView.setTextColor( c );
    }

    @Override
    public void onClick(View view) {

        if(mKatStaticPosition == null) return;

        if(view ==mRecordingToggleButton ) {
            mKatStaticPosition.setRecording( mRecordingToggleButton.isChecked() );
        }


        if(view == mPositionActiveToggleButton) {
            if(!mKatStaticPosition.hasData()) {
                mPositionActiveToggleButton.setChecked(false);
                return;
            }
            mKatStaticPosition.setOn( mPositionActiveToggleButton.isChecked() );
            //DataHub.getInstance().dataProduced( this, "positionStatus", mKatStaticPosition );
        }

        // Update everything
        mDataPresentCheckBox.setChecked( mKatStaticPosition.hasData() );


        invalidate();
    }

    protected void setBlinking(boolean blinking) {
        mBlinking = blinking;

        if(!blinking) {
            mPositionLabelTextView.setTextColor(Color.BLACK);
        }
    }

    protected void updateFromPosition(KatStaticPosition position) {
        mDataPresentCheckBox.setChecked( position.hasData() );
        mPositionActiveToggleButton.setChecked( position.isOn() );
        mRecordingToggleButton.setChecked( position.isRecording() );
        // Check if the position is active or not
        setBlinking( position.isActive() );
        invalidate();
    }

    @Override
    public void update(Observable observable, Object o) {
        if( observable instanceof KatStaticPosition ) {
            updateFromPosition(  (KatStaticPosition)observable);
        }
    }
}
