package com.example.mmittek.myapplication;

import java.io.Serializable;
import java.util.Observable;

public class DataParamViewModel extends Observable implements Serializable {
    protected DataBase mModel;
    protected String mName;
    protected Double mToleranceScale = 1.0;
    protected Boolean mEnabledInFeedback = true;

    public DataParamViewModel(String name,DataBase model) {
        mName = name;
        mModel = model;
    }
}
