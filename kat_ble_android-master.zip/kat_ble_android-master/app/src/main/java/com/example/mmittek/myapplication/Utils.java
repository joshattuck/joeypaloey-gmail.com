package com.example.mmittek.myapplication;


import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.util.Calendar;

/**
 * This is a generic class having a bunch of static methods used along the app
 */
public class Utils {

    public static String bytesToHex(byte[] in) {
        final StringBuilder builder = new StringBuilder();
        for(byte b : in) {
            builder.append(String.format("%02x ", b));
        }
        return builder.toString();
    }

    // Stolen from http://stackoverflow.com/questions/1158909/average-of-two-angles-with-wrap-around
    public static double angleDifference(double a, double b) {

        double result = a-b;
        if(result > 180) result-=360;
        if(result < -180) result+=360;
        //Log.d("angle", "a " + a + ", b " + b + ", diff " + result);
        return result;
    }

    public static double[] toPrimitive(Double[] in) {
        double[] out = new double[in.length];
        for(int i=0; i<in.length; i++) {
            out[i] = in[i];
        }
        return out;
    }


    public static double angleVariance(double[] values) {
        if(values.length == 0) return 0;
        double N = values.length;
        double avg = Utils.averageAngle(values);
        double sum = 0;
        double angleDiff = 0;

        double[] angleDiffValues = new double[ values.length ];

        for (int i=0; i<N; i++) {
            angleDiff = Utils.angleDifference( avg, values[i] );
            angleDiffValues[i] = angleDiff;
            sum += Math.pow(angleDiff,2);
        }
        return sum / (N*N);
    }

    public static double averageAngle(double[] values) {
        double sumSin = 0;
        double sumCos = 0;
        if(values.length == 0) return 0;
        for(int i=0; i<values.length; i++) {
            sumSin += Math.sin( Math.PI*values[i]/180 );
            sumCos += Math.cos( Math.PI*values[i]/180 );
        }
        return (360 + 180*Math.atan2( sumSin,sumCos  )/Math.PI) % 360.0f;
    }

    // From http://stackoverflow.com/questions/8911356/whats-the-best-practice-to-round-a-float-to-2-decimals
    public static float roundFloat(float d, int decimalPlace) {
        return BigDecimal.valueOf(d).setScale(decimalPlace,BigDecimal.ROUND_HALF_UP).floatValue();
    }

    public static String getCurrentTimestampString() {
        Calendar calendar = Calendar.getInstance();

        String timestampString = "" + calendar.get(Calendar.YEAR) + "-" +
                String.format("%02d", (calendar.get(Calendar.MONTH))+1) + "-" +
                String.format("%02d", calendar.get(Calendar.DAY_OF_MONTH)) + " " +
                String.format("%02d", calendar.get(Calendar.HOUR_OF_DAY)) + ":" +
                String.format("%02d", calendar.get(Calendar.MINUTE)) + ":" +
                String.format("%02d", calendar.get(Calendar.SECOND)) + ":"  +
                String.format("%03d", calendar.get(Calendar.MILLISECOND));
        return timestampString;
    }

    // Got from http://stackoverflow.com/questions/80476/how-can-i-concatenate-two-arrays-in-java
    public static <T> T[] concatenateArrays (T[] a, T[] b) {
        int aLen = a.length;
        int bLen = b.length;

        @SuppressWarnings("unchecked")
        T[] c = (T[]) Array.newInstance(a.getClass().getComponentType(), aLen+bLen);
        System.arraycopy(a, 0, c, 0, aLen);
        System.arraycopy(b, 0, c, aLen, bLen);

        return c;
    }

}