package com.example.mmittek.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.ToggleButton;

public class TriStateToggleButton extends ToggleButton  {

    private String mStates[] = {"Off", "In", "Out"};
    private int mState = 0;

    public TriStateToggleButton(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    public TriStateToggleButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public TriStateToggleButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public TriStateToggleButton(Context context) {
        super(context);
        init();
    }

    public void init() {

    }

    public void advanceState() {
        mState = (mState+1)%3;
        invalidate();
    }

    public final String getStateName() {
        return mStates[mState];
    }

    public final int getState() {
        return mState;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if( mState > 0 ) {
            setChecked(true);

        } else {
            setChecked(false);
        }
        setText(mStates[mState]);
        super.onDraw(canvas);
    }
}
