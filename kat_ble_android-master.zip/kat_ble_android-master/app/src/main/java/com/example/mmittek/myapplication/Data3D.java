package com.example.mmittek.myapplication;

/**
 * Created by mmittek on 7/20/16.
 */
public class Data3D extends Data2D {

    protected float mZ;

    public Data3D() {
        super(0,0,0);
        mZ = 0;
        mDimensions = 3;
    }

    public Data3D(long timestamp, float x, float y, float z) {
        super(timestamp, x,y);
        mDimensions = 3;
        mZ = z;
    }

    public Data3D(final byte[] rawBytes) {
        super(rawBytes);
        mDimensions = 3;
        if(rawBytes.length >= 16) {
            mZ = getByteArraySliceAsFloat(rawBytes, 12);
        }
    }

    public Data3D(long timestamp, float xyz[]) {
        super(timestamp, xyz[0], xyz[1]);
        mDimensions = 3;
        mZ = xyz[2];
    }

    public float[] toArray() {
        float xyz[] = { mX, mY, mZ };
        return xyz;
    }

    public final float getZ() {
        return mZ;
    }

    public void addZ(float z) {
        float newZ = mZ + z;
        setZ(newZ);
    }

    public void setZ(float newZ) {
        if(newZ != mZ) {
            mZ = newZ;
            hasChanged();
            notifyObservers();

        }
    }


    @Override
    public String toString() {
        return super.toString() + ", " + mZ;
    }
}
