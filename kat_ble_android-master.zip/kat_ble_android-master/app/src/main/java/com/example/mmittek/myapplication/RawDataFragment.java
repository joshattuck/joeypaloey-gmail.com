package com.example.mmittek.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;

class RawDataDevicesListAdapter extends BaseAdapter implements Observer {

    private ArrayList<KatDevice> mKatDevicesCollection;
    private int mLayoutElement;
    private Context mContext;

    public RawDataDevicesListAdapter(Context context, int layoutElement) {
        mContext = context;
        mLayoutElement = layoutElement;
        mKatDevicesCollection = new ArrayList<KatDevice>();
    }

    public void clear() {
        mKatDevicesCollection.clear();
        notifyDataSetChanged();
    }

    public void add(KatDevice device) {
        mKatDevicesCollection.add(device);

        device.getKatDataBuffer().addObserver(this);

        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return mKatDevicesCollection.size();
    }

    @Override
    public Object getItem(int i) {
        if(i<mKatDevicesCollection.size()) {
            return mKatDevicesCollection.get(i);
        }
        return null;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        final View result;
        if (convertView == null) {
            result = LayoutInflater.from(parent.getContext()).inflate(mLayoutElement, parent, false);
        } else {
            result = convertView;
        }

        KatDevice katDevice = (KatDevice) getItem(i);

        // Set the device's MAC
        TextView deviceMacTextView = (TextView) result.findViewById(R.id.device_mac);
        deviceMacTextView.setText( "Device: " + katDevice.getMAC() );


        // Construct acceleration vector and set the appropriate textview
        TextView accelVectorTextView = (TextView) result.findViewById(R.id.raw_data_list_item_acceleration_vector);
        String accelVector = String.format("Accel: %.2f, %.2f, %.2f",
                katDevice.getKatDataBuffer().getAccelX().getValue(),
                katDevice.getKatDataBuffer().getAccelY().getValue(),
                katDevice.getKatDataBuffer().getAccelZ().getValue());
        accelVectorTextView.setText(accelVector);


        // Construct the orientation vector and set appropriate textview
        TextView orientationVectorTextView = (TextView) result.findViewById(R.id.raw_data_list_item_orientation_vector);
        String orientationVector = String.format("Orient: %.2f, %.2f, %.2f",
                katDevice.getKatDataBuffer().getAngleX().getValue(),
                katDevice.getKatDataBuffer().getAngleY().getValue(),
                katDevice.getKatDataBuffer().getAngleZ().getValue());
        orientationVectorTextView.setText( orientationVector );

        TextView distanceVectorTextView = (TextView) result.findViewById(R.id.raw_data_list_item_distance_vector);
        String distanceVector = String.format("Distance: %.2f, %.2f",
                katDevice.getKatDataBuffer().getDistanceX().getValue() ,
                katDevice.getKatDataBuffer().getDistanceY().getValue() );
        distanceVectorTextView.setText(distanceVector);

        return result;
    }

    @Override
    public void update(Observable o, Object arg) {
        notifyDataSetChanged();
    }
}


/**
 * Created by mmittek on 9/22/16.
 */
public class RawDataFragment extends Fragment implements Observer  {

    RawDataDevicesListAdapter mRawDataDevicesListAdapter;

    public RawDataFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setRetainInstance(true);

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_raw_data, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        mRawDataDevicesListAdapter = new RawDataDevicesListAdapter(view.getContext(), R.layout.raw_data_devices_list_item);
        KatDevices.getInstance().addObserver(this);
        ListView lv = (ListView)view.findViewById(R.id.raw_data_devices_list);
        lv.setAdapter(mRawDataDevicesListAdapter);
    }


    @Override
    public void update(Observable o, Object arg) {
        if(o instanceof KatDevices) {
            mRawDataDevicesListAdapter.clear();
            for(KatDevice device : KatDevices.getInstance().getConnectedKatDevices()) {
                mRawDataDevicesListAdapter.add(device);
            }
        }
    }
}
