package com.example.mmittek.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class FeedbackBlinker extends View implements Runnable {

    protected Thread mBlinkingThread;
    protected boolean mState;
    protected String mText;
    protected int mBlinkingInterval;
    protected boolean mRunning;
    protected Paint mPaint;

    public FeedbackBlinker(Context context) {
        super(context);
        init();
    }

    public FeedbackBlinker(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public FeedbackBlinker(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public FeedbackBlinker(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    public void setText(String text) {
        mText = text;
    }

    @Override
    public void run() {

        while (mRunning) {
            try {
                mState = !mState;
                invalidate();
                Thread.sleep(mBlinkingInterval);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void finalize() {
        mRunning = false;
        if (mBlinkingThread != null) {
            try {
                mBlinkingThread.join();
            } catch (InterruptedException e) {
            }
        }
    }

    protected void init() {
        mBlinkingInterval = 500;
        mText = "Attention!";
        mState = false;
        mPaint = new Paint();

        mBlinkingThread = new Thread(this);
        mRunning = true;
        mBlinkingThread.start();
    }


    @Override
    protected void onDraw(Canvas canvas) {
        float canvasHeight = getHeight();
        float canvasWidth = getWidth();

        if(mState) {
            mPaint.setColor(Color.RED);

        } else {
            mPaint.setColor(Color.BLUE);

        }
        mPaint.setTextSize(50);
        canvas.drawText(mText, 30, 50, mPaint);

    }
}