package com.example.mmittek.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;

/**
 * Created by mmittek on 10/9/16.
 */

public class EMGPlot extends ParamViewBase {

    protected float  mValue = 0.0f;


    public EMGPlot(Context context) {
        super(context);
    }
    public EMGPlot(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public EMGPlot(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
    public EMGPlot(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }



    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mPaint.reset();
        float canvasHeight = getHeight();
        float canvasWidth = getWidth();

        mPaint.setTextSize(mTextSize);
        if (mDrawPositions) {
            mPaint.setColor(Color.BLUE);
            canvas.drawText("ON " + Utils.roundFloat(mValue, 2) + "", 15, mTextSize*1.1f, mPaint);

        } else {
            mPaint.setColor(Color.GRAY);
            canvas.drawText("OFF " + Utils.roundFloat(mValue, 2) + "", 15, mTextSize*1.1f, mPaint);

        }

        if (mDescription != null) {
            canvas.drawText(mDescription, 15, canvasHeight - 15, mPaint);
        }


        // outline
        mPaint.setColor(Color.LTGRAY);
        mPaint.setStrokeWidth(5);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(0, 0, canvasWidth, canvasHeight, mPaint);

    }

}
