package com.example.mmittek.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.AttributeSet;

public class DistPlot extends ParamViewBase {

    protected float mValue = 100;
    protected float mMaxValue = 400;

    public DistPlot(Context context) {

        super(context);
    }

    public DistPlot(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public DistPlot(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public DistPlot(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }



    public void setMaxValue(float max) {
        mMaxValue = max;
    }

    public void setValue(float value) {
        mValue = value;
    }

    @Override
    protected void newDataValue(float value) {
        setValue(value);
        invalidate();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mPaint.reset();
        float canvasHeight = getHeight();
        float canvasWidth = getWidth();

        mPaint.setTextSize(mTextSize);
        if(mDrawPositions) {
            mPaint.setColor(Color.BLUE);
            canvas.drawText("ON " + Utils.roundFloat(mValue,2) + "", 15, mTextSize*1.1f, mPaint);

        } else {
            mPaint.setColor(Color.GRAY);
            canvas.drawText("OFF " + Utils.roundFloat(mValue,2) + "", 15, mTextSize*1.1f, mPaint);

        }

        if(mDescription != null) {
            canvas.drawText(mDescription, 15, canvasHeight-15, mPaint);
        }


        // outline
        mPaint.setColor(Color.LTGRAY);
        mPaint.setStrokeWidth(5);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(0,0,canvasWidth,canvasHeight, mPaint);


        canvas.translate(0, 1*canvasHeight/2);


        float scaledValue = mValue * canvasWidth / mMaxValue;

        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setColor(Color.RED);
        canvas.drawRect( 0, -canvasHeight/8, scaledValue,canvasHeight/8, mPaint );



        // Positions
//        if( (mDrawPositions) && ( mPositions != null ) && (mPositions.length >0) && (mExpectedStatisticNames != null) && (mExpectedStatisticNames.length > 0)) {
        if( (mDrawPositions) && ( myPositions != null ) && (myPositions.size() >0) ) {
            for(KatStaticPosition position: myPositions) {

                mPaint.setStyle(Paint.Style.FILL);
                mPaint.setColor(position.getColor());
                mPaint.setAlpha(200);

                float positionScale = mGlobalToleranceScale;
                Bundle stats = position.getStatistics();
                if(stats == null) continue;
                    ParameterStats paramStats = (ParameterStats)stats.getSerializable( mParamName+"Stats" );
                    if(paramStats == null) continue;

                    float paramMean = (float)paramStats.getMean();
                    float paramStdDev = (float)Math.sqrt(paramStats.getVariance());


                    float drawLow = (paramMean - 3*paramStdDev*positionScale*mParamFeedbackScale) * canvasWidth/mMaxValue;
                    float drawHigh = (paramMean + 3*paramStdDev*positionScale*mParamFeedbackScale) * canvasWidth/mMaxValue;

                    canvas.drawRect( drawLow, -canvasHeight/5, drawHigh, canvasHeight/5, mPaint );


            }

        }

    }
}
