package com.example.mmittek.myapplication;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by mmittek on 10/6/16.
 */
public class CsvFormatter {

    protected HashMap<Integer, String> mOrderedFieldNames = new HashMap<Integer, String>();
    protected HashMap<String, String> mBuffer = new HashMap<String, String>();
    protected String mSeparator = ",";
    protected String mLineSeparator = "\r\n";
    protected String mEmptyValue = "0";

    public CsvFormatter(String[] fieldNames) {
        for(int i=0; i<fieldNames.length; i++) {
            mOrderedFieldNames.put( i, fieldNames[i] );
            mBuffer.put( fieldNames[i], mEmptyValue );
        }
    }

    public CsvFormatter(ArrayList<String> fieldNames) {
        int i=0;
        for(String fieldName : fieldNames) {
            mOrderedFieldNames.put( i, fieldName);
            mBuffer.put( fieldName, mEmptyValue );
            i++;
        }
    }

    public final String getEmptyValue() {
        return mEmptyValue;
    }

    public void setEmptyValue(String emptyValue) {
        mEmptyValue = emptyValue;
    }

    public void storeInBuffer(String fieldName, String fieldValue) {
        if( mBuffer.containsKey(fieldName) ) {
            mBuffer.put( fieldName, fieldValue);
        }
    }

    public final String getRecord() {
        String record = "";
        int j=0;
        for(Integer i : mOrderedFieldNames.keySet()) {
            if (j == 0) {

                record = record + mBuffer.get(mOrderedFieldNames.get(i));
            } else {
                record = record + mSeparator + mBuffer.get(mOrderedFieldNames.get(i));

            }
            j++;
        }
        return record;
    }

    public final String getHeader() {
        String header = "";
        int j=0;
        for(Integer i : mOrderedFieldNames.keySet()) {
            if(j==0) {
                header = header + mOrderedFieldNames.get(i);
            } else {
                header = header + mSeparator + mOrderedFieldNames.get(i);
            }
            j++;
        }
        return header + mLineSeparator;
    }

    public void setmLineSeparator(String lineSep) {
        mLineSeparator = lineSep;
    }

    public final String getLineSeparator() {
        return mLineSeparator;
    }

    public void setSeparator(String sep) {
        mSeparator = sep;
    }

    public final String getSeparator() {
        return mSeparator;
    }

}
