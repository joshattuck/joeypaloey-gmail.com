package com.example.mmittek.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.util.AttributeSet;

public class AnglePlot extends ParamViewBase {



    protected float mAngle = 0;
    protected float mWidth = 80;
    protected float mHeight = 30;
    protected float mFillRatio = 0.8f;
    protected boolean mGoalEnabled = false;
    protected float mGoalAngle = 0;




    public AnglePlot(Context context, AttributeSet attrs) {
        super(context, attrs);

    }



    public AnglePlot(Context context, AttributeSet attrs, int irgendwas) {
        super(context, attrs);
        mPaint = new Paint();
    }

    @Override
    protected void newDataValue(float value) {
        setAngle(value);
    }


    public void setAngle(final float angle) {
        mAngle = angle;
        invalidate();
    }

    public final float getAngle() {
        return mAngle;
    }


    public boolean isGoalEnabled() {
        return mGoalEnabled;
    }

    public final float getGoalAngle() {
        return mGoalAngle;
    }



    public void setGoalAngle(float angle, boolean draw) {
        mGoalAngle = angle;
        mGoalEnabled = draw;
        invalidate();
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mPaint.reset();
        float canvasHeight = getHeight();
        float canvasWidth = getWidth();
        float drawWidth = mWidth;
        float drawHeight = mHeight;




        // Figure out the dimension to limit the box
        float referenceDimension = (canvasHeight < canvasWidth)? canvasHeight : canvasWidth;

        float widthToHeightRatio = mWidth/mHeight;

        if(mWidth >  mHeight) {
            // adjusting for width
            drawWidth = referenceDimension*mFillRatio;
            drawHeight = drawWidth / widthToHeightRatio;
        } else {
            // adjusting for height
            drawHeight = referenceDimension*mFillRatio;
            drawWidth = drawHeight * widthToHeightRatio;
        }

        mPaint.setTextSize(mTextSize);
        if(mDrawPositions) {
            mPaint.setColor(Color.BLUE);
            canvas.drawText("ON " + Utils.roundFloat(mAngle,2) + "", 15, mTextSize*1.1f, mPaint);

        } else {
            mPaint.setColor(Color.GRAY);
            canvas.drawText("OFF " + Utils.roundFloat(mAngle,2) + "", 15, mTextSize*1.1f, mPaint);
        }

        if(mDescription != null) {
            canvas.drawText(mDescription, 15, 3*drawHeight, mPaint);
        }

        // outline
        mPaint.setColor(Color.LTGRAY);
        mPaint.setStrokeWidth(5);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(0,0,canvasWidth,canvasHeight, mPaint);



        // left top right bottom
        mPaint.setColor(Color.BLACK);
        mPaint.setAlpha(128);
        mPaint.setStyle(Paint.Style.FILL);
        canvas.translate(canvasWidth/2,canvasHeight/2); // move to the middle
        canvas.rotate(mAngle);
        canvas.drawRect(-drawWidth/2,-drawHeight/2,  drawWidth/2, drawHeight/2, mPaint);

        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setColor(Color.GREEN);
        canvas.drawLine(-drawWidth/2, 0, drawWidth/2, 0, mPaint);

        mPaint.setColor(Color.RED);
        mPaint.setAlpha(255);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawCircle(0,0, 10, mPaint);

        // go back to angle 0
        canvas.rotate( -mAngle);


//        if( (mDrawPositions) && (mPositions != null) && (mPositions.length > 0) && (mExpectedStatisticNames != null) && (mExpectedStatisticNames.length > 0)) {
        if( (mDrawPositions) && (myPositions != null) && (myPositions.size() > 0))  {
//            String mExpectedStatisticNames[] = {"orientationStatsX", "orientationStatsY", "orientationStatsZ"};
//            for(int i=0; i<myPositions.size(); i++) {
            for(KatStaticPosition position: myPositions) {

                Bundle b = position.getStatistics();
                if(b == null) continue;

                    ParameterStats stats = (ParameterStats)b.getSerializable(  mParamName+"Stats" );
                    if(stats == null) continue;

                    Double angleMean = stats.getMean();
                    Double angleSd = Math.sqrt( stats.getVariance() );

                    Float scale = mGlobalToleranceScale;



                    double lowAngle = Utils.angleDifference(angleMean, 3*angleSd*scale*mParamFeedbackScale);
                    double highAngle = Utils.angleDifference(angleMean, -3*angleSd*scale*mParamFeedbackScale);

                /*
                    canvas.rotate( (float)lowAngle );
                    mPaint.setStyle(Paint.Style.STROKE);
                    mPaint.setStrokeWidth(7);
                    mPaint.setColor( position.getColor() );
                    canvas.drawLine(-drawWidth/2, 0, drawWidth/2, 0, mPaint);
                    canvas.rotate( (float)-lowAngle );

                    canvas.rotate( (float)highAngle );
                    mPaint.setStyle(Paint.Style.STROKE);
                    mPaint.setStrokeWidth(7);
                    mPaint.setColor( position.getColor() );
                    canvas.drawLine(-drawWidth/2, 0, drawWidth/2, 0, mPaint);
                    canvas.rotate( (float)-highAngle );
*/
                    float lowAngleRadians = (float)(Math.PI*lowAngle/180.0);
                    float highAngleRadians = (float)(Math.PI*highAngle/180.0);
                    float d = drawWidth/2;
                    float lowAngleX = d*(float)Math.cos(lowAngleRadians);
                    float lowAngleY = d*(float)Math.sin(lowAngleRadians);
                    float highAngleX = d*(float)Math.cos(highAngleRadians);
                    float highAngleY = d*(float)Math.sin(highAngleRadians);

                    mPaint.setColor( position.getColor() );
                    mPaint.setAlpha(190);
//                    mPaint.setColor( Color.argb(190, 255, 0, 0) );
                    mPaint.setStyle(Paint.Style.FILL_AND_STROKE);

                    Path angleRangePath = new Path();

                    angleRangePath.moveTo( -lowAngleX, -lowAngleY );
                    angleRangePath.lineTo( -highAngleX, -highAngleY );
                    angleRangePath.lineTo( 0, 0 );

                    angleRangePath.lineTo( lowAngleX, lowAngleY );
                    angleRangePath.lineTo( highAngleX, highAngleY );
                    angleRangePath.lineTo( 0, 0 );
                    angleRangePath.close();
                    canvas.drawPath(angleRangePath, mPaint);
            }
        }
    }
}
