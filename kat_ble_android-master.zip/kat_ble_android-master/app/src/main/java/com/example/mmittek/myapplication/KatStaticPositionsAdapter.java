package com.example.mmittek.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Observable;
import java.util.Observer;

public class KatStaticPositionsAdapter extends BaseAdapter implements Serializable, Observer {

    private KatStaticPosition[] mKatStaticPositions;
    private Context mContext;
    private int mLayoutElement;

    public KatStaticPositionsAdapter(Context context, int layoutElement, KatStaticPosition[] staticPositions) {
        mContext = context;
        mLayoutElement = layoutElement;
        mKatStaticPositions = staticPositions;
    }

    @Override
    public int getCount() {
        return mKatStaticPositions.length;
    }

    @Override
    public Object getItem(int i) {
        if(i < mKatStaticPositions.length) {
            return mKatStaticPositions[i];
        }
        return null;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        final View result;
        if (view == null) {
            result = LayoutInflater.from(viewGroup.getContext()).inflate(mLayoutElement, viewGroup, false);
        } else {
            result = view;
        }

        KatStaticPosition position = (KatStaticPosition)getItem(i);
        position.addObserver(this);

        TextView idTextView = (TextView)result.findViewById(R.id.positionID);
        idTextView.setText("Position " + position.getID());

        ToggleButton positionStateToggleButton = (ToggleButton)result.findViewById(R.id.toggleButton);
        positionStateToggleButton.setTag(position);


        CheckBox hasDataCheckBox = (CheckBox)result.findViewById(R.id.hasData);


        // Recording start / stop
        Button recordButton = (Button)result.findViewById(R.id.recordButton);
        recordButton.setTag(position);
        if(position.isRecording()) {
            recordButton.setText("STOP REC.");
        } else {
            recordButton.setText("RECORD");
        }

        //
//
//        TextView idTextView = (TextView)result.findViewById(R.id.positionID);
//        idTextView.setText("Position " + position.getID());
//        idTextView.setTextColor( position.getColor() );
//
//        toggleButton.setTag(mKatStaticPositions.get(i));
        if(position.hasData()) {
            positionStateToggleButton.setEnabled(true);
        } else {
            positionStateToggleButton.setEnabled(false);
        }
        hasDataCheckBox.setChecked( position.hasData());
        return result;
    }

    @Override
    public void update(Observable o, Object arg) {
        if(o instanceof KatStaticPosition) {
            notifyDataSetChanged();
        }
    }
}
