package com.example.mmittek.myapplication;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import org.apache.commons.math3.stat.descriptive.moment.Mean;
import org.apache.commons.math3.stat.descriptive.moment.Variance;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;


class PositionResponse {
    public KatStaticPosition PositionObj;
    public int Position;
    public float minParamResponse = 999999;
    public float maxParamResponse = 0;
}


public class KatTracker {

    private ArrayList<Data3D> mAccData;
    private ArrayList<Data3D> mOrientationData;
    private ArrayList<Data2D> mSonarsData;


    private ArrayList<Double> mOrientationX;
    private ArrayList<Double> mOrientationY;
    private ArrayList<Double> mOrientationZ;

    private ArrayList<Double> mAccX;
    private ArrayList<Double> mAccY;
    private ArrayList<Double> mAccZ;

    private ArrayList<Double> mSonarsX;
    private ArrayList<Double> mSonarsY;

    private ArrayList<Double> mEMG;

    private HashSet<String> mParamsUsedForFeedback;
    private HashMap<String, Float> mCurrentParamValues;

    private HashMap<String, Float> mCurrentFeedbackScales;

    private FeedbackMode mFeedbackMode;

    private boolean isRecording;
    private Handler mContextHandler;
    private Bundle mFeedbackStatsData;
    private String mMAC;
    private Float mScale = 1f;

    private FeedbackStrength.Strength mPrevStrength = FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF;

    private KatStaticPosition[] mActivePositions;

    public KatTracker(Handler contextHandler, String MAC) {

        mContextHandler = contextHandler;
        isRecording = false;
        mParamsUsedForFeedback = new HashSet<String>();
        mMAC = MAC;

        // Add all for feedback
        mParamsUsedForFeedback.add("orientationStatsX");
        mParamsUsedForFeedback.add("orientationStatsY");
        mParamsUsedForFeedback.add("orientationStatsZ");
        mParamsUsedForFeedback.add("accStatsX");
        mParamsUsedForFeedback.add("accStatsY");
        mParamsUsedForFeedback.add("accStatsZ");

        mParamsUsedForFeedback.add("sonarStatsX");
        mParamsUsedForFeedback.add("sonarStatsY");

        mParamsUsedForFeedback.add("emg");

        mFeedbackMode = FeedbackMode.FEEDBACK_MODE_OFF;

        mCurrentParamValues = new HashMap<String, Float>();
        mCurrentFeedbackScales = new HashMap<String, Float>();

        mActivePositions = null;
    }

    public final Bundle getFeedbackStatsData() {
        return mFeedbackStatsData;
    }

    public void setFeedbackStatsData(Bundle statsData) {
        mFeedbackStatsData = statsData;
    }

    public void setActivePositions(final KatStaticPosition[] activePositions) {
        mActivePositions = activePositions;
    }

    public void setScale(Float scale) {
        mScale = scale;
    }

    protected void startRecording() {
        mAccData = new ArrayList<Data3D>();
        mOrientationData = new ArrayList<Data3D>();
        mSonarsData = new ArrayList<Data2D>();

        mOrientationX  = new ArrayList<Double> ();
        mOrientationY  = new ArrayList<Double> ();
        mOrientationZ = new ArrayList<Double> ();

        mAccX = new ArrayList<Double>();
        mAccY = new ArrayList<Double>();
        mAccZ = new ArrayList<Double>();

        mSonarsX = new ArrayList<Double>();
        mSonarsY = new ArrayList<Double>();

        mEMG = new ArrayList<Double>();

        isRecording = true;
    }

    protected void stopRecording() {
        isRecording = false;
    }

    public final boolean isRecording() {
        return isRecording;
    }

    public void toggleRecording() {
        setRecording(!isRecording);
    }

    public void setRecording(boolean recording) {
        if(recording) {
            startRecording();
        } else {
            stopRecording();
        }
    }

    public void setFeedbackMode(FeedbackMode mode) {
        mFeedbackMode = mode;
    }

    public final FeedbackMode getFeedbackMode() {
        return mFeedbackMode;
    }



    public static ParameterStats calculateParameterStats(ArrayList<Double> angleData, boolean isAngle) {
        double[] arr = Utils.toPrimitive(angleData.toArray(new Double[angleData.size()]));
        double mean = 0;
        double variance = 0;
        if(isAngle) {
            mean = Utils.averageAngle(arr);
            variance = Utils.angleVariance(arr);
        } else {
            Mean meanObj = new Mean();
            Variance varianceObj = new Variance();
            mean = meanObj.evaluate( arr );
            variance = varianceObj.evaluate(arr);
        }
        return new ParameterStats(mean, variance, isAngle);
    }


    public Bundle getStatisticsOfLastRecording() {
        ParameterStats orientationStatsX = calculateParameterStats(mOrientationX, true);
        ParameterStats orientationStatsY = calculateParameterStats(mOrientationY, true);
        ParameterStats orientationStatsZ = calculateParameterStats(mOrientationZ, true);

        ParameterStats accStatsX = calculateParameterStats(mAccX, false);
        ParameterStats accStatsY = calculateParameterStats(mAccY, false);
        ParameterStats accStatsZ = calculateParameterStats(mAccZ, false);

        ParameterStats sonarStatsX = calculateParameterStats(mSonarsX, false);
        ParameterStats sonarStatsY = calculateParameterStats(mSonarsY, false);

        ParameterStats emgStats = calculateParameterStats(mEMG, false);


        Bundle b = new Bundle();
        b.putSerializable("orientationStatsX", orientationStatsX);
        b.putSerializable("orientationStatsY", orientationStatsY);
        b.putSerializable("orientationStatsZ", orientationStatsZ);
        b.putSerializable("accStatsX", accStatsX);
        b.putSerializable("accStatsY", accStatsY);
        b.putSerializable("accStatsZ", accStatsZ);
        b.putSerializable("sonarStatsX", sonarStatsX);
        b.putSerializable("sonarStatsY", sonarStatsY);
        b.putSerializable("emg", emgStats);

        Log.d("tracker", "angles: " + orientationStatsX + ", " + orientationStatsY + ", " + orientationStatsZ);
        Log.d("tracker", "acc: " + accStatsX + ", " + accStatsY + ", " + accStatsZ);
        Log.d("tracker", "sonars: " + sonarStatsX + ", " + sonarStatsY);
        Log.d("tracker", "emg: " + emgStats);
        return b;
    }

    protected void sendMessage(DataBase data, KatMessageType messageType) {
        Message m = new Message();
        Bundle b = new Bundle();
        b.putFloatArray("data", data.toArray());
        b.putString("device", mMAC);
        m.setData(b);
        m.what = messageType.ordinal();
        m.obj = this;
        mContextHandler.sendMessage(m);
    }

    public void setParamFeedbackScale(String paramName, double scale) {
        mCurrentFeedbackScales.put(paramName, (float)scale);
    }

    public final HashMap<String, Float> getParamFeedbackScales() {
        return mCurrentFeedbackScales;
    }

    public void addEMGData(byte[] data) {
        for(int i=0; i<data.length; i+=2) {
            int byteL = data[i];
            int byteH = data[i+1];
            float sampleValue = byteH*256 + byteL;
            Data1D sample = new Data1D(sampleValue);
            if(isRecording) {
                mEMG.add((double)sample.getX());
            } else {
                newSensorValueForFeedback("emgStatsX", sample.getX() );
            }
            sendMessage( sample , KatMessageType.KAT_MESSAGE_TYPE_EMG_DATA);
        }

        if(!isRecording) {
            recalculateFeedback();
        }
    }

    public void addOrientationData(byte[] data) {
        Data3D sample = new Data3D(data);
        sample.addY(90);
        sample.addZ(180);
        if(isRecording) {
//            mAccData.add(sample);
            mOrientationX.add((double)sample.getX());
            mOrientationY.add((double)sample.getY() );
            mOrientationZ.add((double)sample.getZ());
        } else {
            newSensorValueForFeedback("orientationStatsX", sample.getX() );
            newSensorValueForFeedback("orientationStatsY", sample.getY() );
            newSensorValueForFeedback("orientationStatsZ", sample.getZ() );
            recalculateFeedback();
        }
        sendMessage(sample, KatMessageType.KAT_MESSAGE_TYPE_ORIENTATION_DATA);
    }


    public void addAccelerometerData(byte[] data) {
        Data3D sample = new Data3D(data);
        if(isRecording) {
            mAccX.add((double)sample.getX());
            mAccY.add((double)sample.getY());
            mAccZ.add((double)sample.getZ());
        } else {
            newSensorValueForFeedback("accStatsX", sample.getX() );
            newSensorValueForFeedback("accStatsY", sample.getY() );
            newSensorValueForFeedback("accStatsZ", sample.getZ() );
            recalculateFeedback();
        }
        sendMessage(sample, KatMessageType.KAT_MESSAGE_TYPE_NEW_ACCELEROMETER_DATA);
    }

    // FIxme nasty sonar value conditioning
    public void addSonarsData(byte[] data) {
        Data2D sample = new Data2D(data);

        if(isRecording) {
            if(sample.getX() <= 4000) mSonarsX.add((double)sample.getX());
            if(sample.getY() <= 4000) mSonarsY.add((double)sample.getY());
        } else {
            if(sample.getX() <= 4000)  newSensorValueForFeedback("sonarStatsX", sample.getX() );
            if(sample.getY() <= 4000) newSensorValueForFeedback("sonarStatsY", sample.getY() );

            if(( sample.getX() <=4000) || (sample.getY() <= 4000)) {
                recalculateFeedback();
            }
        }
        sendMessage(sample, KatMessageType.KAT_MESSAGE_TYPE_SONARS_DATA);
    }


    public void useFeedbackForParam(String paramName, boolean use) {
        if(use) {
            mParamsUsedForFeedback.add(paramName);
        } else {
            mParamsUsedForFeedback.remove(paramName);
        }
    }

    protected void newSensorValueForFeedback(String name, float sample) {
        mCurrentParamValues.put(name, sample);
    }


    protected Message prepareFeedbackStrengthMessage(FeedbackStrength.Strength strength) {
        Message m = new Message();
        m.what = KatMessageType.KAT_MESSAGE_TYPE_SET_FEEDBACK_STRENGTH.ordinal();
        Bundle b = new Bundle();
        b.putSerializable("FeedbackStrength", strength);
        m.setData(b);
        return m;
    }

    protected void setFeedbackStrength(FeedbackStrength.Strength strength, int winningPosition) {
        if(strength != mPrevStrength) {
            Message m = prepareFeedbackStrengthMessage(strength);
            m.getData().putInt("WinningPosition", winningPosition);
            mContextHandler.sendMessage(m);
            mPrevStrength = strength;
        }
    }

    protected void setFeedbackStrength(FeedbackStrength.Strength strength) {
        if(strength != mPrevStrength) {
            mContextHandler.sendMessage( prepareFeedbackStrengthMessage(strength) );
            mPrevStrength = strength;
        }
    }
    // Feedback calculation
    private void recalculateFeedback() {

        ArrayList<PositionResponse> positionResponses = new ArrayList<PositionResponse>();
;
        float normalizedDifferenceSum = 0f;
        ArrayList<Float> normalizedDifferences = new ArrayList<Float>();
        int N = 0;

        if( (mFeedbackMode == FeedbackMode.FEEDBACK_MODE_OFF) || (mActivePositions == null) || (mActivePositions.length == 0))  {
            setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF);
            return;
        }

        for(int i=0; i<mActivePositions.length; i++) {
            KatStaticPosition position = mActivePositions[i];
            Bundle positionStatsBundle = position.getStatistics();
            Iterator<String> paramNameIterator = mParamsUsedForFeedback.iterator();

            PositionResponse positionResponse = new PositionResponse();
            positionResponse.Position = position.getID();

            while(paramNameIterator.hasNext()) {
                String paramName = paramNameIterator.next();
                ParameterStats parameterStats = (ParameterStats)positionStatsBundle.getSerializable(paramName);
                if(parameterStats == null) continue;

                Float paramScale = 1.0f;
                if(mCurrentFeedbackScales != null) {
                    paramScale = mCurrentFeedbackScales.get(paramName);
                    if(paramScale == null) {
                        paramScale = 1.0f;
                    }
                }


                Double paramMean = parameterStats.getMean();
                Double paramVariance = parameterStats.getVariance();

                if((paramMean.isNaN()) || (paramVariance.isNaN()) || (paramVariance <= 0)) continue;
                float paramCurrentValue = mCurrentParamValues.get(paramName);

                float normalizedDifference = 0;
                if(parameterStats.isAngle()) {
                    normalizedDifference = (float)Math.abs( Utils.angleDifference((double)paramCurrentValue, paramMean) )/ (float)(  Math.sqrt(paramVariance));
                } else {
                    normalizedDifference = Math.abs( paramCurrentValue - (float)(double)paramMean ) / (float)(  Math.sqrt(paramVariance));      // riddick again!
                }

                normalizedDifference /= paramScale;

               // positionResponse.paramScale = paramScale;
                if( normalizedDifference < positionResponse.minParamResponse ) {
                    positionResponse.minParamResponse = normalizedDifference;
                }
                if( normalizedDifference > positionResponse.maxParamResponse ) {
                    positionResponse.maxParamResponse = normalizedDifference;
                }

                normalizedDifferences.add(normalizedDifference);
                normalizedDifferenceSum += normalizedDifference;
                N++;
            }

            positionResponses.add( positionResponse );
        }


        PositionResponse[] positionResponsesArr = positionResponses.toArray(new PositionResponse[positionResponses.size()]);

        if(mFeedbackMode == FeedbackMode.FEEDBACK_MODE_IN) {
            for(int i=0; i<positionResponsesArr.length; i++) {
                // All params within boundaries for at least one position
                if(positionResponsesArr[i].maxParamResponse <= 3*mScale) {
                    setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_HIGH, positionResponsesArr[i].Position);
                    return;
                }
            }
            // Return should not let this code to execute
            setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF);
        } else if(mFeedbackMode == FeedbackMode.FEEDBACK_MODE_OUT) {
            int numOut = 0;
            for(int i=0; i<positionResponsesArr.length; i++) {
                // At least one param of all positions needs to be OUT
                if (positionResponsesArr[i].maxParamResponse > 3*mScale ) {
                    numOut++;
                }
            }
            if(numOut == positionResponsesArr.length) {
                setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_HIGH);
            } else {
                // Return should not let this code to execute
                setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF);

            }
        } else if(mFeedbackMode == FeedbackMode.FEEDBACK_MODE_OFF) {
            setFeedbackStrength(FeedbackStrength.Strength.FEEDBACK_STRENGTH_OFF);
        }
    }

}
