package com.example.mmittek.myapplication;

/**
 * Created by mmittek on 9/26/16.
 */
public interface KatDeviceController {
    public void setKineticFeedbackEnabled(boolean enabled);
    public void setLaserDiodesEnabled(boolean enabled);
    public void setAcousticFeedbackEnabled(boolean enabled);
    public void setFeedbackStrength(FeedbackStrength.Strength strength);
}
