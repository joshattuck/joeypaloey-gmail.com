package com.example.mmittek.myapplication;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/**
 * Created by mmittek on 7/20/16.
 */
public class Data1D extends DataBase {


    protected float mX;

    public Data1D(long timestamp, float x) {
        super(timestamp);
        mX = x;
        mDimensions = 1;
    }

    public Data1D(float x) {
        super(0);
        mDimensions = 1;
        mX = x;
    }

    public Data1D(final byte[] rawBytes) {
        super(0);
        mDimensions = 1;
        if(rawBytes.length >= 8) {
            mTimestamp = getByteArraySliceAsInt(rawBytes, 0);
            mX = getByteArraySliceAsFloat(rawBytes, 4);
        }
    }

    public float[] toArray() {
        float x[] = { mX};
        return x;
    }


    public final float getX() {
        return mX;
    }

    public void addX(float x) {
        float newX = mX + x;
        setX(newX);
    }

    public void setX(float x) {
        if(mX != x) {
            mX = x;
            hasChanged();
            notifyObservers();
        }
    }

    @Override
    public String toString() {
        return super.toString() + ": " + mX;
    }

    protected long getByteArraySliceAsInt(final byte[] arr, int start) {
        byte[] val = Arrays.copyOfRange(arr, start, start+4);
        return ByteBuffer.wrap(val).order(ByteOrder.LITTLE_ENDIAN).getInt();
    }

    protected float getByteArraySliceAsFloat(final byte[] arr, int start) {
        byte[] val = Arrays.copyOfRange(arr, start, start+4);
        return ByteBuffer.wrap(val).order(ByteOrder.LITTLE_ENDIAN).getFloat();
    }

}
