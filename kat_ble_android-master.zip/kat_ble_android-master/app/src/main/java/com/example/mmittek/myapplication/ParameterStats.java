package com.example.mmittek.myapplication;

import android.util.Log;

import org.apache.commons.math3.stat.descriptive.moment.Mean;
import org.apache.commons.math3.stat.descriptive.moment.Variance;

import java.io.Serializable;
import java.util.ArrayList;

public class ParameterStats implements Serializable {

    protected double mMean = 0;
    protected double mVariance = 0;
    protected boolean mIsAngle = false;

    public ParameterStats(double mean, double variance) {
        mMean = mean;
        mVariance = variance;
        mIsAngle =false;
    }

    public ParameterStats(double mean, double variance, boolean isAngle) {
        mMean = mean;
        mVariance = variance;
        mIsAngle = isAngle;
    }

    public final boolean isAngle() {
        return mIsAngle;
    }

    public final double getMean() {
        return mMean;
    }

    public final double getVariance() {
        return mVariance;
    }

    public void setVariance(double variance) {
        mVariance = variance;
    }

    @Override
    public String toString() {
        return "" + mMean + " (" + mVariance + ")";
    }



    public static ParameterStats calculateParameterStats(ArrayList<Double> angleData, boolean isAngle) {
        double[] arr = Utils.toPrimitive(angleData.toArray(new Double[angleData.size()]));
        double mean = 0;
        double variance = 0;
        if(isAngle) {
            mean = Utils.averageAngle(arr);
            variance = Utils.angleVariance(arr);

            Log.d("param stats", "angle: " + mean + " (" + variance + ")" );

        } else {
            Mean meanObj = new Mean();
            Variance varianceObj = new Variance();
            mean = meanObj.evaluate( arr );
            variance = varianceObj.evaluate(arr);
        }
        return new ParameterStats(mean, variance, isAngle);
    }

}
