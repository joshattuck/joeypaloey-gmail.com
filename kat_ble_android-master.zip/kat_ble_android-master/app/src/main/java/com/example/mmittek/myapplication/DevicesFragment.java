package com.example.mmittek.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

class MyAdapter extends BaseAdapter {

    private int mLayoutElement;
    private Context mContext;
    private HashMap<String, MyBluetoothDeviceInfo> mHashMap;




    public MyAdapter(Context context, int layoutElement, HashMap<String, MyBluetoothDeviceInfo> hashMap) {
        mContext = context;
        mLayoutElement = layoutElement;
        mHashMap = hashMap;
    }


    public void add(MyBluetoothDeviceInfo newBluetoothDevice) {
        mHashMap.put( newBluetoothDevice.getMAC(), newBluetoothDevice );
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {

        return mHashMap.size();
    }

    @Override
    public Object getItem(int i) {
        int index = 0;
        MyBluetoothDeviceInfo myBluetoothDevice = null;
        for (String key : mHashMap.keySet()) {
            myBluetoothDevice = mHashMap.get(key);
            if(index == i) {
                return myBluetoothDevice;
            }
            ++index;
        }
        return null;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    private int getFirstSeenInSecondsAgo( Date firstSeen) {
        Date now = Calendar.getInstance().getTime();

        long diffInMs = now.getTime() - firstSeen.getTime();
        return (int)diffInMs/1000;

    }

    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        final View result;
        if (convertView == null) {
            result = LayoutInflater.from(parent.getContext()).inflate(mLayoutElement, parent, false);
        } else {
            result = convertView;
        }

        MyBluetoothDeviceInfo myBluetoothDeviceInfo = (MyBluetoothDeviceInfo)getItem(i);
        Button button;


        if(myBluetoothDeviceInfo != null) {
            // TODO replace findViewById by ViewHolder
            ((TextView) result.findViewById(R.id.deviceName)).setText( myBluetoothDeviceInfo.getName() );
            ((TextView) result.findViewById(R.id.deviceMAC)).setText( myBluetoothDeviceInfo.getMAC() );
            ((TextView) result.findViewById(R.id.deviceRSSI)).setText( "RSSI: " + myBluetoothDeviceInfo.getRssi()  + "dBm" );

            ((TextView) result.findViewById(R.id.deviceFirstSeenSecondsAgo)).setText( "Seen: " + getFirstSeenInSecondsAgo(myBluetoothDeviceInfo.getFirstSeen())  + " sec ago" );


            button = (Button)result.findViewById(R.id.connectButton);
            button.setEnabled( myBluetoothDeviceInfo.getConnectionAllowed() );

            ConnectDisconnectTag tag = new ConnectDisconnectTag();
            tag.MAC = myBluetoothDeviceInfo.getMAC();

            if(myBluetoothDeviceInfo.isConnected()) {
                button.setText("Disconnect");
                tag.connect = false;
            } else {
                button.setText("Connect");
                tag.connect = true;
            }
            button.setTag(tag);
        }

        return result;
    }
}



public class DevicesFragment extends Fragment {


    private HashMap<String, MyBluetoothDeviceInfo>  myBluetoothDeviceInfos;
    private MyAdapter mMyBluetoothDeviceInfoListAdapter;

    @Override
    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setRetainInstance(true);
    }


    public DevicesFragment() {
    }

    public void bluetoothDeviceConnected(String MAC, boolean connected) {
        MyBluetoothDeviceInfo deviceInfo = myBluetoothDeviceInfos.get(MAC);
        if(deviceInfo == null) return;
        deviceInfo.setConnected(connected);
    }

    public void bluetoothDeviceFound(MyBluetoothDeviceInfo deviceInfo) {
        String MAC = deviceInfo.getMAC();
        myBluetoothDeviceInfos.put(MAC, deviceInfo);
        mMyBluetoothDeviceInfoListAdapter.notifyDataSetChanged();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_devices, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        ListView lv = (ListView) view.findViewById(R.id.devicesListView);
        if(lv != null) {
            myBluetoothDeviceInfos = new HashMap<String, MyBluetoothDeviceInfo>();
            mMyBluetoothDeviceInfoListAdapter = new MyAdapter(view.getContext(), R.layout.my_list_items, myBluetoothDeviceInfos);
            lv.setAdapter(mMyBluetoothDeviceInfoListAdapter);
        }
    }
}
