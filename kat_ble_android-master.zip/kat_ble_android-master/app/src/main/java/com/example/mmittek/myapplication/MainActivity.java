package com.example.mmittek.myapplication;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.ParcelUuid;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;
import java.util.UUID;



public class MainActivity extends AppCompatActivity implements ListView.OnItemClickListener, Observer {

    protected final static int DRAWER_ITEM_DEVICES = 0;
    protected final static int DRAWER_ITEM_RAW_DATA = 1;
    protected final static int DRAWER_ITEM_BODY_PART_SELECTION = 2;
    protected final static int DRAWER_ITEM_TRAINING = 3;
    protected final static int DRAWER_ITEM_RECORDS = 4;
    protected final static int DRAWER_ITEM_MULTIPLE_DEVICES = 5;

    protected String mCurrentlyLoadedTrainingSettingName = null;

    // Drawer stuff
    private String[] mNavigationDrawerItemTitles;
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private int mCurrentDrawerPosition;

    private CharSequence mDrawerTitle;
    private CharSequence mTitle;
    ObjectDrawerItem[] mDrawerItems;

    private boolean mIsScanning = false;
    BluetoothAdapter mBluetoothAdapter;
    private KatDevice mCurrentKatDevice = null;
    KatStaticPositionsAdapter mKatStaticPositionsAdapter;
    Fragment[] mFragments;
    ArrayList<BluetoothDevice> mFoundBluetoothDevices = new ArrayList<BluetoothDevice>();

    public void connectToOrDisconnectFromBluetoothDevice(View view) {
        ConnectDisconnectTag tag = (ConnectDisconnectTag)view.getTag();
        String MAC = tag.MAC;


        if(tag.connect) {
        //    mKatBluetooth.connectToBluetoothDevice(MAC);
            connectToBluetoothDevice(MAC);
        } else {
        //    mKatBluetooth.disconnectFromBluetoothDevice(MAC);
            disconnectFromBluetoothDevice(MAC);
        }
    }


    public void selectDeviceForTraining(View view) {
        Button selectedDeviceMacButton = (Button)view;                          // it only comes from the button view, so taken for granted
        KatDevice selectedDevice = (KatDevice) view.getTag();                   // get the instance of KatDevice as TAG
        Bundle settings = BodyPlacementSettingsFactory.getParamsForFullView();  // default full view for multiple devices

        String label = ("Device " + selectedDevice.getMAC()).toUpperCase();

        TrainingFragment trainingFragment = (TrainingFragment)mFragments[3];
        trainingFragment.setKatDevice(selectedDevice);
        trainingFragment.applySettings(settings);
        mCurrentlyLoadedTrainingSettingName = label;
        selectItem(3, label);
        mDrawerItems[ DRAWER_ITEM_TRAINING ].name = label;

    }

    public void bodyPartSelectionButtonHandler(View view) {
        String selectedBodyPartName = (String)view.getTag();
        loadBodyPlacementSettings(selectedBodyPartName);

    }

    public void changePositionRecordingState(View view) {
        if(view instanceof Button) {
            Button recordButton = (Button)view;
            KatStaticPosition position = (KatStaticPosition) recordButton.getTag();
            if(position.isRecording()) {
                position.stopRecording();
            } else {
                position.startRecording();
            }
        }
    }

    public void togglePositionState(View view) {
        if(view instanceof ToggleButton) {
            ToggleButton positionToggleButton = (ToggleButton)view;
            KatStaticPosition position = (KatStaticPosition)positionToggleButton.getTag();
            position.setActive(positionToggleButton.isChecked());

        }
    }

    protected void loadBodyPlacementSettings(String settingName) {
        Bundle settings = BodyPlacementSettingsFactory.getParamsForBodyPlacement( settingName );

//       FeedbackGenerator.getInstance().resetFeedbackSettings();
        if(mCurrentKatDevice != null) {
            mCurrentKatDevice.getFeedbackGenerator().resetFeedbackSettings();
        }

        TrainingFragment trainingFragment = (TrainingFragment)mFragments[3];
        trainingFragment.applySettings(settings);
        mCurrentlyLoadedTrainingSettingName = settingName;
        selectItem(3, settingName.toUpperCase());
        mDrawerItems[ DRAWER_ITEM_TRAINING ].name = settingName.toUpperCase();
    }



    private void bluetoothDeviceFound(ScanResult scanResult) {
        mFoundBluetoothDevices.add(scanResult.getDevice());

        DevicesFragment devicesFragment = (DevicesFragment) mFragments[0];
        devicesFragment.bluetoothDeviceFound(new MyBluetoothDeviceInfo(scanResult));
    }

    public void scanButtonHandler(View view) {
        Button button = (Button)view;
        final MainActivity mainActivity = this;

        ScanCallback mScanCallback = new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                super.onScanResult(callbackType, result);

                try {
                    for(ParcelUuid serviceUUID : result.getScanRecord().getServiceUuids()) {
                        if (serviceUUID.getUuid().equals( KatUUIDS.KAT_SERVICE_UUID  )) {
                            mainActivity.bluetoothDeviceFound(result);
                            break;
                        }
                    }
                }catch(Exception e) {
                    Log.d(this.getClass().getName(), e.getMessage());
                }
        }
        };

        if(mIsScanning) {
            mBluetoothAdapter.getBluetoothLeScanner().stopScan(mScanCallback);
            mIsScanning = false;
            button.setText("Scan");
        } else {
            mBluetoothAdapter.getBluetoothLeScanner().startScan(mScanCallback);
            mIsScanning = true;
            button.setText("Stop");
        }
    }


    /**
     * Implemented using solution from: http://stackoverflow.com/questions/24186781/android-navigation-drawer-fragment-state
     * @param position
     */
    private void selectItem(int position) {
        selectItem(position, mNavigationDrawerItemTitles[position]);
    }


    private void selectItem(int position, String customTitle) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        for(int i=0; i<mFragments.length; i++) {
            if( i == position) {
                ft.show(mFragments[i]);
            } else {
                ft.hide( mFragments[i] );
            }
        }
        ft.commit();
        mCurrentDrawerPosition = position;
        mDrawerList.setItemChecked(position, true);
        mDrawerList.setSelection(position);

        getSupportActionBar().setTitle(customTitle);


        mDrawerLayout.closeDrawer(mDrawerList);

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        selectItem(position);
    }

    public void disconnectFromBluetoothDevice(String MAC) {
        KatDevice deviceToDisconnect = KatDevices.getInstance().getKatDeviceByMAC(MAC);
        if(deviceToDisconnect != null) {
            deviceToDisconnect.disconnect();
        }
    }




    public boolean connectToBluetoothDevice(String MAC) {
        for(BluetoothDevice foundBluetoothDevice : mFoundBluetoothDevices) {
            if(foundBluetoothDevice.getAddress().equals(MAC)) {
                KatDevice katDevice = new KatDevice(this, foundBluetoothDevice);
                return katDevice.connect();
            }
        }

        return false;
    }

    public DevicesFragment getDevicesFragment() {
        return (DevicesFragment)mFragments[0];
    }






    public void positionRecordButtonOnClickHandler(View view) {
        KatStaticPosition position = (KatStaticPosition) view.getTag();
        Button button = (Button)view;
        if(position == null) return;
        if(mCurrentKatDevice == null) return;
        KatTracker tracker = mCurrentKatDevice.getTracker();

        if(tracker.isRecording()) {
            tracker.stopRecording();

            Bundle lastRecordingStats = tracker.getStatisticsOfLastRecording();
            position.setStatistics(lastRecordingStats);
            tracker.setFeedbackStatsData(lastRecordingStats);

            button.setText("Record");
        } else {
            tracker.startRecording();

            button.setText("STOP");
        }
        mKatStaticPositionsAdapter.notifyDataSetChanged();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_main);






/*
        //Determine screen size
        if ((getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_LARGE) {
            Toast.makeText(this, "Large screen", Toast.LENGTH_LONG).show();
        }
        else if ((getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_NORMAL) {
            Toast.makeText(this, "Normal sized screen", Toast.LENGTH_LONG).show();
        }
        else if ((getResources().getConfiguration().screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_SMALL) {
            Toast.makeText(this, "Small sized screen", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(this, "Screen size is neither large, normal or small", Toast.LENGTH_LONG).show();
        }
*/


        // enabling action bar app icon and behaving it as toggle button
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(false);
        actionBar.setHomeButtonEnabled(false);




        mNavigationDrawerItemTitles= getResources().getStringArray(R.array.navigation_drawer_items_array);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerList = (ListView) findViewById(R.id.left_drawer);

        mDrawerItems = new ObjectDrawerItem[6];
        mFragments = new Fragment[6];
        mFragments[DRAWER_ITEM_DEVICES] = getSupportFragmentManager().findFragmentById(R.id.devices_fragment);
        mFragments[DRAWER_ITEM_RAW_DATA] = getSupportFragmentManager().findFragmentById(R.id.raw_data_fragment);
        mFragments[DRAWER_ITEM_BODY_PART_SELECTION] = getSupportFragmentManager().findFragmentById(R.id.body_part_selection_fragment);
        mFragments[DRAWER_ITEM_TRAINING] = getSupportFragmentManager().findFragmentById(R.id.custom_training_fragment);
        mFragments[DRAWER_ITEM_RECORDS] = getSupportFragmentManager().findFragmentById(R.id.records_fragment);
        mFragments[DRAWER_ITEM_MULTIPLE_DEVICES] = getSupportFragmentManager().findFragmentById(R.id.multiple_devices_fragment);

        //mFragments[DRAWER_ITEM_MULTIPLE_DEVICES]

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        for(int i=0; i<mFragments.length; i++) {
            ft.hide(mFragments[i]);
        }
        ft.commit();


        String[] mDrawerItemNames = getResources().getStringArray( R.array.navigation_drawer_items_array );
        for(int i=0; i<mFragments.length; i++) {
            mDrawerItems[i] = new ObjectDrawerItem(R.drawable.ic_menu_camera, mDrawerItemNames[i]);
        }

        DrawerItemCustomAdapter adapter = new DrawerItemCustomAdapter(this, R.layout.listview_item_row, mDrawerItems);
        mDrawerList.setAdapter(adapter);

        mDrawerList.setOnItemClickListener(this);

        mTitle = mDrawerTitle = getTitle();


        mDrawerLayout.openDrawer(Gravity.LEFT, true);


        if((mBluetoothAdapter = initializeBluetooth()) == null) {
            finish();
        }
    }

    private BluetoothAdapter initializeBluetooth() {

        BluetoothAdapter mBluetoothAdapter;

        String[] requiredPermissions = {"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"};

//        requestPermissions( requiredPermissions ,1);

        // Use this check to determine whether BLE is supported on the device. Then
        // you can selectively disable BLE-related features.
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            return null;
        }
        // Initializes Bluetooth adapter.
        final BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();

        // Ensures Bluetooth is available on the device and it is enabled. If not,
        // displays a dialog requesting user permission to enable Bluetooth.
        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }
        return mBluetoothAdapter;
    }


    @Override
    public void update(Observable o, Object arg) {

        // Changes coming from KatDevices
        if(o instanceof KatDevice) {

        }
    }
}
