package com.example.mmittek.myapplication;

public enum FeedbackMode {
    FEEDBACK_MODE_OFF,
    FEEDBACK_MODE_IN,
    FEEDBACK_MODE_OUT,
}
