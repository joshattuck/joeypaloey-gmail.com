package com.example.mmittek.myapplication;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Observable;

/**
 * Created by mmittek on 3/10/2017.
 */

public class KatDevices extends Observable {

//    protected static ArrayList<KatDevice> sConnectedKatDevices = new ArrayList<KatDevice>();
    protected static HashMap<String, KatDevice> sConnectedKatDevices = new HashMap<String, KatDevice>();
    protected static KatDevices sInstance = null;

    public static KatDevices getInstance() {
        if(sInstance == null) {
            sInstance = new KatDevices();
        }
        return sInstance;
    }

    public final KatDevice getKatDeviceByMAC(String mac) {
        for(KatDevice katDevice : sConnectedKatDevices.values()) {
            if(katDevice.getMAC().equals(mac)) {
                return katDevice;
            }
        }
        return null;
    }

    public void addConnectedKatDevice(KatDevice katDevice) {
        // Mutually exclusive
        synchronized(sConnectedKatDevices) {
            sConnectedKatDevices.put(katDevice.getMAC(), katDevice);
            setChanged();
            notifyObservers();
        }
    }

    public void removeConnectedKatDevice(KatDevice katDevice) {
        synchronized (sConnectedKatDevices) {
            sConnectedKatDevices.remove(katDevice);
            setChanged();
            notifyObservers();
        }
    }

    public final KatDevice getFirstConnectedDevice() {
        return sConnectedKatDevices.get(0);
    }

    public final Collection<KatDevice> getConnectedKatDevices() {
        return sConnectedKatDevices.values();
    }
}
