package com.example.mmittek.myapplication;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;

/**
 * Created by mmittek on 4/8/2017.
 */

public class DeviceTrainingFragment  extends Fragment implements TabHost.TabContentFactory {



    @Override
    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setRetainInstance(true);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View rootView = inflater.inflate(R.layout.fragment_device_training, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView deviceMacTextView = (TextView) view.findViewById(R.id.device_mac);
        deviceMacTextView.setText("random text");
    }

    @Override
    public View createTabContent(String tag) {
        View view = getView();
        return view;
//        return null;
    }
}
