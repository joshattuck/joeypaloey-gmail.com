package com.example.mmittek.myapplication;

import android.graphics.Color;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;

public class KatStaticPosition extends Observable implements Observer {

    private static int sPositionColors[] = {
            Color.MAGENTA,
            Color.BLUE,
            Color.CYAN,
            Color.RED,
    };

    private int mID;
    private int mNumSamples;
    private boolean mActive;
    private boolean mHasData;
    private boolean mIsOn;
    private Bundle mStatistics;
    private int mColor;
    private Double mScale;
    private boolean mRecordingActive = false;
    private KatDevice mKatDevice;


    protected HashMap<String, ArrayList<Double>> mRecordedSamples;

    public KatStaticPosition(KatDevice katDevice, int i) {
        mKatDevice = katDevice;
        mColor = sPositionColors[ i%sPositionColors.length ];
        mID = i;
        reset();


    }



    public void reset() {
        reset(true);
    }

    public void reset(boolean notifyObservers) {
        mNumSamples = 0;
        mActive = false;
        mHasData = false;
        mIsOn = false;
        mScale = 1.0;

        setChanged();
        if(notifyObservers) notifyObservers();
    }


    public final boolean isRecording() {
        return mRecordingActive;
    }

    public final Double getScale() {
        return mScale;
    }

    public void setScale(Double scale) {
        if(scale != mScale) {
            mScale = scale;
            setChanged();
            notifyObservers();
        }
    }

    public final Bundle getStatistics() {
        return mStatistics;
    }

    public void setStatistics(Bundle b) {
        // Switch to off
        boolean prevMode = mIsOn;
        mIsOn = false;
        mStatistics = b;
        mHasData = true;
        setOn(prevMode);

        setChanged();
        notifyObservers();
    }

    public final boolean isOn() {
        return mIsOn;
    }

    public final int getColor() {
        return mColor;
    }

    public final boolean hasData() {
        return mHasData;
    }

    public void setOn(boolean on) {
        if(mIsOn != on) {
            mIsOn = on;
            setChanged();
            notifyObservers();
        }
    }

    public final int getID() {
        return mID;
    }

    public void setRecording(boolean active) {
        if(active) {
            startRecording();
        } else {
            stopRecording();
        }
    }



    public void startRecording() {
//        stopRecordingOnAllPositions();
        mKatDevice.stopRecordingOnAllStaticPositions();
        mRecordedSamples = new HashMap<String, ArrayList<Double>>();
        mRecordingActive = true;

        mKatDevice.getKatDataBuffer().subscribeObserverToAllDataParams(this);

        setChanged();
        notifyObservers();
    }

    public void setActive(boolean active) {
        setActive(active, true);
    }

    public void setActive(boolean active, boolean notifyObservers) {
        if(mActive != active) {
            mActive = active;
            setChanged();;
            if(notifyObservers) notifyObservers();
        }
    }

    public final boolean isActive() {
        return mActive;
    }

    public void stopRecording() {
        stopRecording(true);
    }

    public void stopRecording(boolean publishStats) {
        mKatDevice.getKatDataBuffer().unSubscribeObserverFromAllDataParams(this);

        mRecordingActive = false;   // set the flag first

        if(publishStats) {

            Bundle positionStatsBundle = new Bundle();
            positionStatsBundle.putInt("positionId", mID);

            // now calculate the stats for each parameter
            for(String paramName: mRecordedSamples.keySet()) {
                ArrayList<Double> paramSamples = mRecordedSamples.get(paramName);
                KatDataParam dataParam = mKatDevice.getKatDataBuffer().getDataParamByName(paramName);

                //Log.d("static pos", "Param " + paramName + " is angle? " + DataHub.isAngle(paramName));

                ParameterStats paramStats = ParameterStats.calculateParameterStats( paramSamples, dataParam.isAngle() );

                // Apply minimum values of parameter stats
                Float minimumVariance = (Float)mKatDevice.getKatDataBuffer().getDataParamByName( paramName ).getMinimumVariance();
//                Float minimumVariance = (Float)KatDataBuffer.getInstance().getDataParamByName( paramName ).getMinimumVariance();
                if(minimumVariance != null && minimumVariance > 0 && minimumVariance > paramStats.getVariance()) {
                    paramStats.setVariance( minimumVariance );
                }

                positionStatsBundle.putSerializable(paramName+"Stats", paramStats);
            }
//            DataHub.getInstance().dataProduced(this, "positionStats", positionStatsBundle);
            setStatistics(positionStatsBundle);

        }
        // Get rid of old stuff
        mRecordedSamples = new HashMap<String, ArrayList<Double>>();

        setChanged();
        notifyObservers();
    }

    @Override
    public void update(Observable o, Object arg) {
        if(o instanceof KatDataParam) {
            KatDataParam dataParam = (KatDataParam)o;
            if(!mRecordingActive) return;
            String paramName = dataParam.getName();
            ArrayList<Double> paramSamples = mRecordedSamples.get(paramName);
            if(paramSamples == null) {
                paramSamples = new ArrayList<Double>();
                mRecordedSamples.put(paramName, paramSamples);
            }
            Double t = Double.parseDouble(new Float( (float)dataParam.getValue() ).toString());
            paramSamples.add(t  );
        }
    }


//    public void consumeData(String name, Object data) {
//        if(!mRecordingActive )  return;     // drop when not recording
//        if( !Arrays.asList( DataHub.getDataParamNames() ).contains( name) ) return; // drop when NOT data value
////        Log.d("position " + mID, " recording " + name);
//        ArrayList<Double> paramSamples = mRecordedSamples.get(name);
//        if(paramSamples == null) {
//            paramSamples = new ArrayList<Double>();
//            mRecordedSamples.put(name, paramSamples);
//        }
//        Double t = Double.parseDouble(new Float( (float)data ).toString());
//        paramSamples.add(t  );
//    }
}
