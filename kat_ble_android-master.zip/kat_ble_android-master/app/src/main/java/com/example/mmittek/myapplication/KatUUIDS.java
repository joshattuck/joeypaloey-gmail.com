package com.example.mmittek.myapplication;

import java.util.UUID;

public class KatUUIDS {
    public static final UUID KAT_SERVICE_UUID = UUID.fromString("00000000-0000-0000-ffff-ffffffffffff");
    public static final UUID CHARACTERISTIC_CONFIG_DESRIPTOR = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    public static final UUID CHARACTERISTIC_USER_DESCRIPTION_DESCRIPTOR = UUID.fromString("00002901-0000-1000-8000-00805f9b34fb");
    public static final UUID CHARACTERISTIC_ACC_UUID = UUID.fromString("00000006-0000-0000-ffff-ffffffffffff");
    public static final UUID CHARACTERISTIC_ORIENTATION_UUID = UUID.fromString("00000008-0000-0000-ffff-ffffffffffff");
    public static final UUID CHARACTERISTIC_SONARS_UUID = UUID.fromString("00000009-0000-0000-ffff-ffffffffffff");
    public static final UUID CHARACTERISTIC_BUZZ_UUID = UUID.fromString("00000002-0000-0000-ffff-ffffffffffff");
    public static final UUID CHARACTERISTIC_VIBR_UUID = UUID.fromString("00000003-0000-0000-ffff-ffffffffffff");
    public static final UUID CHARACTERISTIC_LASX_UUID = UUID.fromString("00000004-0000-0000-ffff-ffffffffffff");
    public static final UUID CHARACTERISTIC_LASY_UUID = UUID.fromString("00000005-0000-0000-ffff-ffffffffffff");
    public static final UUID CHARACTERISTIC_EMG_UUID = UUID.fromString("0000000c-0000-0000-ffff-ffffffffffff");

    // @see: https://stackoverflow.com/questions/19539535/how-to-get-the-battery-level-after-connect-to-the-ble-device
    public static final UUID BAS_SERVICE_UUID = UUID.fromString("0000180F-0000-1000-8000-00805f9b34fb");
    public static final UUID CHARACTERISTIC_BATTERY_LEVEL_UUID = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb");


    public static UUID sSensorCharUUIDS[] = {
            CHARACTERISTIC_ACC_UUID,
            CHARACTERISTIC_ORIENTATION_UUID,
            CHARACTERISTIC_SONARS_UUID,
            CHARACTERISTIC_EMG_UUID
    };
}
