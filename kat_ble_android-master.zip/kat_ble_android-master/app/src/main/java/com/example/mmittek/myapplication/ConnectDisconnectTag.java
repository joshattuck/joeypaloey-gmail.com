package com.example.mmittek.myapplication;

public class ConnectDisconnectTag {
    public boolean connect;
    public String MAC;
}
