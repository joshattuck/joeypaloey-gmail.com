package com.example.mmittek.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.widget.SeekBar;

public class ScaleControlBar extends SeekBar {

    private Double mScale = 1.0;
    protected Paint mPaint;

    public ScaleControlBar(Context context) {
        super(context);
        init();
    }

    public ScaleControlBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ScaleControlBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public ScaleControlBar(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    protected void init() {
        mPaint = new Paint();
        setVerticalScrollbarPosition(10);
        setProgress(10);

        invalidate();
    }

    public void setScale(Double scale) {
        mScale = scale;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mPaint.reset();
        float canvasHeight = getHeight();
        float canvasWidth = getWidth();

        mPaint.setTextSize(25);
//        canvas.drawText("0",0,canvasHeight/2, mPaint);
        //canvas.drawText("10",canvasWidth*0.8f,canvasHeight/2, mPaint);

        canvas.drawText("x" + getVerticalScrollbarPosition()/10f,canvasWidth*0.5f,canvasHeight*0.4f, mPaint);

//        mPaint.setColor(Color.BLACK);
//        mPaint.setStrokeWidth(1);
//        mPaint.setStyle(Paint.Style.STROKE);

//        for (int i=0; i<100; i+=20) {
//            canvas.drawLine( i*canvasWidth/100.0f, canvasHeight/2.0f+5, i*canvasWidth/100.0f,   canvasHeight/2.0f-5,mPaint );
//        }

        //setVerticalScrollbarPosition(6);
    }

}
