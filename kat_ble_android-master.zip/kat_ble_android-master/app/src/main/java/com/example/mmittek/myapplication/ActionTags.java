package com.example.mmittek.myapplication;

public enum ActionTags {
    ACTION_TAGS_RECORD_POSITION_NUMBER,

}
