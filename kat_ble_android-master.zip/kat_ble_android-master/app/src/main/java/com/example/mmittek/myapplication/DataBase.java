package com.example.mmittek.myapplication;

import java.io.Serializable;
import java.util.Observable;

/**
 * Created by mmittek on 7/20/16.
 */
public class DataBase extends Observable implements Serializable, Comparable<DataBase> {

    protected long mTimestamp = 0;
    protected static int mDimensions = 0;
    protected boolean mIsAngle = false;

    public DataBase() {
    }

    public DataBase(long timestamp) {
        mTimestamp = timestamp;
    }

    @Override
    public String toString() {
        return "(" + mTimestamp + ")";
    }


    public float[] toArray() {
        return new float[]{};
    }

    public final long getTimestamp() {
        return mTimestamp;
    }

    public int getDimensions() {
        return mDimensions;
    }

    public final boolean isAngle() {
        return mIsAngle;
    }

    @Override
    public int compareTo(DataBase obj) {
        return (int)(mTimestamp - obj.mTimestamp);
    }

    @Override
    public boolean equals(Object o) {
        if(o instanceof DataBase) {
            DataBase comparedTo = (DataBase)o;
            if(compareTo(comparedTo) == 0) {
                return true;
            }
        }
        return false;
    }
}
