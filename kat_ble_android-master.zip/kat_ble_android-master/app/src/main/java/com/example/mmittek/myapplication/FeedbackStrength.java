package com.example.mmittek.myapplication;

import java.io.Serializable;

public class  FeedbackStrength implements Serializable {

    public static enum Strength {
        FEEDBACK_STRENGTH_OFF,
        FEEDBACK_STRENGTH_LOW,
        FEEDBACK_STRENGTH_MEDIUM,
        FEEDBACK_STRENGTH_HIGH,
    }



    public static byte FeedbackStrengthToRawData(Strength strength) {
        byte value = (byte)0;

        if(strength == Strength.FEEDBACK_STRENGTH_LOW) {
            value = (byte)2;
        } else if(strength == Strength.FEEDBACK_STRENGTH_MEDIUM) {
            value = (byte)5;
        } else if(strength == Strength.FEEDBACK_STRENGTH_HIGH) {
            value = (byte)3;
        }

        return value;
    }

    public static byte[] FeedbackStrengthToRawDataArr(Strength strength) {
        return new byte[] { FeedbackStrengthToRawData(strength) };
    }

}
