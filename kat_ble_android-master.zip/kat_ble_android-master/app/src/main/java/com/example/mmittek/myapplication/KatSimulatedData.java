package com.example.mmittek.myapplication;

import android.os.Handler;

import org.apache.commons.math3.distribution.NormalDistribution;

/**
 * Created by mmittek on 7/21/16.
 */
public class KatSimulatedData  extends KatData implements Runnable {

    public KatSimulatedData(Handler contextHandler) {
        super(contextHandler);
    }

    public void startSimulation() {
        Thread t = new Thread(this);
        t.start();
    }


    @Override
    public void run() {
        Data3D accelerometerData;

        NormalDistribution gaussian = new NormalDistribution(0, 10);
        long t = 0;
        while(true) {

            accelerometerData = new Data3D(t, (float)gaussian.sample(), (float)gaussian.sample(), (float)gaussian.sample());
//            sendMessage(KatDataMessageType.KAT_DATA_MESSAGE_TYPE_ACC.ordinal(), accelerometerData);
            sendMessage(KatMessageType.KAT_MESSAGE_TYPE_NEW_ACCELEROMETER_DATA.ordinal(), accelerometerData);

            Thread.yield();
            try {
                Thread.sleep(100);
                t+=100;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

}
