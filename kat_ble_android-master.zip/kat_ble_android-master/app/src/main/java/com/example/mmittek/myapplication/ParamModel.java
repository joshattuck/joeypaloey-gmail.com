package com.example.mmittek.myapplication;

/**
 * Created by mmittek on 9/26/16.
 */
public class ParamModel {

    protected String mName;
    float mValue = 0;

    public ParamModel(String name) {
        mName = name;
        mValue = 0;
    }


}
