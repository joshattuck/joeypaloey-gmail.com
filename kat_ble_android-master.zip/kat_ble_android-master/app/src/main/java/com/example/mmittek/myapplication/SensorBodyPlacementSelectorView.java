package com.example.mmittek.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by mmittek on 9/25/16.
 */
public class SensorBodyPlacementSelectorView extends View {


    protected Paint mPaint;

    public SensorBodyPlacementSelectorView(Context context) {
        super(context);
        init();

    }

    public SensorBodyPlacementSelectorView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();

    }

    public SensorBodyPlacementSelectorView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();

    }

    public SensorBodyPlacementSelectorView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();

    }

    protected void init() {
        mPaint = new Paint();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float canvasHeight = getHeight();
        float canvasWidth = getWidth();

        // outline
        mPaint.setColor(Color.LTGRAY);
        mPaint.setStrokeWidth(5);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(0,0,canvasWidth,canvasHeight, mPaint);


    }

}
