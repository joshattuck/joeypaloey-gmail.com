package com.example.mmittek.myapplication;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

/**
 * Created by mmittek on 10/9/16.
 */

public class StorageFragment extends Fragment implements View.OnClickListener, Observer {


    protected Button            mAddMarkerButton;
    protected ToggleButton      mStorageToggleButton;
    protected TextView          mStorageFileNameTextView;
    protected FileStorageModel  mStorage;
    protected boolean           mHeaderWritten = false;
    protected EditText          mRecordNameEditText;
    protected BufferedWriter    mBufferedWriter;
    protected int               mCurrentMarker = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_storage, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        //mKatDataBuffer = KatDataBuffer.getInstance();



        mAddMarkerButton            = (Button)view.findViewById(R.id.raw_data_add_marker_button);
        mAddMarkerButton.setOnClickListener(this);

        mStorageToggleButton        = (ToggleButton)view.findViewById(R.id.raw_data_storage_toggle_button);
        mStorageFileNameTextView    = (TextView)view.findViewById(R.id.raw_data_storage_file_name_text_view);

        mStorageToggleButton.setChecked(false);
        mStorageToggleButton.setOnClickListener(this);

        mRecordNameEditText = (EditText)view.findViewById(R.id.raw_data_storage_record_name_edit_text);

    }

    protected boolean startStorage() {
        mCurrentMarker = 0;

        //mRecordNameEditText.setText(mStorage.getFileName());
        mRecordNameEditText.setEnabled(false);
        String recordName = mRecordNameEditText.getText().toString();


        // Create storage
        try {
            mStorage = Storage.getFileStorageWithPostfix(getContext(), recordName);
            if (!mStorage.open()) return false;
            mBufferedWriter = new BufferedWriter(new FileWriter(mStorage.getFile()));
        }catch(IOException e) {
            return false;
        }

        mStorageFileNameTextView.setText( "Storing to: " + mStorage.getFileName() );

        mHeaderWritten = false;


        // Get all connected devices now
        for(KatDevice device : KatDevices.getInstance().getConnectedKatDevices()) {
            device.getKatDataBuffer().setMarker(mCurrentMarker);
            device.getKatDataBuffer().addObserver(this);
        }


        mAddMarkerButton.setText("Add marker 1");
        mAddMarkerButton.setEnabled(true);




//        DataHub.getInstance().addConsumer(this);
        return true;
    }

    protected void stopStorage() {
//        DataHub.getInstance().removeConsumer(this);

        // Remove observer from all connected devices
        for(KatDevice device : KatDevices.getInstance().getConnectedKatDevices()) {
            device.getKatDataBuffer().deleteObserver(this);
        }


        if(mStorage != null) {
            mStorageFileNameTextView.setText( "Stored to: " + mStorage.getFileName());
            mAddMarkerButton.setEnabled(false);

            try {
                mBufferedWriter.flush();
                mBufferedWriter.close();
                mBufferedWriter = null;
            }catch(IOException e) {
            }
            mStorage.close();
            mStorage = null;

            mRecordNameEditText.setEnabled(true);
        }
    }

    @Override
    public void onClick(View view) {

        if(view == mStorageToggleButton) {
            boolean state = !mStorageToggleButton.isChecked();
            if(state) {
                stopStorage();
            } else {
                startStorage();
            }
            view.invalidate();
        }

        if(view == mAddMarkerButton) {
            mCurrentMarker++;

            for(KatDevice device : KatDevices.getInstance().getConnectedKatDevices()) {
                device.getKatDataBuffer().setMarker(mCurrentMarker);
            }

            mAddMarkerButton.setText("Add marker " + (mCurrentMarker+1));
            Log.d("storage fragment", "Adding marker: " +mCurrentMarker);
        }

    }

    @Override
    public void update(Observable observable, Object o) {
        try {
            if (observable instanceof  KatDataBuffer) {
                KatDataBuffer katDataBuffer = (KatDataBuffer) observable;
                if (!mHeaderWritten) {
                    String header = katDataBuffer.getCSVHeader();
                    mBufferedWriter.write(header);
                    mHeaderWritten = true;

                }
                String record = katDataBuffer.getCSVRecord();
                mBufferedWriter.write( record );
            }
        }catch(IOException e){
            Log.d("raw data fragment", e.getMessage());
        }
    }

}
