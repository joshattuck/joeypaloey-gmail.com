package com.example.mmittek.myapplication;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

class StoredFileInfo extends Observable{

    protected File mFile;
    protected boolean mSelected;

    public StoredFileInfo(File file) {
        mSelected = false;
        mFile = file;
    }

    public void setSelected(boolean selected) {
        mSelected = selected;
        setChanged();
        notifyObservers();
    }

    public final File getFile() {
        return mFile;
    }

    public final boolean isSelected() {
        return mSelected;
    }
}



class StoredFilesListViewAdapter extends BaseAdapter implements View.OnClickListener {
    protected int mLayoutElement;
    ArrayList<StoredFileInfo> mStoredFileInfoCollection;
  //  File[] mStoredFilesCollection;


    public StoredFilesListViewAdapter(Context context, int layoutElement, File[] storedFiles) {
        mLayoutElement = layoutElement;
        mStoredFileInfoCollection = new ArrayList<StoredFileInfo>();
        final StoredFilesListViewAdapter me = this;

        Observer itemsObserver = new Observer() {
            @Override
            public void update(Observable observable, Object o) {
                me.notifyDataSetChanged();
            }
        };


        for(File file : storedFiles) {
            StoredFileInfo storedFileInfo = new StoredFileInfo(file);
            storedFileInfo.addObserver(itemsObserver);
            mStoredFileInfoCollection.add( storedFileInfo );
        }

    }

    public StoredFileInfo[] getSelectedFileInfoArray() {
        ArrayList<StoredFileInfo> selectedFileInfoCollection = new ArrayList<StoredFileInfo>();
        for( StoredFileInfo storedFileInfo : mStoredFileInfoCollection ) {
            if(storedFileInfo.isSelected()) {
                selectedFileInfoCollection.add( storedFileInfo );
            }
         }

        StoredFileInfo[] retArray = new StoredFileInfo[selectedFileInfoCollection.size()];
        selectedFileInfoCollection.toArray( retArray );
        return retArray;
    }

        @Override
    public int getCount() {
            return mStoredFileInfoCollection.size();
            //return mStoredFileNamesCollection.length;
    }

    @Override
    public StoredFileInfo getItem(int i) {
        return mStoredFileInfoCollection.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        final View result;
        if (view == null) {
            result = LayoutInflater.from(viewGroup.getContext()).inflate(mLayoutElement, viewGroup, false);
        } else {
            result = view;
        }

        StoredFileInfo storedFileInfo = getItem(i);
        File file = storedFileInfo.getFile();


        CheckBox fileSectionCheckBox = (CheckBox)result.findViewById(R.id.records_file_item_check_box);
        fileSectionCheckBox.setTag( storedFileInfo );
        fileSectionCheckBox.setOnClickListener(this);


        TextView fileSizeTextView = (TextView)result.findViewById(R.id.records_file_item_file_size);
        fileSizeTextView.setText( String.format("%.1fkB", file.length()/1024.0f )  );

        TextView fileNameTextView = (TextView)result.findViewById(R.id.records_file_item_file_name);
        fileNameTextView.setText( file.getName() );
        return result;
    }

    @Override
    public void onClick(View view) {
        // It has to be one of the items checkboxes
        if(view instanceof CheckBox && view.getTag() instanceof StoredFileInfo ) {
            ((StoredFileInfo)view.getTag()).setSelected( ((CheckBox)view).isChecked()  );
        }
    }
}

/**
 * Created by mmittek on 10/5/16.
 */
public class RecordsFragment extends Fragment implements View.OnClickListener  {

    protected ListView mStoredFilesListView;
    protected StoredFilesListViewAdapter mStoredFilesListViewAdapter;
    protected View mFileListViewHeader;
    protected Button mDeleteSelectedButton;
    protected Button mShareSelectedButton;
    protected Button mRefreshButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_records, container, false);
        mFileListViewHeader = inflater.inflate(R.layout.records_file_list_header, container, false);
        mFileListViewHeader.setOnClickListener(this);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        mRefreshButton = (Button)mFileListViewHeader.findViewById(R.id.records_refresh_button);
        mRefreshButton.setOnClickListener(this);

        mDeleteSelectedButton = (Button)mFileListViewHeader.findViewById(R.id.records_delete_selected_button);
        mDeleteSelectedButton.setOnClickListener(this);

        mShareSelectedButton = (Button)mFileListViewHeader.findViewById(R.id.records_share_button);
        mShareSelectedButton.setOnClickListener(this);

        mStoredFilesListView = (ListView) view.findViewById(R.id.records_stored_files_list_view);
        mStoredFilesListView.addHeaderView(mFileListViewHeader);
        refreshStoredFilesList();
    }


    protected void refreshStoredFilesList() {
//        String[] storedFilesArray = Storage.getStoredFileNames(getContext());

        File[] storedFilesArray = Storage.getStoredFiles(getContext());

        mStoredFilesListViewAdapter = new StoredFilesListViewAdapter(getContext(),R.layout.records_file_list_item, storedFilesArray );
        mStoredFilesListView.setAdapter( mStoredFilesListViewAdapter );
        this.getView().invalidate();

    }


    @Override
    public void onClick(View view) {

        if(view == mRefreshButton) {
            refreshStoredFilesList();
        }

        if(view == mDeleteSelectedButton) {
            StoredFileInfo[] storeFileInfos = mStoredFilesListViewAdapter.getSelectedFileInfoArray();
            if(storeFileInfos.length > 0) {
                for(StoredFileInfo fileInfo : storeFileInfos) {
                    fileInfo.getFile().delete();
//                    File file = new File( getContext().getFilesDir(), fileInfo.getFileName() );
                }
            }
            refreshStoredFilesList();
        }

        // using http://stackoverflow.com/questions/17985646/android-sharing-files-by-sending-them-via-email-or-other-apps
        if(view == mShareSelectedButton) {
            StoredFileInfo[] storeFileInfos = mStoredFilesListViewAdapter.getSelectedFileInfoArray();
            if( storeFileInfos.length > 0 ) {

                // Create list of Uris for the selected files
                ArrayList<Uri> filesToSend = new ArrayList<Uri>();
                for( StoredFileInfo storeFileInfo : storeFileInfos ) {
                    File file = storeFileInfo.getFile();
//                    File file = new File(getContext().getFilesDir(), storeFileInfo.getFileName() );
                    if(file.exists() && file.canRead()) {
                        File exFile = FileStorageModel.writeToExternal(getContext(), file.getName() );
                        exFile.deleteOnExit();
                        filesToSend.add( Uri.parse("file://" + exFile.getAbsolutePath()) );
                    }
                }

                if(filesToSend.size() > 0) {
                    Intent sendIntent = new Intent();
                    sendIntent.setAction(Intent.ACTION_SEND_MULTIPLE);
                    sendIntent.putExtra(Intent.EXTRA_STREAM, filesToSend);
                    sendIntent.putExtra(Intent.EXTRA_SUBJECT, "KAT Records");
                    sendIntent.setType("text/csv");
                    startActivity(Intent.createChooser(sendIntent, getResources().getText(R.string.string_send_to)));
                }
            }
        }
    }
}
