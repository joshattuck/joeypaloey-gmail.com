package com.example.mmittek.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;

import java.util.Collection;
import java.util.Observable;
import java.util.Observer;

/**
 * Created by mmittek on 3/9/2017.
 */


class DevicesListAdapter extends BaseAdapter implements Observer {
    protected Context mContext;
    protected Collection<KatDevice> mKatDevicesCollection;
    protected int mLayoutElementId;

    public DevicesListAdapter(Context context, int layoutElementId, Collection<KatDevice> katDevices) {
        mContext = context;
        mLayoutElementId = layoutElementId;
        mKatDevicesCollection = katDevices;


    }

    @Override
    public int getCount() {
        return mKatDevicesCollection.size();
    }

    @Override
    public Object getItem(int position) {
        int i=0;
        for(KatDevice katDevice : mKatDevicesCollection) {
            if(i == position) return katDevice;
            i++;
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        final View result;
        if (view == null) {
            result = LayoutInflater.from(viewGroup.getContext()).inflate(mLayoutElementId, viewGroup, false);
        } else {
            result = view;
        }

            KatDevice displayedKatDevice = (KatDevice) getItem(position);
            Button katDeviceButton = (Button)result.findViewById(R.id.list_item_device_mac_button_button);
            katDeviceButton.setText( "Configure " + displayedKatDevice.getMAC() );
            katDeviceButton.setTag(displayedKatDevice);
        return result;
    }

    @Override
    public void update(Observable o, Object arg) {
        notifyDataSetChanged();
    }
}

public class MultipleDevicesFragment extends Fragment  {

    protected ListView mDevicesListView;
    protected DevicesListAdapter mDeviceListAdapter;

    public MultipleDevicesFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setRetainInstance(true);

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View rootView = inflater.inflate(R.layout.fragment_multiple_devices, container, false);

        return rootView;
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mDevicesListView = (ListView) view.findViewById(R.id.multiple_devices_fragment_devices_list_view);
        DevicesListAdapter adapter = new DevicesListAdapter(getContext(), R.layout.list_item_device_mac_button, KatDevices.getInstance().getConnectedKatDevices());
        mDevicesListView.setAdapter(adapter);
        KatDevices.getInstance().addObserver( adapter );

    }

}
