package com.example.mmittek.myapplication;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;


class KatDataParam<T> extends Observable {
    protected T         mValue;
    protected String    mName;
    protected boolean   mIsAngle;
    protected T         mMinimumVariance;

    public KatDataParam(String name, T defaultValue) {
        mName = name;
        mValue = defaultValue;
        mIsAngle = false;
        mMinimumVariance = null;
    }

    public final boolean isAngle() {
        return mIsAngle;
    }

    public KatDataParam(String name, T defaultValue, boolean isAngle) {
        mName = name;
        mValue = defaultValue;
        mIsAngle = isAngle;
        mMinimumVariance = null;
    }

    public KatDataParam(String name, T defaultValue, boolean isAngle, T minimumVariance) {
        mName = name;
        mValue = defaultValue;
        mIsAngle = isAngle;
        mMinimumVariance = minimumVariance;
    }

    public void setValue(T newValue) {
        if(!newValue.equals(mValue)) {
            mValue = newValue;
            setChanged();
            notifyObservers();
        }
    }


    public final T getMinimumVariance() {
        return mMinimumVariance;
    }

    public final T getValue() {
        return mValue;
    }

    public final String getName() {
        return mName;
    }

    @Override
    public final String toString() {
        return mName + "=" + mValue;
    }
}

public class KatDataBuffer extends Observable implements Observer, Serializable {

    protected KatDevice mKatDevice;

    // Acceleration
    protected final KatDataParam<Float> mAccelX = new KatDataParam<Float>("accelX", 0.0f, false, 0.1f);
    protected final KatDataParam<Float> mAccelY = new KatDataParam<Float>("accelY", 0.0f, false, 0.1f);
    protected final KatDataParam<Float> mAccelZ = new KatDataParam<Float>("accelZ", 0.0f, false, 0.1f);

    // Angles - orientation
    protected final KatDataParam<Float> mAngleX = new KatDataParam<Float>("angleX", 0.0f, true, 1.0f);
    protected final KatDataParam<Float> mAngleY = new KatDataParam<Float>("angleY", 0.0f, true, 1.0f);
    protected final KatDataParam<Float> mAngleZ = new KatDataParam<Float>("angleZ", 0.0f, true, 1.0f);

    // Distance (from sonars)
    protected final KatDataParam<Float> mDistanceX = new KatDataParam<Float>("distanceX", 0.0f, false, 3.0f);
    protected final KatDataParam<Float> mDistanceY = new KatDataParam<Float>("distanceY", 0.0f, false, 3.0f);

    // EMG
    protected final KatDataParam<Float> mEMG = new KatDataParam<Float>("emg", 0.0f, false, 0.1f);


    protected ArrayList<KatDataParam> mDataParamsCollection;

    protected Integer mMarker = 0;

    public final KatDataParam<Float> getAccelX() {
        return mAccelX;
    }
    public final KatDataParam<Float> getAccelY() {
        return mAccelY;
    }
    public final KatDataParam<Float> getAccelZ() {
        return mAccelZ;
    }
    public final KatDataParam<Float> getAngleX() {
        return mAngleX;
    }
    public final KatDataParam<Float> getAngleY() {
        return mAngleY;
    }
    public final KatDataParam<Float> getAngleZ() {
        return mAngleZ;
    }
    public final KatDataParam<Float> getDistanceX() {
        return mDistanceX;
    }
    public final KatDataParam<Float> getDistanceY() {
        return mDistanceY;
    }
    public final KatDataParam<Float> getEMG() {
        return mEMG;
    }

    protected KatDataBuffer(KatDevice katDevice) {

        mKatDevice = katDevice;

        // Create the collection
        mDataParamsCollection = new ArrayList<KatDataParam>();

        mDataParamsCollection.add(mAccelX);
        mDataParamsCollection.add(mAccelY);
        mDataParamsCollection.add(mAccelZ);
        mDataParamsCollection.add(mAngleX);
        mDataParamsCollection.add(mAngleY);
        mDataParamsCollection.add(mAngleZ);
        mDataParamsCollection.add(mDistanceX);
        mDataParamsCollection.add(mDistanceY);

        // Add all the observers
        mAccelX.addObserver(this);
        mAccelY.addObserver(this);
        mAccelZ.addObserver(this);
        mAngleX.addObserver(this);
        mAngleY.addObserver(this);
        mAngleZ.addObserver(this);
        mDistanceX.addObserver(this);
        mDistanceY.addObserver(this);

        // Add feedback generator observer
        mKatDevice.getFeedbackGenerator().addObserver(this);
    }

    public final String[] getDataParamNames() {
        String[] names = new String[mDataParamsCollection.size()];
        int i=0;
        for(KatDataParam dataParam : mDataParamsCollection) {
            names[i++] = dataParam.getName();
        }
        return names;
    }

    public final KatDataParam getDataParamByName(String name) {
        for(KatDataParam dataParam: mDataParamsCollection) {
            if(dataParam.getName().equals(name)) {
                return dataParam;
            }
        }
        return null;
    }

    public void setMarker(int newMarker) {
        if(mMarker != newMarker)  {
            mMarker = newMarker;
            setChanged();
            notifyObservers();
        }
    }


    public boolean subscribeObserverToAllDataParams(Observer observer) {
        for(KatDataParam dataParam : mDataParamsCollection) {
            dataParam.addObserver(observer);
        }
        return true;
    }

    public boolean unSubscribeObserverFromAllDataParams(Observer observer) {
        for(KatDataParam dataParam : mDataParamsCollection) {
            dataParam.deleteObserver(observer);
        }
        return true;
    }


    public boolean subscribeObserverToDataParamByName(Observer observer, String paramName) {
        KatDataParam dataParam = getDataParamByName(paramName);
        if(dataParam == null) return false;
        dataParam.addObserver( observer );
        return true;
    }

    @Override
    public void update(Observable observable, Object o) {
        // This observer will be tracking the changes in the data values
        setChanged();
        notifyObservers();
    }

    public final String getCSVHeader() {
        String csvHeader = "datetime,millis,device,accelX,accelY,accelZ,angleX,angleY,angleZ,distanceX,distanceY,marker,feedback_mode,position\r\n";
        return csvHeader;
    }

    protected final String getHumanReadableFeedbackMode(int feedbackMode) {
        if(feedbackMode == FeedbackMode.FEEDBACK_MODE_OFF.ordinal()) {
            return "off";
        } else if(feedbackMode == FeedbackMode.FEEDBACK_MODE_IN.ordinal()) {
            return "in";
        } else {
            return "out";
        }
    }

    protected final String getHumanReadablePosition(Integer positionCode) {
        if(positionCode == -1) {
            return "none";
        } else {
            return positionCode.toString();
        }
    }

    public final String getCSVRecord() {
        String csvRecord = Utils.getCurrentTimestampString() + "," +
                System.currentTimeMillis() + "," +
                mKatDevice.getMAC() + ", " +
                mAccelX.getValue() + "," +
                mAccelY.getValue() + "," +
                mAccelZ.getValue() + "," +
                mAngleX.getValue() + "," +
                mAngleY.getValue() + "," +
                mAngleZ.getValue() + "," +
                mDistanceX.getValue() + "," +
                mDistanceY.getValue() + "," +
                mMarker + "," +
//                mFeedbackGenerator.getFeedbackMode() + "," +
                getHumanReadableFeedbackMode(mKatDevice.getFeedbackGenerator().getFeedbackMode()) + "," +
//                mFeedbackGenerator.getCurrentlyInPosition() +
                getHumanReadablePosition(mKatDevice.getFeedbackGenerator().getCurrentlyInPosition()) +
                "\r\n";
        return csvRecord;
    }


}
