package com.example.mmittek.myapplication;

import android.os.Bundle;

/**
 * Created by mmittek on 9/25/16.
 */

/**
 * These settings will be stored in a database of some sort but hardcoded for now
 */
public class BodyPlacementSettingsFactory {


    public static Bundle getParamsForBodyPlacement(String placement) {
        placement = placement.toLowerCase();    // normalize to lower case

        if( placement.equals("any") ) {
            return getParamsForFullView();
        } else if( placement.equals("chest") ) {
            return getParamsForBodyPlacementChest();
        } else if(placement.equals("hip")) {
            return getParamsForBodyPlacementHip();
        } else if(placement.equals("thigh")) {
            return getParamsForBodyPlacementThigh();
        } else if(placement.equals("waist")) {
            return getParamsForBodyPlacementWaist();
        }

        // Empty bundle if not available
        Bundle b = new Bundle();
        return b;
    }

    protected static Bundle getParamsForFullView() {
        Bundle b = new Bundle();
        b.putString("description", "Full view for random body placement");
        b.putStringArray("params", new String[]{"accelX","accelY","accelZ","angleX","angleY", "angleZ","distanceX","distanceY","emg"});
        b.putBoolean("paramsScrollbarsPresent", true);
        return b;
    }


    protected static Bundle getParamsForBodyPlacementChest() {
        Bundle b = new Bundle();
        b.putString("description", "On chest, sonar pointed up and left");
        b.putStringArray("params", new String[]{"angleZ"});
        b.putBoolean("paramsScrollbarsPresent", false);
        return b;
    }

    protected static Bundle getParamsForBodyPlacementHip() {
        Bundle b = new Bundle();
        b.putString("description", "Sonar pointed up, and rear, on right hip");
        b.putStringArray("params", new String[]{"accelX","accelY","angleY", "angleZ"});
        b.putBoolean("paramsScrollbarsPresent", true);
        return b;
    }
    protected static Bundle getParamsForBodyPlacementThigh() {
        Bundle b = new Bundle();
        b.putString("description", "Sonar pointed down, and right, on back waistband");
        b.putStringArray("params", new String[]{"angleY", "angleZ","emg"});
        b.putBoolean("paramsScrollbarsPresent", true);
        return b;
    }
    protected static Bundle getParamsForBodyPlacementWaist() {
        Bundle b = new Bundle();
        b.putString("description", "Sonar pointed down, and right, on back waistband");
        b.putStringArray("params", new String[]{"angleY", "angleZ", "distanceX"});
        b.putBoolean("paramsScrollbarsPresent", true);
        return b;
    }

}
