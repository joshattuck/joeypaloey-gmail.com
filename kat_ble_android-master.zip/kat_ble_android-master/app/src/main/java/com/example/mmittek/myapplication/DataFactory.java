package com.example.mmittek.myapplication;

/**
 * Created by mmittek on 7/22/16.
 */
public class DataFactory {

    public static DataBase create(byte[] data) {
        if(data.length == 8) {
            return new Data1D(data);
        } else if(data.length == 12) {
            return new Data2D(data);
        } else if(data.length == 16) {
            return new Data3D(data);
        }
        return null;
    }

}
