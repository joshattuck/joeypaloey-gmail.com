package com.example.mmittek.myapplication;

import android.content.Context;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;

public class ParamViewBase extends View implements View.OnClickListener, Observer {

    protected KatStaticPosition[] mPositions;
    protected String[] mExpectedStatisticNames;
    protected Paint mPaint;
    protected boolean mDrawPositions;
    protected HashSet<KatStaticPosition> myPositions;
    protected FeedbackMode mFeedbackMode;
    protected HashMap<String, Float> mParamFeedbackScales;
    protected float mParamFeedbackScale = 1.0f;
    protected String mDescription = null;
    protected Float mGlobalToleranceScale = 1.0f;
    protected float mTextSize = 30;


    protected String mParamName = null;

    public ParamViewBase(Context context) {
        super(context);
        init();
    }

    public ParamViewBase(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ParamViewBase(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public ParamViewBase(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    public final String getParamName() {
        return mParamName;
    }

    public void setParamFeedbackScales(HashMap<String, Float> feedbackScales) {
        mParamFeedbackScales = feedbackScales;
    }

    public void setParamFeedbackScale(float scale) {
        mParamFeedbackScale = scale;
        invalidate();
    }

    public final boolean getDrawPositions() {
        return mDrawPositions;
    }

    public void setDrawPositions(boolean draw) {
        mDrawPositions = draw;
        invalidate();
    }

    public void toggleDrawPositions() {
        mDrawPositions = !mDrawPositions;
        invalidate();
    }

    public void clearPositions() {
        mPositions = null;
    }

    public void setPositions(KatStaticPosition[] positions) {
        mPositions = positions;
    }
    public void setExpectedStatNames(String[] statNames) {
        mExpectedStatisticNames = statNames;
    }

    public void setDescription(String desc) {
        mDescription = desc;
    }

    public void setParamName(final String paramName) {
        mParamName = paramName;
    }

    public final String[] getExpectedStatisticNames() {
        return mExpectedStatisticNames;
    }

    private void init() {
        mPaint = new Paint();
        mDrawPositions = true;
        myPositions = new HashSet<KatStaticPosition>();
        this.setOnClickListener(this);

    }


    public void setFeedbackMode(FeedbackMode mode) {
        mFeedbackMode = mode;
    }

    public final FeedbackMode getFeedbackMode() {
        return mFeedbackMode;
    }

    protected void newDataValue(float value) {
        // should be overriden by subclass
    }

    @Override
    public void onClick(View view) {
        toggleDrawPositions();
    }


//    public void consumeData(String name, Object data) {
//        // New data to display
//        if( mParamName != null && mParamName.equals(name) &&  data instanceof Float) newDataValue((float)data);
//
//
//        if( name.equals(mParamName+"Enabled") ) {
//            setDrawPositions((boolean)data);
//        }
//
//        if(name.equals("globalToleranceScale")) {
//            mGlobalToleranceScale = (float)data;
//        }
//
//        if(name.equals("positionStatus") && data instanceof KatStaticPosition) {
//            KatStaticPosition position = (KatStaticPosition)data;
//
//            if(position.isOn()) {
//                myPositions.add(position);
//            } else {
//                myPositions.remove(position);
//            }
//
//        }
//    }


    @Override
    public void update(Observable observable, Object o) {
        if(observable instanceof FeedbackGenerator) {
            mParamFeedbackScale = ((FeedbackGenerator)observable).getParamToleranceScale(mParamName);
            invalidate();
        }

        if(observable instanceof KatStaticPosition) {
            KatStaticPosition position = (KatStaticPosition)observable;
            if(position.isActive()) {
                myPositions.add(position);
            } else {
                myPositions.remove(position);
            }
            invalidate();
        }

        if(observable instanceof KatDataParam) {
            KatDataParam dataParam = (KatDataParam)observable;
            Object value = dataParam.getValue();
            if(value instanceof  Float) {
                newDataValue( (Float)value );
            }
        }

    }

}
