package com.example.mmittek.myapplication;


import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class KatData {

    public Handler mContextHandler;


    public KatData(Handler contextHandler) {
        mContextHandler = contextHandler;
    }

    public void newAccelerometerData(long t, float x, float y, float z) {
//        CircularFifoQueue queue = new CircularFifoQueue
    }

    protected void sendMessage(KatMessageType msgType, DataBase data) {
        sendMessage(msgType.ordinal(), data);
    }

    protected void sendMessage(int what, DataBase data) {
        Message m = new Message();
        Bundle b = new Bundle();
        b.putFloatArray("data", data.toArray());
        m.setData(b);
        m.what = what;
        m.obj = this;
        mContextHandler.sendMessage(m);
    }
}
