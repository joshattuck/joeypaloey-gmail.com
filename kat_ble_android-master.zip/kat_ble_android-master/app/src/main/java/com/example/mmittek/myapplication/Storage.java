package com.example.mmittek.myapplication;

import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;



public class Storage extends Observable implements Observer, AutoCloseable {


    public enum StorageType {
        STORAGE_FILE,
    }

    protected Context mContext;
    protected StorageType mType;
    protected Storage(Context context) {
        mContext = context;
    }

    public boolean open() {
        return true;
    }

    @Override
    public void close() {

    }

    public static String[] getStoredFileNames(Context context) {
        File filesDir = context.getFilesDir();
        return filesDir.list();
    }

    public static File[] getStoredFiles(Context context) {
        File filesDir = context.getFilesDir();
        String[] fileNames = filesDir.list();
        File[] files = new File[ fileNames.length ];
        for(int i=0; i<fileNames.length; i++) {

            File file = new File( context.getFilesDir(), fileNames[i] );
            files[i] = file;

        }
        return files;
    }

    public static FileStorageModel getFileStorage(Context context, String filename) {
        FileStorageModel storage = new FileStorageModel(context, filename);
        return storage;
    }
    public static FileStorageModel getFileStorage(Context context) {
        FileStorageModel storage = new FileStorageModel(context);
        return storage;
    }

    public static FileStorageModel getFileStorageWithPostfix(Context context, String postfix) {
        String filename = FileStorageModel.getDefaultFileName(postfix);
        FileStorageModel storage = new FileStorageModel(context, filename);
        return storage;
    }



    @Override
    public void update(Observable observable, Object o) {

    }
}
