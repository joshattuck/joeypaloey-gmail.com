package com.example.mmittek.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.HashMap;


public class TrainingFragment extends Fragment implements View.OnClickListener, SeekBar.OnSeekBarChangeListener {

    protected TriStateToggleButton mFeedbackToggleButton;
    protected ToggleButton mAcousticFeedbackToggleButton;
    protected ToggleButton mKineticFeedbackToggleButton;
    protected ToggleButton mLaserDiodesToggleButton;
    protected ScaleControlBar mGlobalToleranceScaleBar;
    protected HashMap<String, View> mViews = new HashMap<String, View>();
    protected KatDevice mKatDevice = null;
    protected ListView mPositionsListView;
    protected Context mContext;

    public void setKatDevice(KatDevice katDevice) {
        mKatDevice = katDevice;


        // Add positions view
        KatStaticPositionsAdapter adapter = new KatStaticPositionsAdapter(mContext, R.layout.static_positions_item, mKatDevice.getAllPositions());
        mPositionsListView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    public void applySettings(Bundle settings) {
        LayoutInflater layoutInflater = getLayoutInflater(null);
        GridLayout layout=  (GridLayout)getView().findViewById(R.id.training_layout);
        layout.removeAllViews();

        mViews = new HashMap<String, View>();

        String[] params = settings.getStringArray("params");
        String description = settings.getString("description");
        boolean paramsScrollbarsPresent = settings.getBoolean("paramsScrollbarsPresent");
        if(params == null || params.length == 0 || description == null || description.length() == 0) return;

        Log.d("custom", "non empty!");

        // Description on top
        ((TextView)getView().findViewById(R.id.training_description)).setText(description);

        int index = 0;
        for(int i=0; i<params.length; i++) {
            View v = null;
            GridLayout.Spec rowSpan = GridLayout.spec(GridLayout.UNDEFINED, 1);
            GridLayout.Spec colspan = GridLayout.spec(GridLayout.UNDEFINED, 1);


            if(params[i].equals("accelX") || params[i].equals("accelY") || params[i].equals("accelZ")  ) {
                ViewGroup vg = (ViewGroup) layoutInflater.inflate(R.layout.acceleration_plot_with_slider, layout, false);
                AccBarPlot ap = (AccBarPlot)vg.getChildAt(0);
                mViews.put(params[i], ap);
                ScaleControlBar scaleBar = (ScaleControlBar)vg.getChildAt(1);
                ap.setDescription(params[i]);
                ap.setParamName(params[i]);
                ap.setOnClickListener(this);
//                ap.setPara
//                ap.subscribeToDataHubParam(params[i]);

                if(mKatDevice != null) {
                    mKatDevice.getKatDataBuffer().subscribeObserverToDataParamByName(ap, params[i]);
                    mKatDevice.subsribeObserverToAllPositions(ap);
                    ap.setDrawPositions( mKatDevice.getFeedbackGenerator().isParamUsedForFeedback(params[i]) );

//                    mKatDevice.sub
                }

                v = vg;
                // All those inflated views have slidebars as child #1
                if(paramsScrollbarsPresent) {
                    scaleBar.setTag( params[i] );
                    scaleBar.setOnSeekBarChangeListener(this);

                    loadStateOfScaleBarFromFeedbackParams(scaleBar, params[i]);


                } else {
                    vg.removeViewAt(1);

                }
            } else if(params[i].equals("angleX") || params[i].equals("angleY") || params[i].equals("angleZ")) {
                ViewGroup vg = (ViewGroup) layoutInflater.inflate(R.layout.angle_plot_with_slider, layout, false);
                AnglePlot ap = (AnglePlot)vg.getChildAt(0);
                mViews.put(params[i], ap);
                ScaleControlBar scaleBar = (ScaleControlBar)vg.getChildAt(1);
                ap.setDescription(params[i]);
                ap.setParamName(params[i]);
                ap.setOnClickListener(this);

                if(mKatDevice != null) {
                    mKatDevice.getKatDataBuffer().subscribeObserverToDataParamByName(ap, params[i]);
                    mKatDevice.subsribeObserverToAllPositions(ap);
                    ap.setDrawPositions( mKatDevice.getFeedbackGenerator().isParamUsedForFeedback(params[i]) );


                }
//                ap.subscribeToDataHubParam(params[i]);
                v = vg;
                // All those inflated views have slidebars as child #1
                if(paramsScrollbarsPresent) {
                    scaleBar.setTag( params[i] );
                    scaleBar.setOnSeekBarChangeListener(this);

                    loadStateOfScaleBarFromFeedbackParams(scaleBar, params[i]);


//                    scaleBar.setProgress(60);
//                    scaleBar.set
//                    scaleBar.setVerticalScrollbarPosition(50);
//                    scaleBar.invalidate();
                } else {
                    vg.removeViewAt(1);
                }
            } else if(params[i].equals("distanceX") || params[i].equals("distanceY") || params[i].equals("distanceZ")) {
                ViewGroup vg = (ViewGroup) layoutInflater.inflate(R.layout.distance_plot_with_slider, layout, false);
                DistPlot dp = (DistPlot)vg.getChildAt(0);
                ScaleControlBar scaleBar = (ScaleControlBar)vg.getChildAt(1);
                mViews.put(params[i], dp);
                dp.setDescription(params[i]);
                dp.setParamName(params[i]);
                dp.setOnClickListener(this);

                if(mKatDevice != null) {
                    mKatDevice.getKatDataBuffer().subscribeObserverToDataParamByName(dp, params[i]);
                    mKatDevice.subsribeObserverToAllPositions(dp);
                    dp.setDrawPositions( mKatDevice.getFeedbackGenerator().isParamUsedForFeedback(params[i]) );


                }

//                dp.subscribeToDataHubParam(params[i]);
                v = vg;
                // All those inflated views have slidebars as child #1
                if(paramsScrollbarsPresent) {
                    scaleBar.setTag( params[i] );
                    scaleBar.setOnSeekBarChangeListener(this);

                    loadStateOfScaleBarFromFeedbackParams(scaleBar, params[i]);


                } else {
                    vg.removeViewAt(1);
                }
            } else if(params[i].equals("emg")) {
                ViewGroup vg = (ViewGroup) layoutInflater.inflate(R.layout.emg_plot_with_slider, layout, false);
                EMGPlot emgPlot = (EMGPlot)vg.getChildAt(0);
                ScaleControlBar scaleBar = (ScaleControlBar)vg.getChildAt(1);

                emgPlot.setDescription(params[i]);
                mViews.put(params[i], emgPlot);
                // All those inflated views have slidebars as child #1
                if(paramsScrollbarsPresent) {
                    scaleBar.setTag( params[i] );
                    scaleBar.setOnSeekBarChangeListener(this);

                    loadStateOfScaleBarFromFeedbackParams(scaleBar, params[i]);

                } else {
                    vg.removeViewAt(1);
                }
                v = vg;
            }

            if(v != null) {
                layout.addView(v);
            }


        }
        getView().invalidate();
    }

    protected void loadStateOfScaleBarFromFeedbackParams(ScaleControlBar scaleBar, String paramName) {
        if(mKatDevice == null) return;
        Float progress = convertScaleToProgress( mKatDevice.getFeedbackGenerator().getParamToleranceScale(paramName) );
        scaleBar.setProgress( Math.round( progress ) );
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_training, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        mContext = view.getContext();

        mFeedbackToggleButton = (TriStateToggleButton)view.findViewById(R.id.training_feedback_toggle_button);
        mFeedbackToggleButton.setOnClickListener(this);

        mAcousticFeedbackToggleButton = (ToggleButton)view.findViewById(R.id.training_acoustic_feedback_toggle_button);
        mAcousticFeedbackToggleButton.setOnClickListener(this);

        mKineticFeedbackToggleButton = (ToggleButton)view.findViewById(R.id.training_kinetic_feedback_toggle_button);
        mKineticFeedbackToggleButton.setOnClickListener(this);

        mLaserDiodesToggleButton = (ToggleButton)view.findViewById(R.id.training_laser_diodes_toggle_button);
        mLaserDiodesToggleButton.setOnClickListener(this);

        mGlobalToleranceScaleBar = (ScaleControlBar)view.findViewById(R.id.training_global_tolerance_scale_bar);
        mGlobalToleranceScaleBar.setOnSeekBarChangeListener(this);

        mPositionsListView = (ListView)view.findViewById(R.id.training_positions_list_view);




    }

    @Override
    public void onClick(View view) {

        if(view instanceof ParamViewBase) {
            ParamViewBase paramView = (ParamViewBase)view;
            mKatDevice.getFeedbackGenerator().toggleParamFeedbackState(paramView.getParamName()) ;
            paramView.setDrawPositions( mKatDevice.getFeedbackGenerator().isParamUsedForFeedback(paramView.getParamName()) );

            paramView.invalidate();
//            toggleParamFeedbackState(paramView.getPara);

        }

        if(view == mFeedbackToggleButton) {
            mFeedbackToggleButton.advanceState();
//            DataHub.getInstance().dataProduced(this, "feedbackMode", mFeedbackToggleButton.getState());
            if(mKatDevice != null) {

                int newFeedbackState = mFeedbackToggleButton.getState();
                mKatDevice.getFeedbackGenerator().setFeedbackMode(newFeedbackState);

            }
        }

        if(view == mAcousticFeedbackToggleButton) {
//            DataHub.getInstance().dataProduced(this, "acousticFeedbackEnabled", mAcousticFeedbackToggleButton.isChecked());
            if(mKatDevice != null) {
                mKatDevice.setAcousticFeedbackEnabled( mAcousticFeedbackToggleButton.isChecked() );
            }
        }

        if(view == mKineticFeedbackToggleButton) {
         //   DataHub.getInstance().dataProduced(this, "kineticFeedbackEnabled", mKineticFeedbackToggleButton.isChecked());
            if(mKatDevice != null) {
                mKatDevice.setKineticFeedbackEnabled(mKineticFeedbackToggleButton.isChecked()  );
            }
        }

        if(view == mLaserDiodesToggleButton) {
//            DataHub.getInstance().dataProduced(this, "laserDiodesEnabled", mLaserDiodesToggleButton.isChecked());
            if(mKatDevice != null) {
                mKatDevice.setLaserDiodesEnabled( mLaserDiodesToggleButton.isChecked() );
            }
        }

    }

    protected Float convertScaleToProgress(Float scale) {
        return scale * 10.0f;
    }

    protected Float convertProgresToScale(Float progress) {
        return progress / 10.0f;
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean fromUser) {
        if(!fromUser) return;
//        Float scale = ((float) i) / 10.0f;
        Float scale = convertProgresToScale((float)i);

        seekBar.setVerticalScrollbarPosition( i );

        if(seekBar == mGlobalToleranceScaleBar) {
            //KAT_MESSAGE_TYPE_PARAM_SCALE_CHANGED
//            DataHub.getInstance().dataProduced(this, "globalToleranceScale", scale);

            if(mKatDevice != null) {
                mKatDevice.getFeedbackGenerator().setGlobalToleranceScale(scale);

            }

        } else {
            String tag = (String)seekBar.getTag();
            if(tag == null) return;
            if(mKatDevice != null) {
                mKatDevice.getFeedbackGenerator().setParamToleranceScale(tag, scale);
            }

//            FeedbackGenerator.getInstance().setParamToleranceScale(tag, scale);

            View v = mViews.get( tag );
            if(v == null || v instanceof ParamViewBase == false) return;

            ParamViewBase pvb = (ParamViewBase)v;
            pvb.setParamFeedbackScale( scale );

//            seekBar.invalidate();
//            seekBar.refreshDrawableState();

        }

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
