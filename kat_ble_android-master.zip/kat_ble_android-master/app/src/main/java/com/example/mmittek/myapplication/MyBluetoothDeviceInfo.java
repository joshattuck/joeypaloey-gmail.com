package com.example.mmittek.myapplication;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.le.ScanResult;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by mmittek on 7/20/16.
 */
public class MyBluetoothDeviceInfo implements Serializable {

    private String mName;
    private String mMAC;
    private int mRSSI;
    private boolean mConnectionAllowed;
    private boolean mConnected;
    private BluetoothGatt mGatt;
    private BluetoothGattService mGattService;
    private Date firstSeen;

    public MyBluetoothDeviceInfo(ScanResult scanResult) {
        mName = scanResult.getDevice().getName();
        mMAC = scanResult.getDevice().getAddress();
        mRSSI = scanResult.getRssi();
        mConnectionAllowed = true;  // FIXME
        mConnected = false; // FIXME
        firstSeen = Calendar.getInstance().getTime();
    }

    public MyBluetoothDeviceInfo(String name, String MAC, int RSSI) {
        mName = name;
        mMAC = MAC;
        mRSSI = RSSI;
        mConnectionAllowed = true;
        mConnected = false;
        firstSeen = Calendar.getInstance().getTime();
    }

    public final Date getFirstSeen() {
        return firstSeen;
    }

    public void setGatt(final BluetoothGatt bluetoothGatt) {
        mGatt = bluetoothGatt;
    }

    public void setGattService(final BluetoothGattService service) {
        mGattService = service;
    }

    public final boolean isConnected() {
        return mConnected;
    }

    public void setConnected(boolean connected) {
        mConnected = connected;
    }

    public final boolean getConnectionAllowed() {
        return mConnectionAllowed;
    }

    public final String getName() {
        return mName;
    }

    public final int getRssi() {
        return mRSSI;
    }

    public final String getMAC() {
        return mMAC;
    }


    @Override
    public String toString() {
        return "MAC: " + getMAC() + ": " + getName() + ", RSSI: " + getRssi() + "dBm" + ", first seen: " + firstSeen;
    }

}
