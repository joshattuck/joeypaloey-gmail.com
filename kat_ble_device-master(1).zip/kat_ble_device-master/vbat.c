#include "vbat.h"
#include <math.h>


float vbat_convert_voltage(vbat_raw_value_t raw_value) {
	if(raw_value < VBAT_ADC_MIN) raw_value = VBAT_ADC_MIN;
	if(raw_value > VBAT_ADC_MAX) raw_value = VBAT_ADC_MAX;
	float value = VBAT_MIN + (VBAT_MAX-VBAT_MIN)*((float)raw_value-VBAT_ADC_MIN)/(VBAT_ADC_MAX-VBAT_ADC_MIN);
	return value;
}


uint8_t vbat_convert_percentage(vbat_raw_value_t raw_value) {
	float value;
	#if VBAT_MODEL == VBAT_MODEL_LINEAR
		value = 100.0f*((float)raw_value-VBAT_ADC_MIN)/(VBAT_ADC_MAX-VBAT_ADC_MIN);
	#elif VBAT_MODEL == VBAT_MODEL_SIGMOID
		float voltage = vbat_convert_voltage( raw_value );
		value = 100.0f/( 1+exp( -VBAT_SIGMOID_SLOPE*( voltage-VBAT_HALFCAP ) ) );
	#endif // VBAT_MODEL

	// nice cleanup
	if(value < 0) value = 0;
	if(value > 100) value = 100;
	return value;
}
