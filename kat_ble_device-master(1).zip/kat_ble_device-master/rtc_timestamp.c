#include "rtc_timestamp.h"


volatile uint32_t rtc_timestamp_current_timestamp = 0;


// RTC tick events generation.
void rtc_timestamp_rtc_int_handler(nrf_drv_rtc_int_type_t int_type) {
	rtc_timestamp_current_timestamp++;
}


void rtc_timestamp_write_to_unsigned_long_pointer(long unsigned int *timestamp) {
	*timestamp = rtc_timestamp_current_timestamp;
}
