var structble__kat__s =
[
    [ "characteristics_num", "group__ble__srv__kat.html#ga64304c943e6d5064f83eb40d86c05155", null ],
    [ "conn_handle", "group__ble__srv__kat.html#gaa55435600afbe3fc60f780800a44fbad", null ],
    [ "data_handler", "group__ble__srv__kat.html#ga5b60fca20f22b3cedda46d24a1030eac", null ],
    [ "p_characteristics", "group__ble__srv__kat.html#ga8afbe8f3af8809e012d3391b41ae1e7f", null ],
    [ "service_handle", "group__ble__srv__kat.html#ga1f2d6aa67497950d61c2508675d1b231", null ],
    [ "timestamp", "group__ble__srv__kat.html#gac6f4b4e65f3084cfac22f70eb82a7923", null ],
    [ "uuid_type", "group__ble__srv__kat.html#gac46000adacc9a6996d9504bb93e53e3f", null ]
];