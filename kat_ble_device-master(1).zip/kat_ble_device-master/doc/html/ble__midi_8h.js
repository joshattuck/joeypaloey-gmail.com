var ble__midi_8h =
[
    [ "BLE_MIDI_MAX_DATA_LEN", "group__ble__sdk__srv__nus.html#ga9a113378a295b5de5ff8a3d899951466", null ],
    [ "BLE_UUID_MIDI_SERVICE", "group__ble__sdk__srv__nus.html#ga16ebb373f486d2c2d29dca940922f7dd", null ],
    [ "MIDI_STATUS_NOTE_OFF", "group__ble__sdk__srv__nus.html#ga508f50a35543d3e5ea6baf9750440707", null ],
    [ "MIDI_STATUS_NOTE_ON", "group__ble__sdk__srv__nus.html#gaa1b6ca289d856e41e2f1096d2b189d99", null ],
    [ "MIDI_STATUS_PKP", "group__ble__sdk__srv__nus.html#gaa52ce61d95d378e97f7e84abb0bb3c59", null ],
    [ "ble_midi_data_handler_t", "group__ble__sdk__srv__nus.html#ga01e343ea369fcfcf25c68f8a00536916", null ],
    [ "ble_midi_t", "group__ble__sdk__srv__nus.html#ga3d271bbdb49e6bfde4bc9d4223cfe2d9", null ],
    [ "midi_timestamp_t", "group__ble__sdk__srv__nus.html#ga68627468268338bb57d4179fd8fa17a0", null ],
    [ "ble_midi_init", "group__ble__sdk__srv__nus.html#gadcd46d2cef2e360200e119e50fe3c5ad", null ],
    [ "ble_midi_message_init", "group__ble__sdk__srv__nus.html#ga38185bd65c20413273dbfe8aec564520", null ],
    [ "ble_midi_note_on", "group__ble__sdk__srv__nus.html#ga19f135c85350f600eae05dad7efbc1e4", null ],
    [ "ble_midi_on_ble_evt", "group__ble__sdk__srv__nus.html#gaf4910388d5fab42dcf21736990777bc5", null ],
    [ "ble_midi_send", "group__ble__sdk__srv__nus.html#ga55f141dce4a401a0d63cb3c1f923489d", null ],
    [ "ble_midi_send_message", "group__ble__sdk__srv__nus.html#ga0672121438598e8a9e8b1046b329df3a", null ],
    [ "ble_midi_timestamp_hi", "group__ble__sdk__srv__nus.html#ga1d3a56ac5c7e95c38a5eb226a34b06d7", null ],
    [ "ble_midi_timestamp_increment", "group__ble__sdk__srv__nus.html#ga05379f6b24d4d1ad979a9686b815e29e", null ],
    [ "ble_midi_timestamp_lo", "group__ble__sdk__srv__nus.html#ga200f9473ae835041c472f982f3ec159a", null ]
];