var structble__midi__packet__one__message__t =
[
    [ "data1", "structble__midi__packet__one__message__t.html#a4effb5a4c33478d8078fb09e2327d81d", null ],
    [ "data2", "structble__midi__packet__one__message__t.html#acd2b9a6e2afa9e874ae226bfae8eff32", null ],
    [ "status", "structble__midi__packet__one__message__t.html#adbc3462be8d679836e2a7bfcf360cf63", null ],
    [ "timestamp_hi", "structble__midi__packet__one__message__t.html#aa751cd15361fe71be0666f13b1bd068f", null ],
    [ "timestamp_lo", "structble__midi__packet__one__message__t.html#a8feaf669c67d52dfced32e9308671635", null ]
];