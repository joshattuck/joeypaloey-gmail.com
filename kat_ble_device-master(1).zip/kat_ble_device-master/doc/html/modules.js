var modules =
[
    [ "Nordic UART Service", "group__ble__sdk__srv__nus.html", "group__ble__sdk__srv__nus" ],
    [ "KAT BLE Service", "group__ble__srv__kat.html", "group__ble__srv__kat" ],
    [ "main.c", "group__ble__sdk__uart__over__ble__main.html", "group__ble__sdk__uart__over__ble__main" ]
];