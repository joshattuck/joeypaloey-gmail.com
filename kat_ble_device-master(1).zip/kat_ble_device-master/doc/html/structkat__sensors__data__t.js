var structkat__sensors__data__t =
[
    [ "acc_data", "group__ble__srv__kat.html#ga950ebce680825c05529b3a1e7555c45a", null ],
    [ "range_data", "group__ble__srv__kat.html#ga55aa9b5bb4de3cef540a050466472d73", null ]
];