var kat_8h =
[
    [ "KAT_SERVICE_UUID_MINOR", "group__ble__srv__kat.html#ga4a540845ed71d84fb64f75c16069fa86", null ],
    [ "KAT_SERVICE_UUID_TYPE", "group__ble__srv__kat.html#ga50b09f5be35682b39bda1f8fb6a9994d", null ],
    [ "ble_kat_data_handler_t", "group__ble__srv__kat.html#ga41d00af336c0f42bae5dcbb28fbf66a5", null ],
    [ "ble_kat_t", "group__ble__srv__kat.html#ga8d9517a2e1d80ca04134e10388f76cf1", null ],
    [ "kat_char_access_flags_t", "group__ble__srv__kat.html#ga1038f41c54a6ec4dccef2300edb8079d", null ],
    [ "kat_char_ble_on_write_handler_t", "group__ble__srv__kat.html#ga486268a1277191fc2fd14fd4d40bf92a", null ],
    [ "kat_char_sampling_rate_changed_handler", "group__ble__srv__kat.html#gab278e85429c898d748ad516637c14045", null ],
    [ "kat_char_t", "group__ble__srv__kat.html#gaf235aee7f8da51d16b719826fb0165f6", null ],
    [ "kat_sampling_rate_t", "group__ble__srv__kat.html#gaa6268d333152005e1fec21c0c8076c04", null ],
    [ "kat_timestamp_t", "group__ble__srv__kat.html#ga24d469fad3914d0cbc3709b3dedab88d", null ],
    [ "kat_char_access_flag_t", "group__ble__srv__kat.html#gaba487230c20fc5701b3c0d84ae570f77", [
      [ "KAT_CHAR_ACCESS_FLAG_READ", "group__ble__srv__kat.html#ggaba487230c20fc5701b3c0d84ae570f77a0896d003f5828e9ab5eb4414fd07aad6", null ],
      [ "KAT_CHAR_ACCESS_FLAG_WRITE", "group__ble__srv__kat.html#ggaba487230c20fc5701b3c0d84ae570f77ae48b1431be1ba7ff5b80db7c676433a2", null ],
      [ "KAT_CHAR_ACCESS_FLAG_WRITE_NORESP", "group__ble__srv__kat.html#ggaba487230c20fc5701b3c0d84ae570f77a0b58fec6c876395e862f0055b4a3075d", null ],
      [ "KAT_CHAR_ACCESS_FLAG_NOTIFY", "group__ble__srv__kat.html#ggaba487230c20fc5701b3c0d84ae570f77ab3c33094af027671c8823a64a8cd94a5", null ],
      [ "KAT_CHAR_ACCESS_FLAG_INDICATE", "group__ble__srv__kat.html#ggaba487230c20fc5701b3c0d84ae570f77a85f7c42e996a56f75f80d3480cdcc464", null ]
    ] ],
    [ "kat_char_type_t", "group__ble__srv__kat.html#gaf580810cd427687bf66ef2ab46f0d2b0", [
      [ "KAT_CHAR_TYPE_FEEDBACK", "group__ble__srv__kat.html#ggaf580810cd427687bf66ef2ab46f0d2b0a71c2d4ba20b11f16295a739e2719de74", null ],
      [ "KAT_CHAR_TYPE_SENSORS_DATA_1D", "group__ble__srv__kat.html#ggaf580810cd427687bf66ef2ab46f0d2b0a83cbccf6996a006d99f2765c548d39d9", null ],
      [ "KAT_CHAR_TYPE_SENSORS_DATA_2D", "group__ble__srv__kat.html#ggaf580810cd427687bf66ef2ab46f0d2b0a99487a651aefc1ef173fa6e380fa495d", null ],
      [ "KAT_CHAR_TYPE_SENSORS_DATA_3D", "group__ble__srv__kat.html#ggaf580810cd427687bf66ef2ab46f0d2b0a3af557dd1e37b2a5b29e8bab9cd9132c", null ],
      [ "KAT_CHAR_TYPE_SENSORS_SAMPLING_RATE", "group__ble__srv__kat.html#ggaf580810cd427687bf66ef2ab46f0d2b0a774d345bb57d6dcdcb55db718e1ba51b", null ]
    ] ],
    [ "kat_char_uuid_minor_t", "group__ble__srv__kat.html#gacda6ed8764afd419ed4d5b90a1e1c9c7", [
      [ "KAT_CHAR_UUID_MINOR_SENSORS_DATA", "group__ble__srv__kat.html#ggacda6ed8764afd419ed4d5b90a1e1c9c7a68c7d509bb9986d65cdeba1e502210b2", null ],
      [ "KAT_CHAR_UUID_MINOR_BUZZER", "group__ble__srv__kat.html#ggacda6ed8764afd419ed4d5b90a1e1c9c7a6005ca257c39a54f3cd76d49ad18574b", null ],
      [ "KAT_CHAR_UUID_MINOR_VIBR", "group__ble__srv__kat.html#ggacda6ed8764afd419ed4d5b90a1e1c9c7abbb3b2cbb980607cb08d11c36bb04767", null ],
      [ "KAT_CHAR_UUID_MINOR_LASX", "group__ble__srv__kat.html#ggacda6ed8764afd419ed4d5b90a1e1c9c7aa1171e51a03762d4e8856cbe83ef5924", null ],
      [ "KAT_CHAR_UUID_MINOR_LASY", "group__ble__srv__kat.html#ggacda6ed8764afd419ed4d5b90a1e1c9c7a19b02ed3a530e3e4661e35fd2d7ad068", null ],
      [ "KAT_CHAR_UUID_MINOR_ACC", "group__ble__srv__kat.html#ggacda6ed8764afd419ed4d5b90a1e1c9c7a617bef4118a5bfe34b7c28bdb7199493", null ],
      [ "KAT_CHAR_UUID_MINOR_MAGNETOMETER", "group__ble__srv__kat.html#ggacda6ed8764afd419ed4d5b90a1e1c9c7ac30ea548536105962af8babff1525bd7", null ],
      [ "KAT_CHAR_UUID_MINOR_IMU_SAMPLING_RATE", "group__ble__srv__kat.html#ggacda6ed8764afd419ed4d5b90a1e1c9c7a57b286fda6135f14ec8dc3a1e0805505", null ]
    ] ],
    [ "kat_feedback_value_t", "group__ble__srv__kat.html#gafe9148eac8e846db24d291b333d73afc", [
      [ "KAT_FEEDBACK_VALUE_OFF", "group__ble__srv__kat.html#ggafe9148eac8e846db24d291b333d73afca14bc3606cf8b5ab2ebe00ed76866b1a0", null ],
      [ "KAT_FEEDBACK_VALUE_ON", "group__ble__srv__kat.html#ggafe9148eac8e846db24d291b333d73afca41c2020352c639d191ef305fff8c7070", null ]
    ] ],
    [ "ble_kat_init", "group__ble__srv__kat.html#gac84cc4c55ef567f34f46f5a8089cc041", null ],
    [ "ble_kat_on_ble_event", "group__ble__srv__kat.html#gab65e60bf2fdb7aca8213e0cbe2485c5f", null ],
    [ "kat_char_init_feedback", "group__ble__srv__kat.html#ga761413983fe201efa299eeda08055dd2", null ],
    [ "kat_char_init_sampling_rate", "group__ble__srv__kat.html#ga793f2435c918a1028c50ff079ff362bf", null ],
    [ "kat_char_init_sensor_3d", "group__ble__srv__kat.html#ga883ed0902708117d06629c19d3e7d8be", null ],
    [ "kat_char_notify_new_data", "group__ble__srv__kat.html#gaee5ebc5f7898087422929b12e8fd9b34", null ],
    [ "kat_feedback_data_init", "group__ble__srv__kat.html#gaaeb1e0f1fcd643cb9e030701217e3ffb", null ],
    [ "kat_notify_new_sensor_values", "group__ble__srv__kat.html#ga0f2fe5750472838aed984c697748d10e", null ],
    [ "kat_timestamp_increment", "group__ble__srv__kat.html#gaef4c6524439f9fa5221aad6c9a21a5ef", null ]
];