var group__ble__sdk__srv__nus =
[
    [ "ble_midi_packet_one_message_t", "structble__midi__packet__one__message__t.html", [
      [ "data1", "structble__midi__packet__one__message__t.html#a4effb5a4c33478d8078fb09e2327d81d", null ],
      [ "data2", "structble__midi__packet__one__message__t.html#acd2b9a6e2afa9e874ae226bfae8eff32", null ],
      [ "status", "structble__midi__packet__one__message__t.html#adbc3462be8d679836e2a7bfcf360cf63", null ],
      [ "timestamp_hi", "structble__midi__packet__one__message__t.html#aa751cd15361fe71be0666f13b1bd068f", null ],
      [ "timestamp_lo", "structble__midi__packet__one__message__t.html#a8feaf669c67d52dfced32e9308671635", null ]
    ] ],
    [ "ble_midi_message_t", "structble__midi__message__t.html", [
      [ "data1", "structble__midi__message__t.html#aaad427d975b66a68994f0fba12d019f3", null ],
      [ "data2", "structble__midi__message__t.html#ab069bc9200e05f6c3e37141022945ec8", null ],
      [ "status", "structble__midi__message__t.html#a82043dd755cf86266094ea72ffb16c19", null ],
      [ "timestamp_lo", "structble__midi__message__t.html#a567beb59fb96e851b0c4da1c29028c33", null ]
    ] ],
    [ "ble_midi_packet_t", "structble__midi__packet__t.html", [
      [ "messages", "structble__midi__packet__t.html#ac54c45827fd02bede9ae4ba844e414d6", null ],
      [ "messages_num", "structble__midi__packet__t.html#ab17f4f3268b108d6dca5f193c3e2aed0", null ],
      [ "timestamp_hi", "structble__midi__packet__t.html#acc853830f120c69c7f76f50d91d5c748", null ]
    ] ],
    [ "ble_midi_init_t", "structble__midi__init__t.html", [
      [ "data_handler", "structble__midi__init__t.html#a6362b8ea82a192037147bbc34a1a1a34", null ]
    ] ],
    [ "ble_midi_s", "structble__midi__s.html", [
      [ "conn_handle", "structble__midi__s.html#a34fbbcbf90011f1b339fc55896cd7531", null ],
      [ "data_handler", "structble__midi__s.html#a84859af15131839937b3c56ad1aacfd1", null ],
      [ "is_notification_enabled", "structble__midi__s.html#ac035bc07be7f3ba67f27dc821bc9da1b", null ],
      [ "midi_timestamp", "structble__midi__s.html#aa4ac0c2bbf42f47930ee7c57f37f6a80", null ],
      [ "midiio_handles", "structble__midi__s.html#a3918095d5e5ff5209fd75600797512b6", null ],
      [ "service_handle", "structble__midi__s.html#aa8370ad74c8dca4d5ac92604e768b8c5", null ],
      [ "uuid_type", "structble__midi__s.html#a6d6196468d950eb48f84b4324e59abe0", null ]
    ] ],
    [ "BLE_MIDI_MAX_DATA_LEN", "group__ble__sdk__srv__nus.html#ga9a113378a295b5de5ff8a3d899951466", null ],
    [ "BLE_UUID_MIDI_SERVICE", "group__ble__sdk__srv__nus.html#ga16ebb373f486d2c2d29dca940922f7dd", null ],
    [ "MIDI_STATUS_NOTE_OFF", "group__ble__sdk__srv__nus.html#ga508f50a35543d3e5ea6baf9750440707", null ],
    [ "MIDI_STATUS_NOTE_ON", "group__ble__sdk__srv__nus.html#gaa1b6ca289d856e41e2f1096d2b189d99", null ],
    [ "MIDI_STATUS_PKP", "group__ble__sdk__srv__nus.html#gaa52ce61d95d378e97f7e84abb0bb3c59", null ],
    [ "ble_midi_data_handler_t", "group__ble__sdk__srv__nus.html#ga01e343ea369fcfcf25c68f8a00536916", null ],
    [ "ble_midi_t", "group__ble__sdk__srv__nus.html#ga3d271bbdb49e6bfde4bc9d4223cfe2d9", null ],
    [ "midi_timestamp_t", "group__ble__sdk__srv__nus.html#ga68627468268338bb57d4179fd8fa17a0", null ],
    [ "ble_midi_init", "group__ble__sdk__srv__nus.html#gadcd46d2cef2e360200e119e50fe3c5ad", null ],
    [ "ble_midi_message_init", "group__ble__sdk__srv__nus.html#ga38185bd65c20413273dbfe8aec564520", null ],
    [ "ble_midi_note_on", "group__ble__sdk__srv__nus.html#ga19f135c85350f600eae05dad7efbc1e4", null ],
    [ "ble_midi_on_ble_evt", "group__ble__sdk__srv__nus.html#gaf4910388d5fab42dcf21736990777bc5", null ],
    [ "ble_midi_send", "group__ble__sdk__srv__nus.html#ga55f141dce4a401a0d63cb3c1f923489d", null ],
    [ "ble_midi_send_message", "group__ble__sdk__srv__nus.html#ga0672121438598e8a9e8b1046b329df3a", null ],
    [ "ble_midi_timestamp_hi", "group__ble__sdk__srv__nus.html#ga1d3a56ac5c7e95c38a5eb226a34b06d7", null ],
    [ "ble_midi_timestamp_increment", "group__ble__sdk__srv__nus.html#ga05379f6b24d4d1ad979a9686b815e29e", null ],
    [ "ble_midi_timestamp_lo", "group__ble__sdk__srv__nus.html#ga200f9473ae835041c472f982f3ec159a", null ]
];