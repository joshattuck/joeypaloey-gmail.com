var structkat__2d__data__t =
[
    [ "x", "group__ble__srv__kat.html#ga7dcb28ef2ec299b8accf9a451ad92434", null ],
    [ "y", "group__ble__srv__kat.html#gad1f6331fc462d0db4b4cad41a32a3d7d", null ]
];