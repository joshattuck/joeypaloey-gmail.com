var annotated_dup =
[
    [ "adafruit_bno055_offsets_t", "structadafruit__bno055__offsets__t.html", "structadafruit__bno055__offsets__t" ],
    [ "adafruit_bno055_rev_info_t", "structadafruit__bno055__rev__info__t.html", "structadafruit__bno055__rev__info__t" ],
    [ "ble_kat_init_t", "structble__kat__init__t.html", "structble__kat__init__t" ],
    [ "ble_kat_s", "structble__kat__s.html", "structble__kat__s" ],
    [ "ble_midi_init_t", "structble__midi__init__t.html", "structble__midi__init__t" ],
    [ "ble_midi_message_t", "structble__midi__message__t.html", "structble__midi__message__t" ],
    [ "ble_midi_packet_one_message_t", "structble__midi__packet__one__message__t.html", "structble__midi__packet__one__message__t" ],
    [ "ble_midi_packet_t", "structble__midi__packet__t.html", "structble__midi__packet__t" ],
    [ "ble_midi_s", "structble__midi__s.html", "structble__midi__s" ],
    [ "bno055_t", "structbno055__t.html", "structbno055__t" ],
    [ "glove_change_evt_t", "structglove__change__evt__t.html", "structglove__change__evt__t" ],
    [ "glove_conf_s", "structglove__conf__s.html", "structglove__conf__s" ],
    [ "glove_finger_t", "structglove__finger__t.html", "structglove__finger__t" ],
    [ "hcsr04_t", "structhcsr04__t.html", "structhcsr04__t" ],
    [ "kat_char_s", "structkat__char__s.html", "structkat__char__s" ],
    [ "kat_feedback_data_t", "structkat__feedback__data__t.html", "structkat__feedback__data__t" ],
    [ "kat_sensor_1d_data_t", "structkat__sensor__1d__data__t.html", "structkat__sensor__1d__data__t" ],
    [ "kat_sensor_2d_data_t", "structkat__sensor__2d__data__t.html", "structkat__sensor__2d__data__t" ],
    [ "kat_sensor_3d_data_t", "structkat__sensor__3d__data__t.html", "structkat__sensor__3d__data__t" ]
];