var structble__midi__packet__t =
[
    [ "messages", "structble__midi__packet__t.html#ac54c45827fd02bede9ae4ba844e414d6", null ],
    [ "messages_num", "structble__midi__packet__t.html#ab17f4f3268b108d6dca5f193c3e2aed0", null ],
    [ "timestamp_hi", "structble__midi__packet__t.html#acc853830f120c69c7f76f50d91d5c748", null ]
];