var searchData=
[
  ['i2c_5finit',['i2c_init',['../i2c_8c.html#a48591085c78b33b40ce44c253560dc8a',1,'i2c_init(uint8_t pin_scl, uint8_t pin_sda):&#160;i2c.c'],['../i2c_8h.html#a48591085c78b33b40ce44c253560dc8a',1,'i2c_init(uint8_t pin_scl, uint8_t pin_sda):&#160;i2c.c']]],
  ['i2c_5fread8',['i2c_read8',['../i2c_8c.html#a171ce676b586b3725e2bf45ec3c1728a',1,'i2c_read8(uint8_t device, uint8_t reg):&#160;i2c.c'],['../i2c_8h.html#a171ce676b586b3725e2bf45ec3c1728a',1,'i2c_read8(uint8_t device, uint8_t reg):&#160;i2c.c']]],
  ['i2c_5fread_5fmany',['i2c_read_many',['../i2c_8c.html#ab10c7d37032da4a2aa26bf98c0bb4a59',1,'i2c_read_many(uint8_t device, uint8_t reg, uint8_t *buffer, uint8_t len):&#160;i2c.c'],['../i2c_8h.html#ab10c7d37032da4a2aa26bf98c0bb4a59',1,'i2c_read_many(uint8_t device, uint8_t reg, uint8_t *buffer, uint8_t len):&#160;i2c.c']]],
  ['i2c_5fwrite8',['i2c_write8',['../i2c_8c.html#adbd5c5908eae07e1d8881e4d38fdd89d',1,'i2c_write8(uint8_t device, uint8_t reg, uint8_t value):&#160;i2c.c'],['../i2c_8h.html#adbd5c5908eae07e1d8881e4d38fdd89d',1,'i2c_write8(uint8_t device, uint8_t reg, uint8_t value):&#160;i2c.c']]],
  ['imu_5finit',['imu_init',['../group__ble__sdk__uart__over__ble__main.html#ga5023a8bb8384b6ce3b44002904ecacb6',1,'main.c']]],
  ['imu_5fsampling_5frate_5fchanged_5fhandler',['imu_sampling_rate_changed_handler',['../group__ble__sdk__uart__over__ble__main.html#gac71dbeaaf3fc49bcd0e610dd1ddbab05',1,'main.c']]],
  ['initialize_5fsdhc',['Initialize_SDHC',['../sd_8c.html#a88fede7c63d89ad479899b3035e31ea5',1,'Initialize_SDHC(void):&#160;sd.c'],['../sd_8h.html#a88fede7c63d89ad479899b3035e31ea5',1,'Initialize_SDHC(void):&#160;sd.c']]]
];
