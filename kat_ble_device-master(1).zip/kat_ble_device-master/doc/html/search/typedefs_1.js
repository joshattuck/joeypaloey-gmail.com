var searchData=
[
  ['glove_5fconf_5ft',['glove_conf_t',['../glove_8h.html#a04cf4d26fffa93702290e37dc4e52f4c',1,'glove.h']]],
  ['glove_5fvalues_5fchanged_5fhandler_5ft',['glove_values_changed_handler_t',['../glove_8h.html#a44b6662ff4d561f3744f64b1611e9ac3',1,'glove.h']]]
];
