var searchData=
[
  ['sampling_5frate_5fchanged_5fhandler',['sampling_rate_changed_handler',['../group__ble__srv__kat.html#ga1d3111519f60d6ca05b2d01ef8611be1',1,'kat_char_s']]],
  ['sd_5fbuffer',['sd_buffer',['../sd_8h.html#a5f73316857bbaf99a9f337c980122e50',1,'sd.h']]],
  ['sd_5fcmd1',['sd_cmd1',['../sd_8c.html#afdcd52aa374f8c455f8c1c97c1398c38',1,'sd.c']]],
  ['sd_5fcmd2',['sd_cmd2',['../sd_8c.html#a001b3dd9275a7a2fe91fe26cb788dab9',1,'sd.c']]],
  ['sd_5fcmd3',['sd_cmd3',['../sd_8c.html#a9eca7e902f5f5d41bc59391cab7e45f0',1,'sd.c']]],
  ['sd_5fcmd4',['sd_cmd4',['../sd_8c.html#a5b3a4d73996ece07424b6db6bb4c05d5',1,'sd.c']]],
  ['sd_5fcmd5',['sd_cmd5',['../sd_8c.html#af4be8fc664695a8ce785ee4686e91adb',1,'sd.c']]],
  ['sensor_5fid',['sensor_id',['../structbno055__t.html#ae230c1e4d550a16e4092ee3403f3768b',1,'bno055_t']]],
  ['service_5fhandle',['service_handle',['../structble__midi__s.html#aa8370ad74c8dca4d5ac92604e768b8c5',1,'ble_midi_s::service_handle()'],['../group__ble__srv__kat.html#ga1f2d6aa67497950d61c2508675d1b231',1,'ble_kat_s::service_handle()']]],
  ['spi_5fmaster',['spi_master',['../sd_8c.html#a9c1685cf400d1c122f26671d443eea66',1,'sd.c']]],
  ['startblock',['startBlock',['../sd_8c.html#acc9846dc79e265d6c378faeaf2b31509',1,'sd.c']]],
  ['status',['status',['../structble__midi__packet__one__message__t.html#adbc3462be8d679836e2a7bfcf360cf63',1,'ble_midi_packet_one_message_t::status()'],['../structble__midi__message__t.html#a82043dd755cf86266094ea72ffb16c19',1,'ble_midi_message_t::status()']]],
  ['sw_5frev',['sw_rev',['../structadafruit__bno055__rev__info__t.html#ad0a9a10263312e9f061a0ceea22909cc',1,'adafruit_bno055_rev_info_t']]]
];
