var searchData=
[
  ['adafruit_5fbno055_5faxis_5fremap_5fconfig_5ft',['adafruit_bno055_axis_remap_config_t',['../bno055_8h.html#a671787eeef1eef02bf7aaa541c632761',1,'bno055.h']]],
  ['adafruit_5fbno055_5faxis_5fremap_5fsign_5ft',['adafruit_bno055_axis_remap_sign_t',['../bno055_8h.html#abd2f73de931e0b4bd9285505961b575f',1,'bno055.h']]],
  ['adafruit_5fbno055_5fopmode_5ft',['adafruit_bno055_opmode_t',['../bno055_8h.html#ae17c9a069a2744d4dd4b0c67923618b5',1,'bno055.h']]],
  ['adafruit_5fbno055_5fpowermode_5ft',['adafruit_bno055_powermode_t',['../bno055_8h.html#a1c28bc24f3b0c64165d412eee600c001',1,'bno055.h']]],
  ['adafruit_5fbno055_5freg_5ft',['adafruit_bno055_reg_t',['../bno055_8h.html#a7f054ca2345f1d89ee1b0384b9734765',1,'bno055.h']]],
  ['adafruit_5fvector_5ftype_5ft',['adafruit_vector_type_t',['../bno055_8h.html#a94564c150f8ba3f0dbb679918231a179',1,'bno055.h']]]
];
