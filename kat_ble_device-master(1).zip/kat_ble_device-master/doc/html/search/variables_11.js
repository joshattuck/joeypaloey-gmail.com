var searchData=
[
  ['value',['value',['../structglove__change__evt__t.html#a6885d7021275feb60f43ce9a02c4b8be',1,'glove_change_evt_t::value()'],['../group__ble__srv__kat.html#gaf58c7f52f78596cb87b387b7ae69c1d8',1,'kat_feedback_data_t::value()']]],
  ['value_5fmax',['value_max',['../structglove__conf__s.html#ae712502887cd49b4472543424adf5b19',1,'glove_conf_s']]],
  ['value_5fmin',['value_min',['../structglove__conf__s.html#a47c5a7a6695f95a00d0dfb7c512d44bd',1,'glove_conf_s']]],
  ['value_5fptr',['value_ptr',['../structglove__finger__t.html#a8efeaa4895470da7b329bf11bebe216f',1,'glove_finger_t']]],
  ['values',['values',['../structglove__conf__s.html#a22582017edce85f0c9528d47e1e66872',1,'glove_conf_s']]],
  ['values_5fold',['values_old',['../structglove__conf__s.html#a22a2e243fef9b252f494029567c5d08f',1,'glove_conf_s']]],
  ['variable_5flen',['variable_len',['../group__ble__srv__kat.html#gaabdc099488358b63624024a63bd7d4b2',1,'kat_char_s']]]
];
