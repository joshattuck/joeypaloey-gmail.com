var searchData=
[
  ['note',['note',['../structglove__change__evt__t.html#ab665ab7914c1736de7bc703aa520c130',1,'glove_change_evt_t']]],
  ['notification_5fenabled',['notification_enabled',['../group__ble__srv__kat.html#ga67243b5927ababa0ad84c92596a082eb',1,'kat_char_s']]],
  ['nrf_5fdrv_5fadc_5fchannel',['nrf_drv_adc_channel',['../structglove__finger__t.html#af4e8599bdeb44aa2e41480d038edf9ce',1,'glove_finger_t']]],
  ['nrf_5fdrv_5ftwi',['nrf_drv_twi',['../i2c_8c.html#a1b065994636bf25bd4077a1005b7bd01',1,'i2c.c']]]
];
