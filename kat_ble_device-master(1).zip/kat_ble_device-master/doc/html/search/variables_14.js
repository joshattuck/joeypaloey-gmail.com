var searchData=
[
  ['z',['z',['../group__ble__srv__kat.html#gae1e8f72bba4b9687651a2bc796372272',1,'kat_sensor_3d_data_t']]]
];
