var searchData=
[
  ['on_5fadv_5fevt',['on_adv_evt',['../group__ble__sdk__uart__over__ble__main.html#ga438975f6ac624c8570220ab1c842ba1e',1,'main.c']]],
  ['on_5fble_5fevt',['on_ble_evt',['../group__ble__sdk__uart__over__ble__main.html#gad083cb3569230d7ecbf2d01ef2a2c1d9',1,'main.c']]],
  ['on_5fconn_5fparams_5fevt',['on_conn_params_evt',['../group__ble__sdk__uart__over__ble__main.html#ga3518a4402961dbde9a52c7de6211ad7a',1,'main.c']]],
  ['or',['OR',['../license_8txt.html#a0e2380ba7a0f728226a7f1ce1b9b3d21',1,'license.txt']]]
];
