var searchData=
[
  ['nordic_20uart_20service',['Nordic UART Service',['../group__ble__sdk__srv__nus.html',1,'']]]
];
