var searchData=
[
  ['ble_5fmidi_5fmax_5frx_5fchar_5flen',['BLE_MIDI_MAX_RX_CHAR_LEN',['../ble__midi_8c.html#ad379fc5b09d775d0ed31fe3a3157990b',1,'ble_midi.c']]],
  ['ble_5fmidi_5fmax_5ftx_5fchar_5flen',['BLE_MIDI_MAX_TX_CHAR_LEN',['../ble__midi_8c.html#ab2d5259c7f2905eac54e65c79d41f0f9',1,'ble_midi.c']]],
  ['ble_5fuuid_5fmidi_5fmidiio_5fcharacteristic',['BLE_UUID_MIDI_MIDIIO_CHARACTERISTIC',['../ble__midi_8c.html#aa5c6850f992b4527d6e886273fba8487',1,'ble_midi.c']]],
  ['ble_5fuuid_5fmidi_5frx_5fcharacteristic',['BLE_UUID_MIDI_RX_CHARACTERISTIC',['../ble__midi_8c.html#a7cc363ae43ded51fa354848a59f8ec32',1,'ble_midi.c']]],
  ['ble_5fuuid_5fmidi_5ftx_5fcharacteristic',['BLE_UUID_MIDI_TX_CHARACTERISTIC',['../ble__midi_8c.html#a8c92ff4b96644db76216885d9b081164',1,'ble_midi.c']]],
  ['bno055_5faddress_5fa',['BNO055_ADDRESS_A',['../bno055_8h.html#ac3cdd930d950b35e2041e394d5f44693',1,'bno055.h']]],
  ['bno055_5faddress_5fb',['BNO055_ADDRESS_B',['../bno055_8h.html#aa141fc6fa09b855e6bda7e792bf54e21',1,'bno055.h']]],
  ['bno055_5fid',['BNO055_ID',['../bno055_8h.html#a5d61e3776e3b3017ed5e2d84ed9ec578',1,'bno055.h']]]
];
