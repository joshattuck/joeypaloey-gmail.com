var searchData=
[
  ['fat_5ftesting_5fonly',['FAT_TESTING_ONLY',['../sd_8c.html#a4c9caedf210e9e4e61475e4e86293123',1,'sd.c']]],
  ['feedback_5fpin_5ftoggle',['feedback_pin_toggle',['../group__ble__sdk__uart__over__ble__main.html#ga2fe53dfb557f5bf80e2792deefe4bba4',1,'main.c']]],
  ['feedback_5fvalue_5fchanged_5fhandler',['feedback_value_changed_handler',['../group__ble__sdk__uart__over__ble__main.html#ga920a14c07d9d525c6e75178e2e2a3a56',1,'main.c']]],
  ['fingers',['fingers',['../structglove__conf__s.html#a33b96f30d03d012653a007a1c9869ce5',1,'glove_conf_s']]],
  ['first_5fconn_5fparams_5fupdate_5fdelay',['FIRST_CONN_PARAMS_UPDATE_DELAY',['../group__ble__sdk__uart__over__ble__main.html#ga7204f7a367e8f1ac53ef62c4ad220efc',1,'main.c']]]
];
