var searchData=
[
  ['fingers',['fingers',['../structglove__conf__s.html#a33b96f30d03d012653a007a1c9869ce5',1,'glove_conf_s']]]
];
