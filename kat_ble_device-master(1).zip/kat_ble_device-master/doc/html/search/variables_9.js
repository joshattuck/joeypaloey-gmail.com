var searchData=
[
  ['last_5fupdated',['last_updated',['../group__ble__srv__kat.html#ga9003b66c05d308ada81a636303edf1a9',1,'kat_char_s']]],
  ['len',['len',['../group__ble__srv__kat.html#ga03a61ea8a158574f3574610df1def772',1,'kat_char_s']]],
  ['len_5fmax',['len_max',['../group__ble__srv__kat.html#gac0fc9760c879927983a40cc8aa23a5fc',1,'kat_char_s']]],
  ['licensable',['licensable',['../license_8txt.html#ac67ed50688068d66e5f5b2f0bbae518b',1,'license.txt']]],
  ['limited',['limited',['../license_8txt.html#af768dc631a6b3cebe47375edbc41d9c9',1,'license.txt']]]
];
