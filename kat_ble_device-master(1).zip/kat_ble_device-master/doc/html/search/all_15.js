var searchData=
[
  ['x',['x',['../group__ble__srv__kat.html#ga66ed20cd5eb262caa87685bb66bd8b99',1,'kat_sensor_1d_data_t::x()'],['../group__ble__srv__kat.html#ga4e76840581c05fde220b54fd02ddefe9',1,'kat_sensor_2d_data_t::x()'],['../group__ble__srv__kat.html#ga18abc5a292c3bbbeaaf81f0dfeaac541',1,'kat_sensor_3d_data_t::x()']]]
];
