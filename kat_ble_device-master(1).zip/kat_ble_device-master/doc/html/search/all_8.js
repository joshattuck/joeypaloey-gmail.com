var searchData=
[
  ['i2c_2ec',['i2c.c',['../i2c_8c.html',1,'']]],
  ['i2c_2eh',['i2c.h',['../i2c_8h.html',1,'']]],
  ['i2c_5finit',['i2c_init',['../i2c_8c.html#a48591085c78b33b40ce44c253560dc8a',1,'i2c_init(uint8_t pin_scl, uint8_t pin_sda):&#160;i2c.c'],['../i2c_8h.html#a48591085c78b33b40ce44c253560dc8a',1,'i2c_init(uint8_t pin_scl, uint8_t pin_sda):&#160;i2c.c']]],
  ['i2c_5fread8',['i2c_read8',['../i2c_8c.html#a171ce676b586b3725e2bf45ec3c1728a',1,'i2c_read8(uint8_t device, uint8_t reg):&#160;i2c.c'],['../i2c_8h.html#a171ce676b586b3725e2bf45ec3c1728a',1,'i2c_read8(uint8_t device, uint8_t reg):&#160;i2c.c']]],
  ['i2c_5fread_5fmany',['i2c_read_many',['../i2c_8c.html#ab10c7d37032da4a2aa26bf98c0bb4a59',1,'i2c_read_many(uint8_t device, uint8_t reg, uint8_t *buffer, uint8_t len):&#160;i2c.c'],['../i2c_8h.html#ab10c7d37032da4a2aa26bf98c0bb4a59',1,'i2c_read_many(uint8_t device, uint8_t reg, uint8_t *buffer, uint8_t len):&#160;i2c.c']]],
  ['i2c_5fwrite8',['i2c_write8',['../i2c_8c.html#adbd5c5908eae07e1d8881e4d38fdd89d',1,'i2c_write8(uint8_t device, uint8_t reg, uint8_t value):&#160;i2c.c'],['../i2c_8h.html#adbd5c5908eae07e1d8881e4d38fdd89d',1,'i2c_write8(uint8_t device, uint8_t reg, uint8_t value):&#160;i2c.c']]],
  ['imu_5finit',['imu_init',['../group__ble__sdk__uart__over__ble__main.html#ga5023a8bb8384b6ce3b44002904ecacb6',1,'main.c']]],
  ['imu_5fsampling_5frate_5fchanged_5fhandler',['imu_sampling_rate_changed_handler',['../group__ble__sdk__uart__over__ble__main.html#gac71dbeaaf3fc49bcd0e610dd1ddbab05',1,'main.c']]],
  ['imu_5fvector_5ft',['imu_vector_t',['../bno055_8h.html#a6780e112b0c8520f4cd59ab48b1244d4',1,'bno055.h']]],
  ['initialize_5fsdhc',['Initialize_SDHC',['../sd_8c.html#a88fede7c63d89ad479899b3035e31ea5',1,'Initialize_SDHC(void):&#160;sd.c'],['../sd_8h.html#a88fede7c63d89ad479899b3035e31ea5',1,'Initialize_SDHC(void):&#160;sd.c']]],
  ['is_5fnotification_5fenabled',['is_notification_enabled',['../structble__midi__s.html#ac035bc07be7f3ba67f27dc821bc9da1b',1,'ble_midi_s']]],
  ['is_5fsrvc_5fchanged_5fcharact_5fpresent',['IS_SRVC_CHANGED_CHARACT_PRESENT',['../group__ble__sdk__uart__over__ble__main.html#gac0ad4bcfe8e9edf6794e9a796378978a',1,'main.c']]]
];
