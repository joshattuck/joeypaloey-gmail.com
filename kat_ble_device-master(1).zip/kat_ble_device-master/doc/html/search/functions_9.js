var searchData=
[
  ['licenses',['licenses',['../license_8txt.html#a047c3e7aeafcfa387ebaca8183a90a7d',1,'license.txt']]]
];
