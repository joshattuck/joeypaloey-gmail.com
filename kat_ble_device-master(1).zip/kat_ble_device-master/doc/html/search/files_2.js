var searchData=
[
  ['glove_2ec',['glove.c',['../glove_8c.html',1,'']]],
  ['glove_2eh',['glove.h',['../glove_8h.html',1,'']]]
];
