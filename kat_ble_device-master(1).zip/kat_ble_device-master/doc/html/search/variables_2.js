var searchData=
[
  ['change',['change',['../structglove__change__evt__t.html#adfde5727084233f273763f79b2cdc94b',1,'glove_change_evt_t']]],
  ['channel',['channel',['../structglove__change__evt__t.html#ace0f16fad144a99cb006cd968674d4e5',1,'glove_change_evt_t']]],
  ['char_5ftype',['char_type',['../group__ble__srv__kat.html#ga772bdfa95d56e830386ce9f3ad69bfc8',1,'kat_char_s']]],
  ['characteristics_5fnum',['characteristics_num',['../group__ble__srv__kat.html#ga64304c943e6d5064f83eb40d86c05155',1,'ble_kat_s::characteristics_num()'],['../group__ble__srv__kat.html#gaeb15e95e35198a24b14974a1a3fcd07b',1,'ble_kat_init_t::characteristics_num()']]],
  ['conn_5fhandle',['conn_handle',['../structble__midi__s.html#a34fbbcbf90011f1b339fc55896cd7531',1,'ble_midi_s::conn_handle()'],['../group__ble__srv__kat.html#gaa55435600afbe3fc60f780800a44fbad',1,'ble_kat_s::conn_handle()']]],
  ['current_5fmode',['current_mode',['../bno055_8c.html#a68819d7226c4dac33f0a269c30401e82',1,'bno055.c']]]
];
