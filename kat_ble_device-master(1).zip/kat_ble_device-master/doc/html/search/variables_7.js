var searchData=
[
  ['handles',['handles',['../group__ble__srv__kat.html#ga87fd7e842cf65329485b5ab4b096f602',1,'kat_char_s']]]
];
