var searchData=
[
  ['write8',['write8',['../bno055_8c.html#aafaa7b9e254fc73358e0ec8cd94b1a25',1,'bno055.c']]],
  ['write_5fmultiple_5fblocks',['WRITE_MULTIPLE_BLOCKS',['../sd_8h.html#a8cf5245e676d5405878f2af647491553',1,'sd.h']]],
  ['write_5fsingle_5fblock',['WRITE_SINGLE_BLOCK',['../sd_8h.html#ae24d09e65670aa853aa83889b55a92a0',1,'sd.h']]]
];
