var searchData=
[
  ['is_5fnotification_5fenabled',['is_notification_enabled',['../structble__midi__s.html#ac035bc07be7f3ba67f27dc821bc9da1b',1,'ble_midi_s']]]
];
