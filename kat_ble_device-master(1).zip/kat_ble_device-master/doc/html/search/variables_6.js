var searchData=
[
  ['glove_5fvalues_5fchanged_5fhandler',['glove_values_changed_handler',['../structglove__conf__s.html#a0ecae5d8abdbe41a07f3aec249babaff',1,'glove_conf_s']]],
  ['gyro_5foffset_5fx',['gyro_offset_x',['../structadafruit__bno055__offsets__t.html#a2fc630351b49184c2b5cf962830d21df',1,'adafruit_bno055_offsets_t']]],
  ['gyro_5foffset_5fy',['gyro_offset_y',['../structadafruit__bno055__offsets__t.html#ad5187e06cd3f9a4f6555b698821f8de3',1,'adafruit_bno055_offsets_t']]],
  ['gyro_5foffset_5fz',['gyro_offset_z',['../structadafruit__bno055__offsets__t.html#ad2c9f37b016d3750dc9311ad667383f8',1,'adafruit_bno055_offsets_t']]],
  ['gyro_5frev',['gyro_rev',['../structadafruit__bno055__rev__info__t.html#a3da8566e5bb550b4c24effe2f5c3d147',1,'adafruit_bno055_rev_info_t']]]
];
