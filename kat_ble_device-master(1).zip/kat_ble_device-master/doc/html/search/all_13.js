var searchData=
[
  ['value',['value',['../structglove__change__evt__t.html#a6885d7021275feb60f43ce9a02c4b8be',1,'glove_change_evt_t::value()'],['../group__ble__srv__kat.html#gaf58c7f52f78596cb87b387b7ae69c1d8',1,'kat_feedback_data_t::value()']]],
  ['value_5fmax',['value_max',['../structglove__conf__s.html#ae712502887cd49b4472543424adf5b19',1,'glove_conf_s']]],
  ['value_5fmin',['value_min',['../structglove__conf__s.html#a47c5a7a6695f95a00d0dfb7c512d44bd',1,'glove_conf_s']]],
  ['value_5fptr',['value_ptr',['../structglove__finger__t.html#a8efeaa4895470da7b329bf11bebe216f',1,'glove_finger_t']]],
  ['values',['values',['../structglove__conf__s.html#a22582017edce85f0c9528d47e1e66872',1,'glove_conf_s']]],
  ['values_5fold',['values_old',['../structglove__conf__s.html#a22a2e243fef9b252f494029567c5d08f',1,'glove_conf_s']]],
  ['variable_5flen',['variable_len',['../group__ble__srv__kat.html#gaabdc099488358b63624024a63bd7d4b2',1,'kat_char_s']]],
  ['vector_5faccelerometer',['VECTOR_ACCELEROMETER',['../bno055_8h.html#a94564c150f8ba3f0dbb679918231a179acc3b3076ab1a04df975cf7d24dd3c0bd',1,'bno055.h']]],
  ['vector_5feuler',['VECTOR_EULER',['../bno055_8h.html#a94564c150f8ba3f0dbb679918231a179a424cd2e7452cbed7576aa32b6eb449bc',1,'bno055.h']]],
  ['vector_5fgravity',['VECTOR_GRAVITY',['../bno055_8h.html#a94564c150f8ba3f0dbb679918231a179a70807bf085cec93ea6e563c5a3dd6185',1,'bno055.h']]],
  ['vector_5fgyroscope',['VECTOR_GYROSCOPE',['../bno055_8h.html#a94564c150f8ba3f0dbb679918231a179aac75f41ecda4ac504e2110b6faa2f447',1,'bno055.h']]],
  ['vector_5flinearaccel',['VECTOR_LINEARACCEL',['../bno055_8h.html#a94564c150f8ba3f0dbb679918231a179a7c1b53745eb8705d4073684a5053baf0',1,'bno055.h']]],
  ['vector_5fmagnetometer',['VECTOR_MAGNETOMETER',['../bno055_8h.html#a94564c150f8ba3f0dbb679918231a179a60a6e0242db30c34de57e837c2c32974',1,'bno055.h']]]
];
