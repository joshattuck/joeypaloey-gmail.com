var searchData=
[
  ['y',['y',['../group__ble__srv__kat.html#ga92ab0e2a4facb746a3b18653a4f1c9ff',1,'kat_sensor_1d_data_t::y()'],['../group__ble__srv__kat.html#ga5fc407abbca777bc50904ecf08e60cb1',1,'kat_sensor_2d_data_t::y()'],['../group__ble__srv__kat.html#ga520202df71bc19cfba9c9642fb6b802e',1,'kat_sensor_3d_data_t::y()']]]
];
