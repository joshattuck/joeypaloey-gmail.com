var searchData=
[
  ['p_5fcharacteristics',['p_characteristics',['../group__ble__srv__kat.html#ga8afbe8f3af8809e012d3391b41ae1e7f',1,'ble_kat_s::p_characteristics()'],['../group__ble__srv__kat.html#gad369e4a79a44b5bc4b2fa4928c6b258a',1,'ble_kat_init_t::p_characteristics()']]],
  ['p_5ffeedback_5fdata',['p_feedback_data',['../group__ble__srv__kat.html#ga21266e52765e60d14adb0edc22751250',1,'kat_char_s']]],
  ['p_5fkat',['p_kat',['../group__ble__srv__kat.html#gac234d1bc7b5572a6ad5142800b6360a8',1,'kat_char_s']]],
  ['p_5fname',['p_name',['../group__ble__srv__kat.html#ga64c26586584d38f56ac9a4ec215a12d9',1,'kat_char_s']]],
  ['p_5fsampling_5frate',['p_sampling_rate',['../group__ble__srv__kat.html#gad0e6232064f80d76082ef6ef2f4f76da',1,'kat_char_s']]],
  ['p_5fsensor_5f1d_5fdata',['p_sensor_1d_data',['../group__ble__srv__kat.html#gab2bb8c37493ff1bba04eade79549f8ad',1,'kat_char_s']]],
  ['p_5fsensor_5f2d_5fdata',['p_sensor_2d_data',['../group__ble__srv__kat.html#ga454f583ce5309da8840591202b9f0398',1,'kat_char_s']]],
  ['p_5fsensor_5f3d_5fdata',['p_sensor_3d_data',['../group__ble__srv__kat.html#ga23439516e36a482ab1b2debaf07548c0',1,'kat_char_s']]],
  ['p_5fvalue',['p_value',['../group__ble__srv__kat.html#ga4ff51b906167f203428133883b10d692',1,'kat_char_s']]],
  ['pin',['pin',['../structglove__finger__t.html#a049fb6f0018d101a4e12d196dfe1950c',1,'glove_finger_t::pin()'],['../group__ble__srv__kat.html#ga03895da42853ea232c0c0ba6a9fbfc82',1,'kat_feedback_data_t::pin()']]],
  ['pin_5fecho',['pin_echo',['../structhcsr04__t.html#ac0d95b23f61f25a76c1abb19113d8eba',1,'hcsr04_t']]],
  ['pin_5ftrig',['pin_trig',['../structhcsr04__t.html#ae91ecab4a4d9f6444e992f0cd931f30b',1,'hcsr04_t']]],
  ['ppi_5fchannel',['ppi_channel',['../structhcsr04__t.html#a8bb8fc0f1c73cb69d005b5defc100358',1,'hcsr04_t']]]
];
