var searchData=
[
  ['nordic_20uart_20service',['Nordic UART Service',['../group__ble__sdk__srv__nus.html',1,'']]],
  ['next_5fconn_5fparams_5fupdate_5fdelay',['NEXT_CONN_PARAMS_UPDATE_DELAY',['../group__ble__sdk__uart__over__ble__main.html#gadf85796ef07632ed27e0bce9509d9245',1,'main.c']]],
  ['note',['note',['../structglove__change__evt__t.html#ab665ab7914c1736de7bc703aa520c130',1,'glove_change_evt_t']]],
  ['notification_5fenabled',['notification_enabled',['../group__ble__srv__kat.html#ga67243b5927ababa0ad84c92596a082eb',1,'kat_char_s']]],
  ['nrf_5fdrv_5fadc_5fchannel',['nrf_drv_adc_channel',['../structglove__finger__t.html#af4e8599bdeb44aa2e41480d038edf9ce',1,'glove_finger_t']]],
  ['nrf_5fdrv_5ftwi',['nrf_drv_twi',['../i2c_8c.html#a1b065994636bf25bd4077a1005b7bd01',1,'i2c.c']]],
  ['num_5fbno055_5foffset_5fregisters',['NUM_BNO055_OFFSET_REGISTERS',['../bno055_8h.html#a419d749dedf96924ff95aad0c457eb0e',1,'bno055.h']]]
];
