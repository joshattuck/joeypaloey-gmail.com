var searchData=
[
  ['conn_5fparams_5ferror_5fhandler',['conn_params_error_handler',['../group__ble__sdk__uart__over__ble__main.html#ga4538ed130db3bf7fc68b76a4d9e032fa',1,'main.c']]],
  ['conn_5fparams_5finit',['conn_params_init',['../group__ble__sdk__uart__over__ble__main.html#gaf61b6c1c47f5c96b169ff81c345d7849',1,'main.c']]]
];
