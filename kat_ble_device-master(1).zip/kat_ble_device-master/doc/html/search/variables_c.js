var searchData=
[
  ['ocr',['ocr',['../sd_8c.html#ad7363695f55cf1fa5440a30bcda150c5',1,'sd.c']]],
  ['of',['OF',['../license_8txt.html#ae80d6f994d26aa56b7814cd4e6e98480',1,'license.txt']]],
  ['on_5fwrite_5fhandler',['on_write_handler',['../group__ble__srv__kat.html#ga3881f9d04b763fe3856de24541d5f213',1,'kat_char_s']]]
];
