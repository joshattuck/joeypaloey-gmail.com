var searchData=
[
  ['abstract_2etxt',['Abstract.txt',['../_abstract_8txt.html',1,'']]]
];
