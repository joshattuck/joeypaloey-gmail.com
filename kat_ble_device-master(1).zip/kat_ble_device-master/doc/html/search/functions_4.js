var searchData=
[
  ['feedback_5fpin_5ftoggle',['feedback_pin_toggle',['../group__ble__sdk__uart__over__ble__main.html#ga2fe53dfb557f5bf80e2792deefe4bba4',1,'main.c']]],
  ['feedback_5fvalue_5fchanged_5fhandler',['feedback_value_changed_handler',['../group__ble__sdk__uart__over__ble__main.html#ga920a14c07d9d525c6e75178e2e2a3a56',1,'main.c']]]
];
