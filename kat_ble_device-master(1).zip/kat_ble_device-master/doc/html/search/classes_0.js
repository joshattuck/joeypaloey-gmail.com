var searchData=
[
  ['adafruit_5fbno055_5foffsets_5ft',['adafruit_bno055_offsets_t',['../structadafruit__bno055__offsets__t.html',1,'']]],
  ['adafruit_5fbno055_5frev_5finfo_5ft',['adafruit_bno055_rev_info_t',['../structadafruit__bno055__rev__info__t.html',1,'']]]
];
