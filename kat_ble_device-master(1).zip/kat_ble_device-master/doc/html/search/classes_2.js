var searchData=
[
  ['glove_5fchange_5fevt_5ft',['glove_change_evt_t',['../structglove__change__evt__t.html',1,'']]],
  ['glove_5fconf_5fs',['glove_conf_s',['../structglove__conf__s.html',1,'']]],
  ['glove_5ffinger_5ft',['glove_finger_t',['../structglove__finger__t.html',1,'']]]
];
