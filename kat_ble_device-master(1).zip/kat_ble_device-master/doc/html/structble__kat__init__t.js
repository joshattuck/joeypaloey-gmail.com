var structble__kat__init__t =
[
    [ "characteristics_num", "group__ble__srv__kat.html#gaeb15e95e35198a24b14974a1a3fcd07b", null ],
    [ "data_handler", "group__ble__srv__kat.html#ga5142f39819c7530e211df632d7c6dad1", null ],
    [ "p_characteristics", "group__ble__srv__kat.html#gad369e4a79a44b5bc4b2fa4928c6b258a", null ]
];