var structglove__finger__t =
[
    [ "nrf_drv_adc_channel", "structglove__finger__t.html#af4e8599bdeb44aa2e41480d038edf9ce", null ],
    [ "pin", "structglove__finger__t.html#a049fb6f0018d101a4e12d196dfe1950c", null ],
    [ "value_ptr", "structglove__finger__t.html#a8efeaa4895470da7b329bf11bebe216f", null ]
];