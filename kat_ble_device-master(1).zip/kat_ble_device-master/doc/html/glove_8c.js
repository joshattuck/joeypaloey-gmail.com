var glove_8c =
[
    [ "glove_conf_init", "glove_8c.html#abf04c757482092e1a402e76c5aedab7f", null ],
    [ "glove_finger_init", "glove_8c.html#a39a8e6b857dcd06e7b4af1047cdab6a4", null ],
    [ "glove_sample", "glove_8c.html#a0a901eb1ea75f006a2c8b2cbd770ddd6", null ],
    [ "glove_sampling_done", "glove_8c.html#ae1f3779525aa12dc587a844a75fa1008", null ]
];