var structble__midi__message__t =
[
    [ "data1", "structble__midi__message__t.html#aaad427d975b66a68994f0fba12d019f3", null ],
    [ "data2", "structble__midi__message__t.html#ab069bc9200e05f6c3e37141022945ec8", null ],
    [ "status", "structble__midi__message__t.html#a82043dd755cf86266094ea72ffb16c19", null ],
    [ "timestamp_lo", "structble__midi__message__t.html#a567beb59fb96e851b0c4da1c29028c33", null ]
];