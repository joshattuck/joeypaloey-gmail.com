var structkat__3d__data__t =
[
    [ "x", "group__ble__srv__kat.html#ga9a1e4be236160543e32911c9c808dde7", null ],
    [ "y", "group__ble__srv__kat.html#ga02448633c35f84fb9d29c896bff77ef1", null ],
    [ "z", "group__ble__srv__kat.html#ga38bd3d4c857a242edea64a67afacb392", null ]
];