var files =
[
    [ "ble_midi.c", "ble__midi_8c.html", "ble__midi_8c" ],
    [ "ble_midi.h", "ble__midi_8h.html", "ble__midi_8h" ],
    [ "bno055.c", "bno055_8c.html", "bno055_8c" ],
    [ "bno055.h", "bno055_8h.html", "bno055_8h" ],
    [ "glove.c", "glove_8c.html", "glove_8c" ],
    [ "glove.h", "glove_8h.html", "glove_8h" ],
    [ "hcsr04.c", "hcsr04_8c.html", "hcsr04_8c" ],
    [ "hcsr04.h", "hcsr04_8h.html", "hcsr04_8h" ],
    [ "i2c.c", "i2c_8c.html", "i2c_8c" ],
    [ "i2c.h", "i2c_8h.html", "i2c_8h" ],
    [ "kat.c", "kat_8c.html", "kat_8c" ],
    [ "kat.h", "kat_8h.html", "kat_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "sd.c", "sd_8c.html", "sd_8c" ],
    [ "sd.h", "sd_8h.html", "sd_8h" ]
];