var glove_8h =
[
    [ "glove_change_evt_t", "structglove__change__evt__t.html", "structglove__change__evt__t" ],
    [ "glove_finger_t", "structglove__finger__t.html", "structglove__finger__t" ],
    [ "glove_conf_s", "structglove__conf__s.html", "structglove__conf__s" ],
    [ "GLOVE_ADC_INPUT_AND_SCALING", "glove_8h.html#ad9d215a15caad3195a9d7f0e5fdb105e", null ],
    [ "GLOVE_ADC_REFERENCE", "glove_8h.html#a3886d7d424f2b091fae0e3910b055a3c", null ],
    [ "GLOVE_ADC_RESOLUTION", "glove_8h.html#a4f56e50120da8a3c45ccdc75ce7c9eec", null ],
    [ "GLOVE_NUM_FINGERS", "glove_8h.html#ac138ab19a331482c19e8bdddd333260c", null ],
    [ "GLOVE_PRESSURE_LEVELS", "glove_8h.html#a9ba7096329d97d3a400b4bfed8cfbb6b", null ],
    [ "glove_conf_t", "glove_8h.html#a04cf4d26fffa93702290e37dc4e52f4c", null ],
    [ "glove_values_changed_handler_t", "glove_8h.html#a44b6662ff4d561f3744f64b1611e9ac3", null ],
    [ "glove_change_t", "glove_8h.html#a1de3a8a84144391b329ed8c9231897be", [
      [ "GLOVE_CHANGE_NONE", "glove_8h.html#a1de3a8a84144391b329ed8c9231897beaeed8f0a9241ab68426e7774c43917088", null ],
      [ "GLOVE_CHANGE_ON", "glove_8h.html#a1de3a8a84144391b329ed8c9231897beab19830bb947f9b7c406bceeb8ca8bc59", null ],
      [ "GLOVE_CHANGE_OFF", "glove_8h.html#a1de3a8a84144391b329ed8c9231897beabb9f3506ac2cba12078816eb5cd8b953", null ],
      [ "GLOVE_CHANGE_PRESSURE_CHANGE", "glove_8h.html#a1de3a8a84144391b329ed8c9231897bea634bad0f99f15a16aaf55bd9a53c483e", null ]
    ] ],
    [ "glove_conf_init", "glove_8h.html#abf04c757482092e1a402e76c5aedab7f", null ],
    [ "glove_finger_init", "glove_8h.html#a39a8e6b857dcd06e7b4af1047cdab6a4", null ],
    [ "glove_sample", "glove_8h.html#a0a901eb1ea75f006a2c8b2cbd770ddd6", null ],
    [ "glove_sampling_done", "glove_8h.html#ae1f3779525aa12dc587a844a75fa1008", null ]
];