var structble__midi__init__t =
[
    [ "data_handler", "structble__midi__init__t.html#a6362b8ea82a192037147bbc34a1a1a34", null ]
];