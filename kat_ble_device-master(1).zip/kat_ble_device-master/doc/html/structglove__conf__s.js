var structglove__conf__s =
[
    [ "events", "structglove__conf__s.html#a9160b87f4886f56befec7509f4056c40", null ],
    [ "fingers", "structglove__conf__s.html#a33b96f30d03d012653a007a1c9869ce5", null ],
    [ "glove_values_changed_handler", "structglove__conf__s.html#a0ecae5d8abdbe41a07f3aec249babaff", null ],
    [ "value_max", "structglove__conf__s.html#ae712502887cd49b4472543424adf5b19", null ],
    [ "value_min", "structglove__conf__s.html#a47c5a7a6695f95a00d0dfb7c512d44bd", null ],
    [ "values", "structglove__conf__s.html#a22582017edce85f0c9528d47e1e66872", null ],
    [ "values_old", "structglove__conf__s.html#a22a2e243fef9b252f494029567c5d08f", null ]
];