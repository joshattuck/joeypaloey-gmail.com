var structkat__sensor__t =
[
    [ "handles", "group__ble__srv__kat.html#ga439e3d4ec560464ac9cb18dfa86a8c10", null ],
    [ "last_updated", "group__ble__srv__kat.html#ga4855002e7f1b7931ef708d48f18dc943", null ],
    [ "notification_enabled", "group__ble__srv__kat.html#gaa410b9ff30088c984a0273b8db9a587b", null ],
    [ "p_kat", "group__ble__srv__kat.html#ga6a66d5c0bc9593d921a37e3d2634739f", null ],
    [ "p_name", "group__ble__srv__kat.html#gac5ff45bed096ec1eccb300d1b33cfb55", null ],
    [ "sampling_rate", "group__ble__srv__kat.html#gabac9cd438d74834731f212f1d02ca8ef", null ],
    [ "uuid_minor", "group__ble__srv__kat.html#ga76ffab2eda7b9b4aac8a2bcc09048c72", null ],
    [ "value", "group__ble__srv__kat.html#gacd5bcf387c2f4527d4c2cde9798152c6", null ]
];