var dir_8d27458189a97975fd9e7cd5ff96dbee =
[
    [ "nrf_drv_config.h", "nrf__drv__config_8h_source.html", null ]
];