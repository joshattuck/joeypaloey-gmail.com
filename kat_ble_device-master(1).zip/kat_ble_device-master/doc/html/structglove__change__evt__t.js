var structglove__change__evt__t =
[
    [ "change", "structglove__change__evt__t.html#adfde5727084233f273763f79b2cdc94b", null ],
    [ "channel", "structglove__change__evt__t.html#ace0f16fad144a99cb006cd968674d4e5", null ],
    [ "note", "structglove__change__evt__t.html#ab665ab7914c1736de7bc703aa520c130", null ],
    [ "value", "structglove__change__evt__t.html#a6885d7021275feb60f43ce9a02c4b8be", null ]
];