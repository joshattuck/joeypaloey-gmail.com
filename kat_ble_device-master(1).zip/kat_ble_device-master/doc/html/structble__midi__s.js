var structble__midi__s =
[
    [ "conn_handle", "structble__midi__s.html#a34fbbcbf90011f1b339fc55896cd7531", null ],
    [ "data_handler", "structble__midi__s.html#a84859af15131839937b3c56ad1aacfd1", null ],
    [ "is_notification_enabled", "structble__midi__s.html#ac035bc07be7f3ba67f27dc821bc9da1b", null ],
    [ "midi_timestamp", "structble__midi__s.html#aa4ac0c2bbf42f47930ee7c57f37f6a80", null ],
    [ "midiio_handles", "structble__midi__s.html#a3918095d5e5ff5209fd75600797512b6", null ],
    [ "service_handle", "structble__midi__s.html#aa8370ad74c8dca4d5ac92604e768b8c5", null ],
    [ "uuid_type", "structble__midi__s.html#a6d6196468d950eb48f84b4324e59abe0", null ]
];