/* Copyright (c) 2014 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/** @file
 *
 * @defgroup ble_sdk_uart_over_ble_main main.c
 * @{
 * @ingroup  ble_sdk_app_nus_eval
 * @brief    UART over BLE application main file.
 *
 * This file contains the source code for a sample application that uses the Nordic UART service.
 * This application uses the @ref srvlib_conn_params module.
 */

#include <stdint.h>
#include <string.h>
#include <math.h>
#include "nordic_common.h"
#include "nrf.h"
#include "ble_hci.h"
#include "ble_advdata.h"
#include "ble_advertising.h"
#include "ble_conn_params.h"
#include "softdevice_handler.h"
#include "softdevice_handler_appsh.h"
#include "app_timer.h"
#include "nrf_gpiote.h"
#include "nrf_gpio.h"
#include "nrf_delay.h"
#include "app_button.h"
#include "ble_nus.h"
#include "app_util_platform.h"
#include "app_scheduler.h"
#include "nrf_drv_rtc.h"
#include "bsp.h"
#include "bsp_btn_ble.h"
#include "app_timer_appsh.h"
#include "nrf_gpio.h"
#include "ble_dis.h"
#include "ble_bas.h"
#include "device_manager.h"
#include "nrf_drv_rng.h"
#include "nrf_rng.h"
#include "nrf_drv_adc.h"
#include "nrf_drv_timer.h"
#include "pstorage.h"
#include "nrf_drv_ppi.h"

// ADC
#include "vbat.h"
#include "nrf_drv_adc.h"
#include "rtc_timestamp.h"
#include "custom_board.h" // fix the parsing in eclipse
#include "kat.h"
#include "hcsr04.h"

#if USE_IMU==1
	#if IMU==055
		#include "bno055.h"
	#endif // IMU==BNO055
	#if IMU==9250

		#include "i2c.h"
		#include "app_twi.h"
		#include "nrf_twi.h"
		#include "nrf_drv_twi.h"
		#include "mpu9250.h"
	#endif
#endif //USE_IMU


#define IS_SRVC_CHANGED_CHARACT_PRESENT 0                                           /**< Include the service_changed characteristic. If not enabled, the server's database cannot be changed for the lifetime of the device. */

#define CENTRAL_LINK_COUNT              0                                           /**< Number of central links used by the application. When changing this number remember to adjust the RAM settings*/
#define PERIPHERAL_LINK_COUNT           1                                         /**< Number of peripheral links used by the application. When changing this number remember to adjust the RAM settings*/

#define DEVICE_NAME                     "SMALLKAT"                               /**< Name of device. Will be included in the advertising data. */
#define MANUFACTURER_NAME                "JM"                      /**< Manufacturer. Will be passed to Device Information Service. */
#define MODEL_NUMBER                	"REVD"                      				/**< Model. Will be passed to Device Information Service. */

#define APP_ADV_INTERVAL                64                                          /**< The advertising interval (in units of 0.625 ms. This value corresponds to 40 ms). */
#define APP_ADV_TIMEOUT_IN_SECONDS      180                                         /**< The advertising timeout (in units of seconds). */

#define APP_TIMER_PRESCALER             0                                           /**< Value of the RTC1 PRESCALER register. */
#define APP_TIMER_OP_QUEUE_SIZE         4                                           /**< Size of timer operation queues. */

#define MIN_CONN_INTERVAL               MSEC_TO_UNITS(7.5, UNIT_1_25_MS)             /**< Minimum acceptable connection interval (20 ms), Connection interval uses 1.25 ms units. */
#define MAX_CONN_INTERVAL               MSEC_TO_UNITS(15, UNIT_1_25_MS)             /**< Maximum acceptable connection interval (75 ms), Connection interval uses 1.25 ms units. */
#define SLAVE_LATENCY                   15                                           /**< Slave latency. */
#define CONN_SUP_TIMEOUT                MSEC_TO_UNITS(4000, UNIT_10_MS)             /**< Connection supervisory timeout (4 seconds), Supervision Timeout uses 10 ms units. */


#define FIRST_CONN_PARAMS_UPDATE_DELAY  APP_TIMER_TICKS(5000, APP_TIMER_PRESCALER)  /**< Time from initiating event (connect or start of notification) to first time sd_ble_gap_conn_param_update is called (5 seconds). */
#define NEXT_CONN_PARAMS_UPDATE_DELAY   APP_TIMER_TICKS(30000, APP_TIMER_PRESCALER) /**< Time between each call to sd_ble_gap_conn_param_update after the first call (30 seconds). */
#define MAX_CONN_PARAMS_UPDATE_COUNT    3                                           /**< Number of attempts before giving up the connection parameter negotiation. */

#define SEC_PARAM_BOND                  1                                           /**< Perform bonding. */
#define SEC_PARAM_MITM                  0                                           /**< Man In The Middle protection not required. */
#define SEC_PARAM_LESC                  0                                           /**< LE Secure Connections not enabled. */
#define SEC_PARAM_KEYPRESS              0                                           /**< Keypress notifications not enabled. */
#define SEC_PARAM_IO_CAPABILITIES       BLE_GAP_IO_CAPS_NONE                        /**< No I/O capabilities. */
#define SEC_PARAM_OOB                   0                                           /**< Out Of Band data not available. */
#define SEC_PARAM_MIN_KEY_SIZE          7                                           /**< Minimum encryption key size. */
#define SEC_PARAM_MAX_KEY_SIZE          16                                          /**< Maximum encryption key size. */

#define APP_ADV_FAST_INTERVAL           0x0028                                      /**< Fast advertising interval (in units of 0.625 ms. This value corresponds to 25 ms.). */
#define APP_ADV_SLOW_INTERVAL           0x0C80                                      /**< Slow advertising interval (in units of 0.625 ms. This value corrsponds to 2 seconds). */

#define APP_ADV_FAST_TIMEOUT            30                                          /**< The duration of the fast advertising period (in seconds). */
#define APP_ADV_SLOW_TIMEOUT            180                                         /**< The duration of the slow advertising period (in seconds). */

#define DEAD_BEEF                       0xDEADBEEF                                  /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */


#define BUTTON_DETECTION_DELAY    	APP_TIMER_TICKS(10, APP_TIMER_PRESCALER) /**< Delay from a GPIOTE event until a button is reported as pushed (in number of timer ticks). */


/**@brief Scheduler configuration defines */
#define SCHED_MAX_EVENT_DATA_SIZE        MAX(APP_TIMER_SCHED_EVT_SIZE,\
                                             BLE_STACK_HANDLER_SCHED_EVT_SIZE)          /**< Maximum size of scheduler events. */
#define SCHED_QUEUE_SIZE                 12                                             /**< Maximum number of events in the scheduler queue. */




enum {
	CHAR_ACC_IDX = 0,
	CHAR_ORIENT_IDX,
	CHAR_SONARS_IDX,
	CHAR_IMU_SAMPLING_RATE_IDX,
	CHAR_SONARS_SAMPLING_RATE_IDX,
	CHAR_BUZZ_FEEDBACK_IDX,
	CHAR_VIBR_FEEDBACK_IDX,
	CHAR_LASX_FEEDBACK_IDX,
	CHAR_LASY_FEEDBACK_IDX,
//	CHAR_MAG_IDX,
};


static uint16_t                         m_conn_handle = BLE_CONN_HANDLE_INVALID;    /**< Handle of the current connection. */

static ble_uuid_t                       m_adv_uuids[] = {
														{KAT_SERVICE_UUID_MINOR, KAT_SERVICE_UUID_TYPE},
														{BLE_UUID_DEVICE_INFORMATION_SERVICE, BLE_UUID_TYPE_BLE},
														{BLE_UUID_BATTERY_SERVICE, BLE_UUID_TYPE_BLE}};/**< Universally unique service identifier. */

// BLE Services
static ble_kat_t 				m_kat; 					/**< Structure holding KAT state, both values and bluetooth connection state/settings */
static ble_bas_t                m_bas;                  /**< Structure used to identify the battery service. */


APP_TIMER_DEF(m_kat_1ms_timer_id);					/**< KAT 1ms timer for updating the timestamp of events */
APP_TIMER_DEF(m_minimum_reporting_timer_id);		/**< 100ms timer to provide minimum reporting rate */
APP_TIMER_DEF(m_vbat_measurement_timer_id);			/**< Battery level measurement timer */
APP_TIMER_DEF(m_sampling_imu_timer_id);				/**< Accelerometer sampling timer */
APP_TIMER_DEF(m_sampling_sonars_timer_id);			/**< Sonars sampling timer */

// Feedback stuff
APP_TIMER_DEF(m_feedback_buzzer_timer_id);	/**< Buzzer beeping timer sampling timer */
APP_TIMER_DEF(m_feedback_vibr_timer_id);	/**< Buzzer beeping timer sampling timer */
APP_TIMER_DEF(m_feedback_las_x_timer_id);	/**< Laser X beeping timer sampling timer */
APP_TIMER_DEF(m_feedback_las_y_timer_id);	/**< Laser Y beeping timer sampling timer */
APP_TIMER_DEF(m_hcsr04_timer_id);


#define MINIMUM_REPORTING_DELAY    	APP_TIMER_TICKS(100, APP_TIMER_PRESCALER)
volatile uint8_t m_reported = 0;
volatile static uint8_t m_reported_flags[3][2] = {
		{CHAR_ACC_IDX, 0},
		{CHAR_ORIENT_IDX, 0},
		{CHAR_SONARS_IDX,0}
};

static nrf_drv_rng_config_t		m_drv_rng_config = NRF_DRV_RNG_DEFAULT_CONFIG;



// We have 2 sonars and the time spacing needs to be 60ms per one :)
#define SAMPLING_SONARS_INTERVAL		APP_TIMER_TICKS(30, APP_TIMER_PRESCALER) 		/**< Timestamp value increment interval (ticks), 1ms */
#define SAMPLING_VBAT_INTERVAL			APP_TIMER_TICKS(3000, APP_TIMER_PRESCALER) 		/**< VBAT measreument interval 1s */
#define SAMPLING_DEFAULT_INTERVAL 		APP_TIMER_TICKS(100, APP_TIMER_PRESCALER)
#define SAMPLING_IMU_INTERVAL			APP_TIMER_TICKS(100, APP_TIMER_PRESCALER) 		/**< Timestamp value increment interval (ticks), 1ms */
#define KAT_TIMESTAMP_TIMER_INTERVAL	APP_TIMER_TICKS(1, APP_TIMER_PRESCALER) /**< Timestamp value increment interval (ticks), 1ms */

// Global variables for the main program flow
static kat_sensor_3d_data_t 		m_acceleromter_3d_data;
static kat_sensor_3d_data_t 		m_past_acceleromter_3d_data;
static float						m_accelerometer_sensitivity;
//static kat_sensor_3d_data_t 		m_magnetometer_3d_data;
static kat_sensor_3d_data_t			m_orientation_3d_data;			/** < Euler orientation data */
static kat_sensor_3d_data_t			m_past_orientation_3d_data;		/** < Previous orientation data */
static float 						m_orientation_sensitivity;		/** < Sensitivity to determine when to report */
static kat_char_t 					m_kat_characteristics[9];
static uint8_t 						m_kat_characteristics_num 	= sizeof(m_kat_characteristics)/sizeof(kat_char_t);
static volatile uint8_t				m_imu_sampling_busy_flag 	= 0;
static kat_sampling_rate_data_t		m_kat_imu_sampling_rate_data;
static kat_sampling_rate_data_t		m_kat_sonars_sampling_rate_data;
static kat_sensor_2d_data_t 		m_sonars_2d_data;
static kat_sensor_2d_data_t 		m_past_sonars_2d_data;
static float						m_sonars_sensitivity;
kat_feedback_data_t 				m_kat_feedback_buzzer;
kat_feedback_data_t 				m_kat_feedback_vibr;
kat_feedback_data_t 				m_kat_feedback_las_x;
kat_feedback_data_t 				m_kat_feedback_las_y;
hcsr04_t 							m_sonar_x;
hcsr04_t 							m_sonar_y;
volatile uint8_t 					sonars_current_sonar = 1;
static nrf_drv_adc_channel_t 		m_vbat_meas_adc_channel;
volatile uint8_t					m_vbat_current_perc = 1;
const nrf_drv_timer_t timer1 = NRF_DRV_TIMER_INSTANCE(1);

#define TWI_MAX_PENDING_TRANSACTIONS 5
app_twi_t 		m_app_twi 		= APP_TWI_INSTANCE(0);

mpu9250_t 		m_mpu9250;


static void flag_reported_all(uint8_t reported) {
	for(uint8_t i=0; i<sizeof(m_reported_flags)/2; i++) {
			m_reported_flags[i][1] = reported;
	}
}


static void flag_reported(uint8_t char_id, uint8_t reported) {
	for(uint8_t i=0; i<sizeof(m_reported_flags)/2; i++) {
		if( m_reported_flags[i][0] == char_id ) {
			m_reported_flags[i][1] = reported;
			return;
		}
	}
}


static uint8_t is_reported(uint8_t char_id) {
	for(uint8_t i=0; i<sizeof(m_reported_flags)/2; i++) {
		if( m_reported_flags[i][0] == char_id ) {
			return m_reported_flags[i][1];
		}
	}
	return 0;
}



/**@brief Function for assert macro callback.
 *
 * @details This function will be called in case of an assert in the SoftDevice.
 *
 * @warning This handler is an example only and does not fit a final product. You need to analyse 
 *          how your product is supposed to react in case of Assert.
 * @warning On assert from the SoftDevice, the system can only recover on reset.
 *
 * @param[in] line_num    Line number of the failing ASSERT call.
 * @param[in] p_file_name File name of the failing ASSERT call.
 */
void assert_nrf_callback(uint16_t line_num, const uint8_t * p_file_name)
{
    app_error_handler(DEAD_BEEF, line_num, p_file_name);
}


/**@brief Function for the GAP initialization.
 *
 * @details This function will set up all the necessary GAP (Generic Access Profile) parameters of 
 *          the device. It also sets the permissions and appearance.
 */
static void gap_params_init(void)
{
    uint32_t                err_code;
    ble_gap_conn_params_t   gap_conn_params;
    ble_gap_conn_sec_mode_t sec_mode;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);
    
    err_code = sd_ble_gap_device_name_set(&sec_mode,
                                          (const uint8_t *) DEVICE_NAME,
                                          strlen(DEVICE_NAME));
    APP_ERROR_CHECK(err_code);

    memset(&gap_conn_params, 0, sizeof(gap_conn_params));

    // Send generic HID appearance
    err_code = sd_ble_gap_appearance_set(BLE_APPEARANCE_GENERIC_HID);
    APP_ERROR_CHECK(err_code);


    gap_conn_params.min_conn_interval = MIN_CONN_INTERVAL;
    gap_conn_params.max_conn_interval = MAX_CONN_INTERVAL;
    gap_conn_params.slave_latency     = SLAVE_LATENCY;
    gap_conn_params.conn_sup_timeout  = CONN_SUP_TIMEOUT;

    err_code = sd_ble_gap_ppcp_set(&gap_conn_params);
    APP_ERROR_CHECK(err_code);
}





static void kat_data_handler(ble_kat_t * p_kat, uint8_t * p_data, uint16_t length) {
}



static void kat_1ms_timer_timeout_handler(void *p_context) {
	kat_timestamp_increment(&m_kat);
	rtc_timestamp_rtc_int_handler(0);
}


#if USE_IMU==1

/**
 * @brief Initialization of the I2C bus and BNO055 peripheral
 */
#if IMU==055
static void imu_init() {

	bno055_begin(OPERATION_MODE_NDOF);
}
#endif //BNO055





	#if IMU==055
		static bno055_err_t imu_get_vector( kat_sensor_3d_data_t* p_data_3d, adafruit_vector_type_t vector_type ) {
			bno055_err_t ret_code;
			imu_vector_t imu_vect;
			ret_code = bno055_get_vector(vector_type, &imu_vect);
			if(ret_code == BNO055_ERR_OK) {
				p_data_3d->x = imu_vect[0];
				p_data_3d->y = imu_vect[1];
				p_data_3d->z = imu_vect[2];
			}
			return ret_code;
		}
	#endif // BNO055

#endif // USE_IMU==1

#if USE_IMU==1
	#if IMU==055
	static void sampling_accelerometer_task(void* p_event_data, uint16_t event_size) {
		m_imu_sampling_busy_flag = true;
		float magnitude_difference;

		// Get and notify about the accelerometer data
		if(imu_get_vector(&m_acceleromter_3d_data, VECTOR_ACCELEROMETER) == BNO055_ERR_OK) {
			magnitude_difference = kat_data3d_diff_magnitude(&m_past_acceleromter_3d_data, &m_acceleromter_3d_data);
			if(magnitude_difference > m_accelerometer_sensitivity) {
				memcpy( &m_past_acceleromter_3d_data, &m_acceleromter_3d_data, sizeof( kat_sensor_3d_data_t ) );

				kat_char_notify_new_data( &(m_kat_characteristics[CHAR_ACC_IDX]) );
				flag_reported( CHAR_ACC_IDX, 1);
			}
		}

		// Get and notify about the orientation / angle data
		if(imu_get_vector(&m_orientation_3d_data, VECTOR_EULER) == BNO055_ERR_OK) {
			magnitude_difference = kat_data3d_diff_magnitude(&m_orientation_3d_data, &m_past_orientation_3d_data);
			if(magnitude_difference > m_orientation_sensitivity) {
				memcpy( &m_past_orientation_3d_data, &m_orientation_3d_data, sizeof( kat_sensor_3d_data_t ) );
				kat_char_notify_new_data( &(m_kat_characteristics[CHAR_ORIENT_IDX]) );
				flag_reported( CHAR_ORIENT_IDX, 1);
			}
		}

		m_imu_sampling_busy_flag = false;
	}
	#endif // BNO055

	#if IMU==9250


	void eMPL_send_data(mpu9250_t *p_mpu9250, unsigned char type, long *data, unsigned long timestamp) {
	    float magnitude_difference;
	    kat_sensor_3d_data_t *new_data = NULL;
	    kat_sensor_3d_data_t *past_data = NULL;
	    uint8_t notify_char_idx = 0;
	    float sensitivity_threshold = 0;
		float q[4];
	    float scale[3] = {1.0f, 1.0f, 1.0f};

		switch(type) {

			case MPU9250_EMPL_DATA_QUAT:
			case MPU9250_EMPL_DATA_EULER:
				new_data = &m_orientation_3d_data;
				past_data = &m_past_orientation_3d_data;
				notify_char_idx = CHAR_ORIENT_IDX;
				sensitivity_threshold = m_orientation_sensitivity;
			break;

			case MPU9250_EMPL_DATA_ACCEL:
				new_data = &m_acceleromter_3d_data;
				past_data = &m_past_acceleromter_3d_data;
				notify_char_idx = CHAR_ACC_IDX;
				sensitivity_threshold = m_accelerometer_sensitivity;
				scale[0] = 10.0f;
				scale[1] = 10.0f;
				scale[2] = 10.0f;
			break;
		}

		if(new_data == NULL || past_data == NULL) return;
		new_data->timestamp = timestamp;

		if(type == MPU9250_EMPL_DATA_QUAT) {
			q[0] = data[0]*1.0f / (1<<30);
			q[1] = data[1]*1.0f / (1<<30);
			q[2] = data[2]*1.0f / (1<<30);
			q[3] = data[3]*1.0f / (1<<30);

			// quaternion conversion stolen from
			// @see https://www.hackster.io/30503/using-the-mpu9250-to-get-real-time-motion-data-08f011
			new_data->x = atan2( 2.0f*(q[1]*q[2] + q[0]*q[3]), q[0]*q[0] + q[1]*q[1]-q[2]*q[2] -q[3]*q[3] );
			new_data->y = -asin( 2.0f*(q[1]*q[3] - q[0]*q[2]) );
			new_data->z = atan2( 2.0f*(q[0]*q[1] + q[2]*q[3]), q[0]*q[0] - q[1]*q[1] - q[2]*q[2] +q[3]*q[3] );

			// corrections
			new_data->x  *= 180.0f / M_PI;
			new_data->y   *= 180.0f / M_PI;
			new_data->z   *= 180.0f / M_PI;

			// area specific declination - we should not have to care about it
			new_data->y   += 1.34; /* Declination at Potheri, Chennail ,India  Model Used:    IGRF12  */
		}


//		if((type == MPU9250_EMPL_DATA_EULER) || (type==MPU9250_EMPL_DATA_ACCEL)) {
		if(type==MPU9250_EMPL_DATA_ACCEL) {
			new_data->x = data[0]*scale[0] / (1<<16);
			new_data->y = data[1]*scale[1] / (1<<16);
			new_data->z = data[2]*scale[2] / (1<<16);
		}

		magnitude_difference = kat_data3d_diff_magnitude(past_data, new_data);
		if(magnitude_difference > sensitivity_threshold) {
			memcpy( past_data, new_data, sizeof( kat_sensor_3d_data_t ) );
			kat_char_notify_new_data( &(m_kat_characteristics[notify_char_idx]) );
			flag_reported( notify_char_idx, 1);
		}


	}


	static void sampling_imu_task(void* p_event_data, uint16_t event_size) {
		mpu9250_sampling(&m_mpu9250);
	}

	void imu_int_pin_int_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action) {
		app_sched_event_put( NULL,0, sampling_imu_task);
	}

	void imu_init() {
		mpu9250_conf_t mpu9250_conf;
		memset(&mpu9250_conf, 0, sizeof(mpu9250_conf));
		mpu9250_conf.empl_data_handler = eMPL_send_data;
		mpu9250_init(&m_mpu9250, &mpu9250_conf);

	    // After getting IMU ready, let's configure the interrupt pin
	    static nrf_drv_gpiote_in_config_t imu_int_pin_config= GPIOTE_CONFIG_IN_SENSE_LOTOHI(1);
	    nrf_drv_gpiote_in_init(IMU_INT_PIN, &imu_int_pin_config,imu_int_pin_int_handler );
	    nrf_drv_gpiote_in_event_enable(IMU_INT_PIN, 1);
	}



	#endif
#endif // USE_IMU






static void sampling_sonars_timer_handler(void *p_context) {
	if(sonars_current_sonar == 0) {
		hcsr04_trigger(&m_sonar_x);
	} else {
		hcsr04_trigger(&m_sonar_y);
	}
	sonars_current_sonar = (sonars_current_sonar+1)%2;
}


static void feedback_pin_toggle(void *p_pin_number) {
	nrf_gpio_pin_toggle( *((uint8_t*)p_pin_number) );
}

static void sonar_timer_handler(void *p_context) {
	// literally do nothing here
}


// Timer even handler. Not used since timer is used only for PPI.
void timer1_event_handler(nrf_timer_event_t event_type, void * p_context){}


static void minimum_reporting_timer_event_handler(void *p_context) {
	for(uint8_t i=0; i<sizeof(m_reported_flags)/2; i++) {
		// check if reported and report if not
		if( !is_reported(m_reported_flags[i][0]) ) {
			kat_char_notify_new_data( &(m_kat_characteristics[ m_reported_flags[i][0]  ]) );
		}
	}
	flag_reported_all(0);
}



static void vbat_report_task(void* p_event_data, uint16_t event_size) {
	ble_bas_battery_level_update(&m_bas, m_vbat_current_perc);

}

static void vbat_meas_timer_event_handler(void *p_context) {
	nrf_drv_adc_sample_convert(&m_vbat_meas_adc_channel, NULL);
	app_sched_event_put(NULL, 0, vbat_report_task);
}



/**@brief Function for the Timer initialization.
 *
 * @details Initializes the timer module. This creates and starts application timers.
 */
static void timers_init(void)
{
    uint32_t err_code;

    // Now let's use TIMER1 in somewhat raw mode for sonars
    // Configure Timer 1 to overflow every 2 seconds. Check TIMER1 configuration for details
    // The overflow occurs every 0xFFFF/(SysClk/2^PRESCALER).
    // = 65535/31250 = 2.097 sec
    err_code = nrf_drv_timer_init(&timer1, NULL, timer1_event_handler);
    APP_ERROR_CHECK(err_code);
    nrf_drv_timer_enable(&timer1);

    err_code = app_timer_create(&m_kat_1ms_timer_id,
    							APP_TIMER_MODE_REPEATED,
								kat_1ms_timer_timeout_handler);
    APP_ERROR_CHECK(err_code);

    /*
    err_code = app_timer_create(&m_sampling_imu_timer_id,
    							APP_TIMER_MODE_REPEATED,
								sampling_imu_timer_handler);
    APP_ERROR_CHECK(err_code);
*/

    err_code = app_timer_create(&m_sampling_sonars_timer_id,
    							APP_TIMER_MODE_REPEATED,
								sampling_sonars_timer_handler);
    APP_ERROR_CHECK(err_code);


    err_code = app_timer_create(&m_feedback_buzzer_timer_id,
    							APP_TIMER_MODE_REPEATED,
								feedback_pin_toggle);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_create(&m_feedback_vibr_timer_id,
    							APP_TIMER_MODE_REPEATED,
								feedback_pin_toggle);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_create(&m_feedback_las_x_timer_id,
    							APP_TIMER_MODE_REPEATED,
								feedback_pin_toggle);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_create(&m_feedback_las_y_timer_id,
    							APP_TIMER_MODE_REPEATED,
								feedback_pin_toggle);
    APP_ERROR_CHECK(err_code);

    err_code = app_timer_create(&m_hcsr04_timer_id,
    							APP_TIMER_MODE_REPEATED,
								sonar_timer_handler);
    APP_ERROR_CHECK(err_code);


    // Minimum reporting rate timer
    err_code = app_timer_create(&m_minimum_reporting_timer_id,
    							APP_TIMER_MODE_REPEATED,
								minimum_reporting_timer_event_handler);
    APP_ERROR_CHECK(err_code);

    // Battery monitoring timer
    err_code = app_timer_create(&m_vbat_measurement_timer_id,
    							APP_TIMER_MODE_REPEATED,
								vbat_meas_timer_event_handler);
    APP_ERROR_CHECK(err_code);

}

static void app_timers_start() {
	uint32_t err_code;
	/**@brief STarting the note generation timer */
//	err_code = app_timer_start(m_note_gen_timer_id, NOTE_GEN_INTERVAL, NULL);
 //   APP_ERROR_CHECK(err_code);

    /**@brief Starting the timestamp timer */
    err_code = app_timer_start(m_kat_1ms_timer_id,
    			KAT_TIMESTAMP_TIMER_INTERVAL,
				NULL);
    APP_ERROR_CHECK(err_code);


/*
    err_code = app_timer_start(m_sampling_imu_timer_id,
    				SAMPLING_DEFAULT_INTERVAL,
					NULL);
    APP_ERROR_CHECK(err_code);
*/

    err_code = app_timer_start(m_sampling_sonars_timer_id,
    		SAMPLING_SONARS_INTERVAL,
					NULL);
    APP_ERROR_CHECK(err_code);

    // Minimum reporting timer
    err_code = app_timer_start(m_minimum_reporting_timer_id,
    		MINIMUM_REPORTING_DELAY,
					NULL);
    APP_ERROR_CHECK(err_code);

    // Battery monitoring timer
    err_code = app_timer_start(m_vbat_measurement_timer_id,
    		SAMPLING_VBAT_INTERVAL,
					NULL);
    APP_ERROR_CHECK(err_code);

}


/**@todo Check for nulls and do a little bit more robust programming here */
void feedback_value_changed_handler(kat_char_t* p_char, uint8_t * p_data, uint16_t length) {
	kat_feedback_value_t* p_value = (kat_feedback_value_t*)p_data;
	kat_feedback_value_t value;
	uint16_t ticks;

	if(p_char == NULL) return;
	if(p_char->p_feedback_data == NULL) return;
	/**@todo Test it throughrougly */
	if(length != sizeof(kat_feedback_value_t)) return;

	value = *p_value;

	app_timer_stop(p_char->p_feedback_data->timer_id);

	if(value == KAT_FEEDBACK_VALUE_OFF) {
		nrf_gpio_pin_clear(p_char->p_feedback_data->pin);
	} else if(value == KAT_FEEDBACK_VALUE_ON) {
		nrf_gpio_pin_set(p_char->p_feedback_data->pin);
	} else {
		ticks = APP_TIMER_TICKS(500/value, APP_TIMER_PRESCALER);
		// Start with ON and then start the timer, gives better impression on responsiveness but also kinda screws with everythin else
//		nrf_gpio_pin_set(p_char->p_feedback_data->pin);
		app_timer_start(p_char->p_feedback_data->timer_id, ticks, &(p_char->p_feedback_data->pin));
	}
}


void sampling_rate_changed_handler(kat_char_t* p_char, uint8_t * p_data, uint16_t length) {
	uint32_t err_code;
	kat_sampling_rate_t* p_new_sampling_rate;
	uint16_t ticks;

	if(p_char == NULL) return;
	if(p_char->char_type != KAT_CHAR_TYPE_SENSORS_SAMPLING_RATE) return;
	if(p_char->p_sampling_rate_data == NULL) return;


	p_new_sampling_rate = (kat_sampling_rate_t*)p_data;
	ticks = APP_TIMER_TICKS(500/(*p_new_sampling_rate), APP_TIMER_PRESCALER);



	err_code = app_timer_stop( p_char->p_sampling_rate_data->timer_id );
	APP_ERROR_CHECK(err_code);

	err_code = app_timer_start( p_char->p_sampling_rate_data->timer_id,
					ticks,
					NULL);
	APP_ERROR_CHECK(err_code);
}


void ble_bas_evt_handler (ble_bas_t * p_bas, ble_bas_evt_t * p_evt) {
	ble_bas_battery_level_update( p_bas, m_vbat_current_perc );
}

/**@brief Function for initializing services that will be used by the application.
 */
static void services_init(void)
{
    uint32_t       	err_code;
    ble_dis_init_t 	dis_init;
    ble_kat_init_t	kat_init;
    ble_bas_init_t	bas_init;

    /** @brief Initialize the sampling rate structures */
    m_kat_imu_sampling_rate_data.busy_flag = 0;
    m_kat_imu_sampling_rate_data.sampling_rate = 10;
    m_kat_imu_sampling_rate_data.timer_id = m_sampling_imu_timer_id;

    m_kat_sonars_sampling_rate_data.busy_flag = 0;
    m_kat_sonars_sampling_rate_data.sampling_rate = 10;
    m_kat_sonars_sampling_rate_data.timer_id = m_sampling_sonars_timer_id;

    /** @brief Initialize the feedbacks */
    kat_feedback_data_init(&m_kat_feedback_buzzer, BUZZER_PIN, m_feedback_buzzer_timer_id);
    kat_feedback_data_init(&m_kat_feedback_vibr, MOTOR_PIN, m_feedback_vibr_timer_id);
    kat_feedback_data_init(&m_kat_feedback_las_x, LAS_X_PIN, m_feedback_las_x_timer_id);
    kat_feedback_data_init(&m_kat_feedback_las_y, LAS_Y_PIN, m_feedback_las_y_timer_id);


    /** @brief Add characteristics */
    memset( &m_kat_characteristics, 0, sizeof(m_kat_characteristics) );


    kat_char_init_sensor_3d(&m_kat_characteristics[CHAR_ACC_IDX], "ACC", KAT_CHAR_UUID_MINOR_ACC, 			&m_acceleromter_3d_data);
//    kat_char_init_sensor_3d(&m_kat_characteristics[CHAR_MAG_IDX], "MAG", KAT_CHAR_UUID_MINOR_MAGNETOMETER, &m_magnetometer_3d_data);
    kat_char_init_sensor_3d(&m_kat_characteristics[CHAR_ORIENT_IDX], "ORI", KAT_CHAR_UUID_MINOR_ORIENTATION, &m_orientation_3d_data);
    kat_char_init_sampling_rate(&m_kat_characteristics[CHAR_IMU_SAMPLING_RATE_IDX], "IMU_SAMPLING_RATE", KAT_CHAR_UUID_MINOR_IMU_SAMPLING_RATE, &m_kat_imu_sampling_rate_data, sampling_rate_changed_handler);
    kat_char_init_feedback(&m_kat_characteristics[CHAR_BUZZ_FEEDBACK_IDX], "BUZZ", KAT_CHAR_UUID_MINOR_BUZZER, &m_kat_feedback_buzzer, feedback_value_changed_handler);
    kat_char_init_feedback(&m_kat_characteristics[CHAR_VIBR_FEEDBACK_IDX], "VIBR", KAT_CHAR_UUID_MINOR_VIBR, &m_kat_feedback_vibr, feedback_value_changed_handler);
    kat_char_init_feedback(&m_kat_characteristics[CHAR_LASX_FEEDBACK_IDX], "LASX", KAT_CHAR_UUID_MINOR_LASX, &m_kat_feedback_las_x, feedback_value_changed_handler);
    kat_char_init_feedback(&m_kat_characteristics[CHAR_LASY_FEEDBACK_IDX], "LASY", KAT_CHAR_UUID_MINOR_LASY, &m_kat_feedback_las_y, feedback_value_changed_handler);
    kat_char_init_sampling_rate(&m_kat_characteristics[CHAR_SONARS_SAMPLING_RATE_IDX], "SONARS_SAMPLING_RATE", KAT_CHAR_UUID_MINOR_SONARS_SAMPLING_RATE, &m_kat_sonars_sampling_rate_data, sampling_rate_changed_handler);
    kat_char_init_sensor_2d(&m_kat_characteristics[CHAR_SONARS_IDX], "SONARS", KAT_CHAR_UUID_MINOR_SONARS, &m_sonars_2d_data);


    /**@brief Initialize the kat service */
    memset(&kat_init, 0, sizeof(kat_init));
    kat_init.data_handler 	= kat_data_handler;
    kat_init.p_characteristics = m_kat_characteristics;
    kat_init.characteristics_num = m_kat_characteristics_num;
    err_code = ble_kat_init(&m_kat, &kat_init);
    APP_ERROR_CHECK(err_code);

    /** @brief Initialize Device Information Service. */
    memset(&dis_init, 0, sizeof(dis_init));
    ble_srv_ascii_to_utf8(&dis_init.manufact_name_str, (char *)MANUFACTURER_NAME);
    ble_srv_ascii_to_utf8(&dis_init.model_num_str, (char *)MODEL_NUMBER);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&dis_init.dis_attr_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_NO_ACCESS(&dis_init.dis_attr_md.write_perm);
    err_code = ble_dis_init(&dis_init);
    APP_ERROR_CHECK(err_code);

    /** @brief Initialize Battery Information Service */
    memset(&bas_init, 0, sizeof(bas_init));
    // Here the sec level for the Battery Service can be changed/increased.
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&bas_init.battery_level_char_attr_md.cccd_write_perm);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&bas_init.battery_level_char_attr_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_NO_ACCESS(&bas_init.battery_level_char_attr_md.write_perm);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&bas_init.battery_level_report_read_perm);

    bas_init.evt_handler          = ble_bas_evt_handler;
    bas_init.support_notification = true;
    bas_init.p_report_ref         = NULL;
    bas_init.initial_batt_level   = 100;

    err_code = ble_bas_init(&m_bas, &bas_init);
    APP_ERROR_CHECK(err_code);

}


/**@brief Function for handling an event from the Connection Parameters Module.
 *
 * @details This function will be called for all events in the Connection Parameters Module
 *          which are passed to the application.
 *
 * @note All this function does is to disconnect. This could have been done by simply setting
 *       the disconnect_on_fail config parameter, but instead we use the event handler
 *       mechanism to demonstrate its use.
 *
 * @param[in] p_evt  Event received from the Connection Parameters Module.
 */
static void on_conn_params_evt(ble_conn_params_evt_t * p_evt)
{
    uint32_t err_code;
    
    if(p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED)
    {
        err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
        APP_ERROR_CHECK(err_code);
    }
}


/**@brief Function for handling errors from the Connection Parameters module.
 *
 * @param[in] nrf_error  Error code containing information about what went wrong.
 */
static void conn_params_error_handler(uint32_t nrf_error)
{
    APP_ERROR_HANDLER(nrf_error);
}


/**@brief Function for initializing the Connection Parameters module.
 */
static void conn_params_init(void)
{
    uint32_t               err_code;
    ble_conn_params_init_t cp_init;
    
    memset(&cp_init, 0, sizeof(cp_init));

    cp_init.p_conn_params                  = NULL;
    cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;
    cp_init.next_conn_params_update_delay  = NEXT_CONN_PARAMS_UPDATE_DELAY;
    cp_init.max_conn_params_update_count   = MAX_CONN_PARAMS_UPDATE_COUNT;
    cp_init.start_on_notify_cccd_handle    = BLE_GATT_HANDLE_INVALID;
    cp_init.disconnect_on_fail             = false;
    cp_init.evt_handler                    = on_conn_params_evt;
    cp_init.error_handler                  = conn_params_error_handler;
    
    err_code = ble_conn_params_init(&cp_init);
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for putting the chip into sleep mode.
 *
 * @note This function will not return.
 */
static void sleep_mode_enter(void)
{
    uint32_t err_code = bsp_indication_set(BSP_INDICATE_IDLE);
    APP_ERROR_CHECK(err_code);

    // Prepare wakeup buttons.
    err_code = bsp_btn_ble_sleep_mode_prepare();
    APP_ERROR_CHECK(err_code);

    // Go to system-off mode (this function will not return; wakeup will cause a reset).
    err_code = sd_power_system_off();
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for handling advertising events.
 *
 * @details This function will be called for advertising events which are passed to the application.
 *
 * @param[in] ble_adv_evt  Advertising event.
 */
static void on_adv_evt(ble_adv_evt_t ble_adv_evt)
{
    uint32_t err_code;

    switch (ble_adv_evt)
    {
        case BLE_ADV_EVT_FAST:
            err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING);
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_ADV_EVT_IDLE:
            sleep_mode_enter();
            break;

        default:
            break;
    }
}

/**@brief Function for the Event Scheduler initialization.
 */
static void scheduler_init(void) {
    APP_SCHED_INIT(SCHED_MAX_EVENT_DATA_SIZE, SCHED_QUEUE_SIZE);
}



/**@brief Function for the application's SoftDevice event handler.
 *
 * @param[in] p_ble_evt SoftDevice event.
 */
static void on_ble_evt(ble_evt_t * p_ble_evt)
{
    uint32_t                         err_code;
    
    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_CONNECTED:
            err_code = bsp_indication_set(BSP_INDICATE_CONNECTED);
            APP_ERROR_CHECK(err_code);
            m_conn_handle = p_ble_evt->evt.gap_evt.conn_handle;
            break;
            
        case BLE_GAP_EVT_DISCONNECTED:
            err_code = bsp_indication_set(BSP_INDICATE_IDLE);
            APP_ERROR_CHECK(err_code);
            m_conn_handle = BLE_CONN_HANDLE_INVALID;
            break;

        case BLE_GAP_EVT_SEC_PARAMS_REQUEST:
            // Pairing not supported
            err_code = sd_ble_gap_sec_params_reply(m_conn_handle, BLE_GAP_SEC_STATUS_PAIRING_NOT_SUPP, NULL, NULL);
            APP_ERROR_CHECK(err_code);
            break;



            /*
        case BLE_GATTS_EVT_SYS_ATTR_MISSING:
            // No system attributes have been stored.
            err_code = sd_ble_gatts_sys_attr_set(m_conn_handle, NULL, 0, 0);
            APP_ERROR_CHECK(err_code);
            break;
*/

        default:
            // No implementation needed.
            break;
    }
}


/**@brief Function for dispatching a SoftDevice event to all modules with a SoftDevice 
 *        event handler.
 *
 * @details This function is called from the SoftDevice event interrupt handler after a 
 *          SoftDevice event has been received.
 *
 * @param[in] p_ble_evt  SoftDevice event.
 */
static void ble_evt_dispatch(ble_evt_t * p_ble_evt)
{
    ble_conn_params_on_ble_evt(p_ble_evt);
    on_ble_evt(p_ble_evt);
    ble_bas_on_ble_evt(&m_bas, p_ble_evt);
    ble_kat_on_ble_event(&m_kat, p_ble_evt);
    ble_advertising_on_ble_evt(p_ble_evt);
    bsp_btn_ble_on_ble_evt(p_ble_evt);
    
}


/**@brief Function for the SoftDevice initialization.
 *
 * @details This function initializes the SoftDevice and the BLE event interrupt.
 */
static void ble_stack_init(void)
{
    uint32_t err_code;
    
    nrf_clock_lf_cfg_t clock_lf_cfg = NRF_CLOCK_LFCLKSRC;
    
    // Initialize SoftDevice.
    SOFTDEVICE_HANDLER_INIT(&clock_lf_cfg, NULL);
    
    ble_enable_params_t ble_enable_params;
    err_code = softdevice_enable_get_default_config(CENTRAL_LINK_COUNT,
                                                    PERIPHERAL_LINK_COUNT,
                                                    &ble_enable_params);
    APP_ERROR_CHECK(err_code);

    /**@todo Find a nicer way of setting the number of long uuids count */
    ble_enable_params.common_enable_params.vs_uuid_count = 4;

    //Check the ram settings against the used number of links
    CHECK_RAM_START_ADDR(CENTRAL_LINK_COUNT,PERIPHERAL_LINK_COUNT);
    // Enable BLE stack.
    err_code = softdevice_enable(&ble_enable_params);
    APP_ERROR_CHECK(err_code);
    
    // Subscribe for BLE events.
    err_code = softdevice_ble_evt_handler_set(ble_evt_dispatch);
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for handling events from the BSP module.
 *
 * @param[in]   event   Event generated by button press.
 */
void bsp_event_handler(bsp_event_t event)
{
    uint32_t err_code;
    switch (event)
    {
        case BSP_EVENT_SLEEP:
            sleep_mode_enter();
            break;

        case BSP_EVENT_DISCONNECT:
            err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            if (err_code != NRF_ERROR_INVALID_STATE)
            {
                APP_ERROR_CHECK(err_code);
            }
            break;

        case BSP_EVENT_WHITELIST_OFF:
            err_code = ble_advertising_restart_without_whitelist();
            if (err_code != NRF_ERROR_INVALID_STATE)
            {
                APP_ERROR_CHECK(err_code);
            }
            break;

        default:
            break;
    }
}




/**@brief Function for initializing the Advertising functionality.
 */
static void advertising_init(void)
{
    uint32_t      err_code;
    ble_advdata_t advdata;
    ble_advdata_t scanrsp;

    // Build advertising data struct to pass into @ref ble_advertising_init.
    memset(&advdata, 0, sizeof(advdata));
    advdata.name_type          = BLE_ADVDATA_FULL_NAME;
    advdata.include_appearance = true;
    advdata.flags              = BLE_GAP_ADV_FLAGS_LE_ONLY_LIMITED_DISC_MODE;

    memset(&scanrsp, 0, sizeof(scanrsp));
    scanrsp.uuids_complete.uuid_cnt = sizeof(m_adv_uuids) / sizeof(m_adv_uuids[0]);
    scanrsp.uuids_complete.p_uuids  = m_adv_uuids;

    ble_adv_modes_config_t options = {0};
    options.ble_adv_fast_enabled  = BLE_ADV_FAST_ENABLED;
    options.ble_adv_fast_interval = APP_ADV_INTERVAL;
    options.ble_adv_fast_timeout  = APP_ADV_TIMEOUT_IN_SECONDS;

    err_code = ble_advertising_init(&advdata, &scanrsp, &options, on_adv_evt, NULL);
    APP_ERROR_CHECK(err_code);
}

static void my_event_handler(void * p_event_data, uint16_t event_size) {
}

static void button_event_handler(uint8_t pin_no, uint8_t button_action) {
	uint32_t err_code = 0;

	// Create an event
	uint8_t event_data = 0x33;
	err_code = app_sched_event_put(&event_data, sizeof(event_data), my_event_handler);
	APP_ERROR_CHECK(err_code);

}

/**@brief Function for initializing buttons and leds.
 *
 * @param[out] p_erase_bonds  Will be true if the clear bonding button was pressed to wake the application up.
 */
static void buttons_leds_init(bool * p_erase_bonds)
{
    bsp_event_t startup_event;
//    app_button_cfg_t app_button_cfg;

    uint32_t err_code = bsp_init(BSP_INIT_NONE ,
                                 APP_TIMER_TICKS(100, APP_TIMER_PRESCALER), 
                                 bsp_event_handler);
    APP_ERROR_CHECK(err_code);


    // Initialize my button
    //The array must be static because a pointer to it will be saved in the button handler module.
    static app_button_cfg_t buttons[] =
    {
        {16, false, BUTTON_PULL, button_event_handler},
        {17, false, BUTTON_PULL, button_event_handler},
    };

    err_code = app_button_init(buttons, sizeof(buttons) / sizeof(buttons[0]),
                               BUTTON_DETECTION_DELAY);
    APP_ERROR_CHECK(err_code);

    // Enable buttons
    err_code = app_button_enable();
    APP_ERROR_CHECK(err_code);

    err_code = bsp_btn_ble_init(NULL, &startup_event);
    APP_ERROR_CHECK(err_code);

    *p_erase_bonds = (startup_event == BSP_EVENT_CLEAR_BONDING_DATA);
}


/**@brief Function for placing the application in low power state while waiting for events.
 */
static void power_manage(void)
{
    uint32_t err_code = sd_app_evt_wait();
    APP_ERROR_CHECK(err_code);
}



/**@todo This is a hack introduced because of the undefined reference error during the compilation */
static uint32_t app_sched_event_handler(app_timer_timeout_handler_t timeout_handler, void* p_context) {
	timeout_handler(p_context);
	return 0;
}

static void rng_init() {
	ret_code_t err_code;
	err_code = nrf_drv_rng_init(&m_drv_rng_config);
	APP_ERROR_CHECK(err_code);
}

void sonar_measurement_callback(hcsr04_t* p_hcsr04, float dist_cm) {
	float magnitude_difference = 0;
	kat_sensor_2d_data_t* p_2d_data;
	p_2d_data = m_kat_characteristics[CHAR_SONARS_IDX].p_sensor_2d_data;
	switch(p_hcsr04->id) {
		case 0:
			p_2d_data->x = dist_cm;
		break;

		case 1:
			p_2d_data->y = dist_cm;
		break;
	}


	magnitude_difference = kat_data2d_diff_magnitude(&m_past_sonars_2d_data, p_2d_data);
	// Get and notify about the sonars data
		if(magnitude_difference > m_sonars_sensitivity) {
			memcpy( &m_past_sonars_2d_data, &p_2d_data, sizeof( kat_sensor_2d_data_t ) );
			kat_char_notify_new_data( &(m_kat_characteristics[CHAR_SONARS_IDX]) );
			flag_reported(CHAR_SONARS_IDX, 1);
		}
}

static void sonars_init() {
    nrf_drv_timer_init(&timer1, NULL, timer1_event_handler);
    nrf_drv_gpiote_init();

    hcsr04_init(
    		&m_sonar_x,
			0,
			&timer1,
			SONAR_X_TRIG_PIN,
			SONAR_X_ECHO_PIN,
			sonar_measurement_callback);


    hcsr04_init(
    		&m_sonar_y,
			1,
			&timer1,
			SONAR_Y_TRIG_PIN,
			SONAR_Y_ECHO_PIN,
			sonar_measurement_callback);
}


void data_init() {
	kat_sensor_3d_data_init(&m_past_acceleromter_3d_data);
	kat_sensor_3d_data_init(&m_past_orientation_3d_data);
	kat_sensor_2d_data_init(&m_past_sonars_2d_data);

	m_accelerometer_sensitivity = 0.1f;		/** < 0.1g of sensitivity */
	m_orientation_sensitivity = 0.5f;		/** < 0.5 degree of sensitivity */
	m_sonars_sensitivity = 10.0f;			/** < 1mm of sensitivity */

}


static void startup_routine() {
    // Configure LED-pins as outputs.
	nrf_gpio_cfg_output(BUZZER_PIN);
	nrf_gpio_cfg_output(LED_PIN);
	nrf_gpio_cfg_output(LAS_X_PIN);
	nrf_gpio_cfg_output(LAS_Y_PIN);
	nrf_gpio_cfg_output(MOTOR_PIN);

	nrf_gpio_pin_write(BUZZER_PIN, 0);
	nrf_gpio_pin_write(LED_PIN, 0);
	nrf_gpio_pin_write(LAS_X_PIN, 0);
	nrf_gpio_pin_write(LAS_Y_PIN, 0);
	nrf_gpio_pin_write(MOTOR_PIN, 0);


	// A little bit time to wait for the power to rach all peripherals
	nrf_delay_ms(500);


	nrf_gpio_pin_write(BUZZER_PIN, 1);
	nrf_gpio_pin_write(LED_PIN, 1);
	nrf_gpio_pin_write(LAS_X_PIN, 1);
	nrf_gpio_pin_write(LAS_Y_PIN, 1);
	nrf_gpio_pin_write(MOTOR_PIN, 1);
	nrf_delay_ms(50);
	nrf_gpio_pin_write(BUZZER_PIN, 0);
	nrf_gpio_pin_write(LED_PIN, 0);
	nrf_gpio_pin_write(LAS_X_PIN, 0);
	nrf_gpio_pin_write(LAS_Y_PIN, 0);
	nrf_gpio_pin_write(MOTOR_PIN, 0);
	nrf_delay_ms(500);
}


void nrf_drv_adc_event_handler(nrf_drv_adc_evt_t const * p_event) {
	if(p_event->type != NRF_DRV_ADC_EVT_SAMPLE) return;
	m_vbat_current_perc = vbat_convert_percentage(p_event->data.sample.sample);
}

static void vbat_meas_init() {
	ret_code_t ret_code;

	// Intialize ADC overall
	nrf_drv_adc_config_t nrf_drv_adc_config = NRF_DRV_ADC_DEFAULT_CONFIG;
	ret_code = nrf_drv_adc_init(&nrf_drv_adc_config, nrf_drv_adc_event_handler);
	APP_ERROR_CHECK(ret_code);

	memset(&m_vbat_meas_adc_channel, 0, sizeof(m_vbat_meas_adc_channel));
	m_vbat_meas_adc_channel.config.config.ain 			= nrf_drv_adc_gpio_to_ain(VBAT_MEAS_PIN);
	m_vbat_meas_adc_channel.config.config.resolution 	= VBAT_ADC_RESOLUTION;
	m_vbat_meas_adc_channel.config.config.input 		= VBAT_ADC_SCALING; //1/3
	m_vbat_meas_adc_channel.config.config.reference    	= VBAT_ADC_REFERENCE; // internal 1.2 V reference

	nrf_drv_adc_channel_enable(&m_vbat_meas_adc_channel);
}


static void i2c_twi_init() {
	ret_code_t err_code;
	//i2c_init(&m_i2c, &m_twi, I2C_SCL_PIN, I2C_SDA_PIN, NRF_TWI_FREQ_100K);
	nrf_drv_twi_config_t const twi_config = {
		   .scl                = TWI_SCL_PIN,
		   .sda                = TWI_SDA_PIN,
		   .frequency          = TWI_FREQUENCY_FREQUENCY_K400,
		   .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
		};

		APP_TWI_INIT(&m_app_twi, &twi_config, TWI_MAX_PENDING_TRANSACTIONS, err_code);
		APP_ERROR_CHECK(err_code);

	i2c_set_app_twi(&m_app_twi);
}





/**@brief Application main function.
 */
int main(void)
{
    uint32_t 	err_code;
    bool 		erase_bonds;

    startup_routine();

    data_init();
    flag_reported_all(0);



    // Initialize.
    APP_TIMER_INIT(APP_TIMER_PRESCALER, APP_TIMER_OP_QUEUE_SIZE, app_sched_event_handler);

    scheduler_init();
    timers_init();
    buttons_leds_init(&erase_bonds);
    ble_stack_init();
    gap_params_init();
    services_init();
    advertising_init();
    conn_params_init();
    rng_init();

    i2c_twi_init();
    imu_init();
    vbat_meas_init();
    sonars_init();


	app_timers_start();

    err_code = ble_advertising_start(BLE_ADV_MODE_FAST);
    APP_ERROR_CHECK(err_code);

    // Enter main loop.
    for (;;)
    {
    	app_sched_execute();
        power_manage();
    }

    return 0;
}


/** 
 * @}
 */
