#include "bno055.h"
#include "i2c.h"
#include <stdint.h>
#include <stdbool.h>
#include <nrf_delay.h>
#include <string.h>


adafruit_bno055_opmode_t current_mode = -1;

void delay(uint16_t ms) {

	nrf_delay_ms(ms);
}


void write8(uint8_t address, uint8_t value) {
	i2c_write8(BNO055_ADDRESS_A, address, value);
}

uint8_t read8(uint8_t address) {
	return i2c_read8(BNO055_ADDRESS_A, address);
}

void setMode(adafruit_bno055_opmode_t new_mode) {
	current_mode = new_mode;
	write8(BNO055_OPR_MODE_ADDR, current_mode);
	delay(30);
}


void readLen( uint8_t address, uint8_t *buffer, uint8_t len ) {
	i2c_read_many(BNO055_ADDRESS_A, address, buffer, len);
}

bno055_err_t bno055_get_vector(adafruit_vector_type_t vector_type, imu_vector_t *xyz) {
	uint8_t buffer[6];
	int16_t x,y,z;
	float scale = 1.0f;
	x=y=z=0;				// oh?
	memset(buffer, 0, sizeof(buffer));
	memset(xyz, 0, sizeof(imu_vector_t));

	readLen((adafruit_bno055_reg_t)vector_type, buffer, 6);


	x = ((int16_t)buffer[0]) | (((int16_t)buffer[1]) << 8);
	y = ((int16_t)buffer[2]) | (((int16_t)buffer[3]) << 8);
	z = ((int16_t)buffer[4]) | (((int16_t)buffer[5]) << 8);


	switch(vector_type) {
		case VECTOR_EULER:   /* 1 degree = 16 LSB */
		case VECTOR_MAGNETOMETER: /* 1uT = 16 LSB */
			scale = 1.0f/16.0f;
			break;
		case VECTOR_GYROSCOPE: /* 1rps = 900 LSB */
			scale = 1.0f/900.0f;
			break;
		case VECTOR_ACCELEROMETER: /* 1m/s^2 = 100 LSB */
		case VECTOR_LINEARACCEL: /* 1m/s^2 = 100 LSB */
		case VECTOR_GRAVITY: /* 1m/s^2 = 100 LSB */
			scale = 1.0f/100.0f;
		break;
	}

	(*xyz)[0] = ((float)x)*scale;
	(*xyz)[1] = ((float)y)*scale;
	(*xyz)[2] = ((float)z)*scale;

	return 0;
}



bno055_err_t bno055_begin(adafruit_bno055_opmode_t mode) {
	uint8_t id = 0;
	bno055_err_t ret_val = BNO055_ERR_OK;

	// Make sure we have the right device present
	id = read8(BNO055_CHIP_ID_ADDR);
	if(id != BNO055_ID) {
		return BNO055_ERR_WRONG_CHIP_ID;
	}

	// Switch to config mode (just in case)
	setMode(OPERATION_MODE_CONFIG);

	// Reset
	write8(BNO055_SYS_TRIGGER_ADDR, 0x20);
	while(1) {
		id = read8(BNO055_CHIP_ID_ADDR);
		if(id==BNO055_ID) {
			break;
		} else {
			delay(500);
		}
	}

	/* Set to normal power mode */
	write8(BNO055_PWR_MODE_ADDR, POWER_MODE_NORMAL);

	write8(BNO055_PAGE_ID_ADDR, 0);

	write8(BNO055_SYS_TRIGGER_ADDR, 0x0);
	delay(10);

	setMode(mode);
	delay(20);

	return ret_val;
}








