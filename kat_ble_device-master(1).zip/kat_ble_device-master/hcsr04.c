#include "hcsr04.h"
#include <nrf_gpio.h>
#include <nrf_error.h>
#include <nrf_drv_gpiote.h>
#include <nrf_drv_ppi.h>
#include <nrf_delay.h>

#include <string.h>

hcsr04_t* p_current_hcsr04 = NULL;

void bubble_sort_float_array(float *array, uint8_t len) {
	float t;
	for(uint8_t i=0; i<len; i++) {
		for(uint8_t j=i+1; j<len; j++) {
			if( array[i] > array[j] ) {
				t = array[j];
				array[j] = array[i];
				array[i ] =t;
			}
		}
	}
}

 void sonar_echo_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action) {

	 if(p_current_hcsr04 == NULL) return;
	uint32_t val = 0;
	val = nrf_drv_timer_capture_get( p_current_hcsr04->p_timer , 0);
	float distance = (float)val/(125.0*0.034*2.0);

	if( distance < HCSR04_DISTANCE_MIN || distance > HCSR04_DISTANCE_MAX) {
		// reject
		return;
	}

	if(HCSR04_MEDIAN_FILTER_LENGTH == 1) {
		// Special case for just one sample
		p_current_hcsr04->p_callback(p_current_hcsr04, distance);
	} else {
		p_current_hcsr04->a_samples[ p_current_hcsr04->sample_idx ] = distance;
		p_current_hcsr04->sample_idx = (p_current_hcsr04->sample_idx+1)%HCSR04_MEDIAN_FILTER_LENGTH;
		bubble_sort_float_array( p_current_hcsr04->a_samples,  HCSR04_MEDIAN_FILTER_LENGTH);
		p_current_hcsr04->p_callback(p_current_hcsr04, p_current_hcsr04->a_samples[HCSR04_MEDIAN_FILTER_LENGTH/2  ] );
	}
 }

void hcsr04_trigger(hcsr04_t* p_hcsr04) {

    nrf_drv_ppi_channel_assign(p_hcsr04->ppi_channel, nrf_drv_gpiote_in_event_addr_get(p_hcsr04->pin_echo), nrf_drv_timer_capture_task_address_get(p_hcsr04->p_timer, 0));
    nrf_drv_ppi_channel_enable(p_hcsr04->ppi_channel);


	// TRIGGER!
    p_current_hcsr04 = p_hcsr04;
	nrf_gpio_pin_set(p_hcsr04->pin_trig);
	nrf_delay_us(10);							// yes, I know it's lame
	nrf_gpio_pin_clear(p_hcsr04->pin_trig);
	nrf_drv_timer_clear(p_hcsr04->p_timer);
	nrf_drv_timer_capture(p_hcsr04->p_timer,0);
}


void hcsr04_init(hcsr04_t* p_hcsr04, uint8_t id, nrf_drv_timer_t const* p_timer, uint8_t pin_trig, uint8_t pin_echo, hcsr04_measurement_callback_t p_callback) {

	memset(p_hcsr04, 0, sizeof(hcsr04_t));

	// Configure pins in/out
    static nrf_drv_gpiote_out_config_t sonar_x_trig_config = GPIOTE_CONFIG_OUT_SIMPLE(0);
    nrf_drv_gpiote_out_init(pin_trig, &sonar_x_trig_config);

    // Configure the events on echo
    static nrf_drv_gpiote_in_config_t sonar_echo_config = GPIOTE_CONFIG_IN_SENSE_HITOLO(1);
    nrf_drv_gpiote_in_init(pin_echo, &sonar_echo_config,sonar_echo_handler );
    nrf_drv_gpiote_in_event_enable(pin_echo, 1);

    // Allocate the PPI channel for events
    uint32_t ppi_channel = 0;
    nrf_ppi_channel_t sonar_echo_ppi_channel;
    ppi_channel = nrf_drv_ppi_channel_alloc(&sonar_echo_ppi_channel);


    p_hcsr04->id 			= id;
    p_hcsr04->pin_echo 		= pin_echo;
    p_hcsr04->p_timer 		= p_timer;
    p_hcsr04->pin_trig 		= pin_trig;
    p_hcsr04->ppi_channel 	= ppi_channel;
    p_hcsr04->p_callback 	= p_callback;

}




# if 0
void new_value(hcsr04_t* p_hcsr04, float dist_mm) {

}


void hcsr04_echo_handler(hcsr04_t* p_hcsr04, uint8_t pin, nrf_gpiote_polarity_t action) {
	uint32_t ticks;
	uint32_t diff;
	float dist;

	if( pin == p_hcsr04->pin_echo ) {

		if(nrf_gpio_pin_read(pin)) {
			// T0
			//p_hcsr04->t0 = ticks;
		} else {
			// ONLY if fired on this sensor
			if(!p_hcsr04->fired) return;

			// T1
			if(app_timer_cnt_get(&ticks) != NRF_SUCCESS) return;
			p_hcsr04->t1 = ticks;
			if(app_timer_cnt_diff_compute(p_hcsr04->t1, p_hcsr04->t0, &diff) != NRF_SUCCESS) return;

			dist = 4.6f*(float)diff;
			if(p_hcsr04->measurement_callback != NULL) p_hcsr04->measurement_callback(p_hcsr04, dist);

			// Mark that we are free to fire again
			p_hcsr04->fired =0;
		}
	}
}


void hcsr04_trigger(hcsr04_t* p_hcsr04) {
	uint32_t ticks;

	nrf_gpio_pin_set(p_hcsr04->pin_trig);
	nrf_gpio_pin_clear(p_hcsr04->pin_trig);
	p_hcsr04->fired = 1;
	if(app_timer_cnt_get(&ticks) != NRF_SUCCESS) return;
	p_hcsr04->t0 = ticks;

}




ret_code_t hcsr04_init(
		hcsr04_t* 						p_hcsr04,
		uint8_t 						pin_trig,
		uint8_t 						pin_echo,
		app_timer_id_t					timer_id,
		hcsr04_echo_toggle_handler_t	echo_toggle_handler,
		hcsr04_measurement_callback		measurement_callback) {

	ret_code_t err_code = NRF_SUCCESS;

	// Simple assignment
	p_hcsr04->pin_echo 				= pin_echo;
	p_hcsr04->pin_trig 				= pin_trig;
	p_hcsr04->echo_toggle_handler	= echo_toggle_handler;
	p_hcsr04->timer_id				= timer_id;
	p_hcsr04->measurement_callback	= measurement_callback;

	// In-direct assignments
	p_hcsr04->busy_flag				= 0;


	nrf_gpio_cfg_output(p_hcsr04->pin_trig);

	err_code = nrf_drv_ppi_channel_alloc( &(p_hcsr04->ppi_channel) );
	if(err_code != NRF_SUCCESS) return err_code;

	nrf_drv_gpiote_in_config_t config = GPIOTE_CONFIG_IN_SENSE_TOGGLE(false);
	err_code = nrf_drv_gpiote_in_init( p_hcsr04->pin_echo , &config, echo_toggle_handler);
	if(err_code != NRF_SUCCESS) return err_code;

	nrf_drv_gpiote_in_event_enable(p_hcsr04->pin_echo, 1);

/*
	err_code = nrf_drv_timer_init(p_timer, p_timer_config, NULL);
	APP_ERROR_CHECK(err_code);
	nrf_drv_timer_enable(p_timer);
*/

	return err_code;
}

#endif // if0

#if 0
ret_code_t hcsr04_init(hcsr04_t* p_hcsr04) {
	ret_code_t err_code;
	nrf_gpio_cfg_output(p_hcsr04->pin_trig);

	err_code = nrf_drv_ppi_channel_alloc( &(p_hcsr04->ppi_channel) );
	if(err_code != NRF_SUCCESS) return err_code;
/*
		nrf_drv_gpiote_in_config_t config = GPIOTE_CONFIG_IN_SENSE_TOGGLE(false);
		err_code = nrf_drv_gpiote_in_init( p_hcsr04->pin_echo , &config, echo_toggle_handler);
		APP_ERROR_CHECK(err_code);
		nrf_drv_gpiote_in_event_enable(HCSR04_ECHO_PIN, 1);

		err_code = nrf_drv_timer_init(&timer, &timer_config, timer_handler);
		APP_ERROR_CHECK(err_code);
		nrf_drv_timer_enable(&timer);
*/
		return err_code;
}
#endif // if 0





