#ifndef _HAVE_HCSR04_
#define _HAVE_HCSR04_

#include <stdint.h>
#include <nrf_ppi.h>
#include <nrf_drv_gpiote.h>
#include "app_timer.h"
#include <nrf_drv_timer.h>

// Forward declaration
typedef struct hcsr04_s hcsr04_t;

#define HCSR04_MEDIAN_FILTER_LENGTH 5	// number of samples for median filtering

#define HCSR04_DISTANCE_MIN 3.0f
#define HCSR04_DISTANCE_MAX 4000.0f

typedef void (*hcsr04_measurement_callback_t)(hcsr04_t* p_hcsr04, float dist_cm);


struct hcsr04_s {
	uint8_t							id;	// < Id of the sonar
	nrf_drv_timer_t const*			p_timer;	// < The main timer for capturing the echo pulse width
	uint8_t 						pin_trig;
	uint8_t							pin_echo;
	uint32_t						ppi_channel;
	hcsr04_measurement_callback_t	p_callback;
	float							a_samples[HCSR04_MEDIAN_FILTER_LENGTH];
	uint8_t							sample_idx;	// current index in the data array
};

void hcsr04_init(hcsr04_t* p_hcsr04, uint8_t id, nrf_drv_timer_t const* p_timer, uint8_t pin_trig, uint8_t pin_echo, hcsr04_measurement_callback_t p_callback );


void hcsr04_trigger(hcsr04_t* p_hcsr04);

#if 0

typedef void (*hcsr04_echo_toggle_handler_t)(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action);

typedef void (*hcsr04_measurement_callback)(hcsr04_t* p_hcsr04, float dist_mm);


struct hcsr04_s{
	uint8_t							pin_trig;
	uint8_t 						pin_echo;
	uint32_t 						t0;
	uint32_t 						t1;
	uint8_t							fired;
	float 							dist;
	nrf_ppi_channel_t 				ppi_channel;
	hcsr04_echo_toggle_handler_t	echo_toggle_handler;
	app_timer_id_t					timer_id;
	nrf_drv_timer_t*				p_timer;
	nrf_drv_timer_config_t*			p_timer_config;
	uint8_t 						busy_flag;
	hcsr04_measurement_callback		measurement_callback;
};




ret_code_t hcsr04_init(
		hcsr04_t* 						p_hcsr04,
		uint8_t 						pin_trig,
		uint8_t 						pin_echo,
		app_timer_id_t					timer_id,
		hcsr04_echo_toggle_handler_t	echo_toggle_handler,
		hcsr04_measurement_callback		measurement_callback);


/**
 * @brief Function triggering the HCSR04
 * @param[in] p_hcsr04 is pointer to a hcsr04 struct
 */
void hcsr04_trigger(hcsr04_t* p_hcsr04);


void hcsr04_echo_handler(hcsr04_t* p_hcsr04, uint8_t pin, nrf_gpiote_polarity_t action);

#endif // if0





#endif // _HAVE_HCSR04_
