#ifndef _HAVE_KAT_H_
#define _HAVE_KAT_H_

/**@file
 *
 * @defgroup ble_srv_kat KAT BLE Service
 * @{
 * @ingroup  ble_srv_kat
 * @brief    KAT BLE Service implementation.
 *
 * @details KAT BLE is a standard service allowing handheld devices to communicate with the
 * 			KAT unit to retrieve the data and send feedback
 *
 * @note The application must provice 1ms timer calling the @ref kat_timestamp_increment routine to maintain
 * 		proper timestamping of device's events
 * @note The app needs to be initialized such that it allows for allocation of <b>1 new 128-bit UUID</b>
 * @note App also need to advertise the presence of KAT's service UUID set in @ref KAT_SERVICE_UUID_MINOR
 */

#include "ble.h"
#include "ble_srv_common.h"
#include <stdint.h>
#include <stdbool.h>
#include "app_scheduler.h"
#include "app_timer.h"
#include "kat_uuids.h"
#include <math.h>


#define KAT_SERVICE_UUID_MINOR 	0x0000						/**< Minor UUID for the KAT Service 128-bit long UUID (12 and 13 byte) */
#define KAT_SERVICE_UUID_TYPE	BLE_UUID_TYPE_VENDOR_BEGIN	/**< UUID type for the KAT Service (vendor specific, 128-bit long). */

/* Forward declaration of the ble_kat_t type. */
typedef struct ble_kat_s ble_kat_t;
typedef struct kat_char_s kat_char_t;

typedef enum {
	KAT_CHAR_TYPE_FEEDBACK = 1,
	KAT_CHAR_TYPE_SENSORS_DATA_1D,
	KAT_CHAR_TYPE_SENSORS_DATA_2D,
	KAT_CHAR_TYPE_SENSORS_DATA_3D,
	KAT_CHAR_TYPE_SENSORS_SAMPLING_RATE,
}kat_char_type_t;




/**@brief 4-byte integer timestamp to assign for events
 * Such a big value to roughly have unique timestamps for ~50 days :)
 * */
typedef uint32_t kat_timestamp_t;



typedef void (*kat_char_ble_on_write_handler_t) (kat_char_t* p_char, uint8_t * p_data, uint16_t length);

typedef uint8_t kat_char_access_flags_t;

typedef enum {
	KAT_CHAR_ACCESS_FLAG_READ 				= 0x01,
	KAT_CHAR_ACCESS_FLAG_WRITE 				= 0x02,
	KAT_CHAR_ACCESS_FLAG_WRITE_NORESP 		= 0x04,
	KAT_CHAR_ACCESS_FLAG_NOTIFY 			= 0x08,
	KAT_CHAR_ACCESS_FLAG_INDICATE 			= 0x10,
}kat_char_access_flag_t;


typedef uint8_t kat_sampling_rate_t;

typedef void (*kat_char_sampling_rate_changed_handler) (kat_char_t* p_char, kat_sampling_rate_t* p_sampling_rate);


typedef struct {
	kat_timestamp_t		timestamp;
	float 				x;
} kat_sensor_1d_data_t;

typedef struct {
	kat_timestamp_t		timestamp;
	float 				x;
	float 				y;
} kat_sensor_2d_data_t;

typedef struct {
	kat_timestamp_t		timestamp;
	float 				x;
	float 				y;
	float 				z;
} kat_sensor_3d_data_t;

void kat_sensor_3d_data_init(kat_sensor_3d_data_t* p_data_3d);
void kat_sensor_2d_data_init(kat_sensor_2d_data_t* p_data_2d);
void kat_sensor_1d_data_init(kat_sensor_1d_data_t* p_data_1d);


float kat_data3d_diff_magnitude(kat_sensor_3d_data_t* p_s1,  kat_sensor_3d_data_t* p_s2 );
float kat_data2d_diff_magnitude(kat_sensor_2d_data_t* p_s1,  kat_sensor_2d_data_t* p_s2 );
float kat_data1d_diff_magnitude(kat_sensor_1d_data_t* p_s1,  kat_sensor_1d_data_t* p_s2 );


typedef enum {
	KAT_FEEDBACK_VALUE_OFF = 0,
	KAT_FEEDBACK_VALUE_ON = 0xff
}kat_feedback_value_t;

typedef struct {
	uint8_t					pin;
	kat_feedback_value_t	value;
	app_timer_id_t			timer_id;
}kat_feedback_data_t;


typedef struct {
	kat_sampling_rate_t		sampling_rate;
	app_timer_id_t			timer_id;
	uint8_t					busy_flag;
}kat_sampling_rate_data_t;


void kat_feedback_data_init(kat_feedback_data_t* p_feedback, uint8_t pin, app_timer_id_t timer_id);



struct kat_char_s{
	char*									p_name;
	ble_kat_t								*p_kat;
	ble_gatts_char_handles_t 				handles;
	kat_char_uuid_minor_t					uuid_minor;
	kat_char_type_t							char_type;
	uint8_t									initialized_flag;
	kat_timestamp_t 						last_updated;
	uint8_t 								notification_enabled;
	kat_char_access_flags_t					access_flags;
	uint8_t									variable_len;
	uint8_t									len;
	uint8_t									len_max;
	uint8_t*								p_value;						/** < This is the data pointer that will point to one of the data structs  */
	kat_feedback_data_t*					p_feedback_data;				/** < Feedback struct pointer (filled only when type is KAT_CHAR_TYPE_FEEDBACK */
	kat_sensor_1d_data_t*					p_sensor_1d_data;				/** < 1D data struct pointer (filled only when type is KAT_CHAR_TYPE_SENSORS_DATA_1D */
	kat_sensor_2d_data_t*					p_sensor_2d_data;				/** < 2D data struct pointer (filled only when type is KAT_CHAR_TYPE_SENSORS_DATA_1D */
	kat_sensor_3d_data_t*					p_sensor_3d_data;				/** < 3D data struct pointer (filled only when type is KAT_CHAR_TYPE_SENSORS_DATA_1D */
	kat_char_ble_on_write_handler_t			on_write_handler;
	kat_sampling_rate_data_t*				p_sampling_rate_data;
	kat_char_sampling_rate_changed_handler	sampling_rate_changed_handler;
};



void kat_char_init_feedback(
		kat_char_t*							p_char,
		char*								p_name,
		kat_char_uuid_minor_t 				uuid_minor,
		kat_feedback_data_t*				p_feedback_data,
		kat_char_ble_on_write_handler_t 	feedback_value_changed_handler);


/**
 * @brief function to initialize the 3D sensor data characteristic
 * @param[out] p_char			characteristic struct to be intialized
 * @param[in] p_name			ASCII string pointer to the name of characteristic
 * @param[in] uuid_minor		Minor uuid from @ref kat_char_uuid_minor_t
 * @param[in] p_sensor_3d_data	pointer to the pre-allocated 3D sensor data struct
 * @param[in] sampling_rate		sampling rate in Hz
 **/
void kat_char_init_sensor_3d(
		kat_char_t* 			p_char,
		char* 					p_name,
		kat_char_uuid_minor_t 	uuid_minor,
		kat_sensor_3d_data_t* 	p_sensor_3d_data);

/**
 * @brief function to initialize the 2D sensor data characteristic
 * @param[out] p_char			characteristic struct to be intialized
 * @param[in] p_name			ASCII string pointer to the name of characteristic
 * @param[in] uuid_minor		Minor uuid from @ref kat_char_uuid_minor_t
 * @param[in] p_sensor_2d_data	pointer to the pre-allocated 2D sensor data struct
 * @param[in] sampling_rate		sampling rate in Hz
 **/
void kat_char_init_sensor_2d(
		kat_char_t* 			p_char,
		char* 					p_name,
		kat_char_uuid_minor_t 	uuid_minor,
		kat_sensor_2d_data_t* 	p_sensor_2d_data);


void kat_char_init_sampling_rate(
		kat_char_t* 						p_char,
		char*								p_name,
		kat_char_uuid_minor_t 				uuid_minor,
		kat_sampling_rate_data_t*			p_sampling_rate_data,
		kat_char_ble_on_write_handler_t		sampling_rate_changed_handler);

uint32_t kat_char_notify_new_data(kat_char_t* p_characteristic);

/**@brief KAT Ble Service event handler type. */
typedef void (*ble_kat_data_handler_t) (ble_kat_t * p_kat, uint8_t * p_data, uint16_t length);

/**@brief Function called by external 1ms timer routine to icrement the timestamp value */
void kat_timestamp_increment(ble_kat_t *p_kat);

uint32_t kat_notify_new_sensor_values(ble_kat_t* p_kat);

/**
 * @brief BLE Event handler for KAT Service
 * @param[in] p_kat 		is the pointer to the main KAT structure
 * @param[in] p_ble_evt 	is the pointer to the bluetooth event structure
 */
void ble_kat_on_ble_event(ble_kat_t * p_kat, ble_evt_t * p_ble_evt);

/**
 * @brief Main structure holding KAT's parameters, wifi stuff and more
 * @todo Set notification flags for each characteristic
 */
struct ble_kat_s {
    uint8_t                  	uuid_type;               	/**< UUID type for KAT Service Base UUID. */
    uint16_t                 	service_handle;          	/**< Handle of KAT BLE Service (as provided by the SoftDevice). */
    uint16_t                 	conn_handle;             	/**< Handle of the current connection (as provided by the SoftDevice). BLE_CONN_HANDLE_INVALID if not in a connection. */
    ble_kat_data_handler_t   	data_handler;            	/**< Event handler to be called for handling received data. */
    kat_timestamp_t				timestamp;					/**< Time stamp for events */
    kat_char_t*					p_characteristics;			/**< Array of characteristics */
    uint8_t						characteristics_num;		/**< Number of active characteristics */
};

/**@brief KAT BLE Service initialization structure.
 *
 * @details This structure contains the initialization information for the service. The application
 * must fill this structure and pass it to the service using the @ref ble_kat_init function
 */
typedef struct {
	/** @brief Externally-defined data handler for incoming bluetooth data
	 * As it may be shared by multiple applications running in the main app flow
	 */
    ble_kat_data_handler_t 	data_handler;
    kat_char_t*				p_characteristics;
    uint8_t					characteristics_num;
} ble_kat_init_t;


/**@brief Function for initializing the KAT BLE Service.
 *
 * @param[out] 	p_kat   		KAT Ble service structure
 * @param[in] 	p_kat_init  	Information needed to initialize the service.
 *
 * @retval NRF_SUCCESS If the service was successfully initialized. Otherwise, an error code is returned.
 * @retval NRF_ERROR_NULL If either of the pointers p_kat or p_kat_init is NULL.
 */
uint32_t ble_kat_init(ble_kat_t * p_kat, const ble_kat_init_t * p_kat_init);



#endif // _HAVE_KAT_H_
