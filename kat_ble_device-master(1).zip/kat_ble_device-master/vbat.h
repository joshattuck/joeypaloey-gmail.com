#ifndef _VBAT_H_
#define _VBAT_H_

//#include "nrf_adc.h"
#include "nrf_drv_adc.h"

#define VBAT_MODEL_LINEAR 	0
#define VBAT_MODEL_SIGMOID 	1
#define VBAT_MODEL 			VBAT_MODEL_SIGMOID

#define VBAT_ADC_RESOLUTION		NRF_ADC_CONFIG_RES_10BIT
#define VBAT_ADC_REFERENCE		NRF_ADC_CONFIG_REF_VBG
#define VBAT_ADC_SCALING		NRF_ADC_CONFIG_SCALING_INPUT_ONE_THIRD
#define VBAT_ADC_MAX 			554
#define VBAT_MAX 				4.2f
#define VBAT_ADC_MIN			402
#define VBAT_MIN				3.0f
#define VBAT_HALFCAP			3.55f
#define VBAT_SIGMOID_SLOPE		10.0f

typedef nrf_adc_value_t vbat_raw_value_t;

/** Returns voltage in volts */
float vbat_convert_voltage(vbat_raw_value_t raw_value);

/** Returns percentage using linear model */
uint8_t vbat_convert_percentage(vbat_raw_value_t raw_value);

#endif // _VBAT_H_
