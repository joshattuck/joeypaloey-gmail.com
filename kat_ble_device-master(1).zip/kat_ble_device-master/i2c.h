#ifndef _HAVE_I2C_H_
#define _HAVE_I2C_H_

#include "app_twi.h"

void i2c_set_app_twi( app_twi_t* p_app_twi);


// two methods required by the inv_mpu.c


int i2c_write(unsigned char slave_addr, unsigned char reg_addr, unsigned char length, unsigned char const *data);
int i2c_read(unsigned char slave_addr, unsigned char reg_addr, unsigned char length, unsigned char *data);

#endif // _HAVE_I2C_H_
