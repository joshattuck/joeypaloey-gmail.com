#include "i2c.h"
#include "app_error.h"
#include "string.h"

// private:
app_twi_t* p_i2c_app_twi;

/** @brief Set the app_twi instance to use in i2c calls */
void i2c_set_app_twi( app_twi_t* p_app_twi) {
	p_i2c_app_twi = p_app_twi;
}






int i2c_write(unsigned char slave_addr, unsigned char reg_addr, unsigned char length, unsigned char const *data) {
    unsigned char new_data[length + 1];
    memcpy(new_data + 1, data, length);
    new_data[0] = reg_addr;

    app_twi_transfer_t const transfers[] =
    {
        APP_TWI_WRITE(slave_addr, new_data, length + 1, 0)
    };
    //log_i("w%d %d %d %d\n", slave_addr, reg_addr, length, new_data[1]);
    //NRF_LOG_HEXDUMP_INFO(new_data, length + 1);
    //NRF_LOG_PROCESS();

    ret_code_t err_code = app_twi_perform(p_i2c_app_twi, transfers, sizeof(transfers) / sizeof(transfers[0]), NULL);
    if(err_code != NRF_SUCCESS) return -1;

    return 0;
}

int i2c_read(unsigned char slave_addr, unsigned char reg_addr, unsigned char length, unsigned char *data) {
    if (length == 0)
        return NRF_SUCCESS;

    app_twi_transfer_t const transfers[] =
    {
        APP_TWI_WRITE(slave_addr, &reg_addr, 1, APP_TWI_NO_STOP),
        APP_TWI_READ (slave_addr, data, length, 0)
    };

    ret_code_t err_code = app_twi_perform(p_i2c_app_twi, transfers, sizeof(transfers) / sizeof(transfers[0]), NULL);
    if(err_code != NRF_SUCCESS) return -1;

    return 0;
}
