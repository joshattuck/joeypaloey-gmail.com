/*
 * @file
 *
 * @ingroup ble_srv_kat
 */

#include <string.h>
#include <nrf_error.h>
#include <sdk_common.h>
#include <nrf_gpio.h>
#include "kat_uuids.h"
#include "kat.h"
#include "ble_gatts.h"
#include <app_util_platform.h>

//#define KAT_SERVICE_BASE_UUID_REV {{0, 0xC7, 0xC4, 0x4E, 0xE3, 0x6C, 0x51, 0xA7, 0x33, 0x4B, 0xE8, 0xED, 0x5A, 0x0E, 0xB8, 0x03}}

/**
 * @brief Our vendor-specific UUID created arbitrarily
 * @see http://stackoverflow.com/questions/10243769/what-range-of-bluetooth-uuids-can-be-used-for-vendor-defined-profiles
 * Using the pattern presented in the website we have
 *  xx xx xx xx -00 00-10 00-80 00-00 80 5F 9B 34 FB
 */
//#define KAT_SERVICE_BASE_UUID_REV {{0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}}



uint8_t ble_mutex = 0;


void kat_sensor_3d_data_init(kat_sensor_3d_data_t* p_data_3d) {
	p_data_3d->timestamp = 0;
	p_data_3d->x = 0;
	p_data_3d->y = 0;
	p_data_3d->z = 0;
}

void kat_sensor_2d_data_init(kat_sensor_2d_data_t* p_data_2d) {
	p_data_2d->timestamp = 0;
	p_data_2d->x = 0;
	p_data_2d->y = 0;
}

void kat_sensor_1d_data_init(kat_sensor_1d_data_t* p_data_1d) {
	p_data_1d->timestamp = 0;
	p_data_1d->x = 0;
}


float kat_data3d_diff_magnitude(kat_sensor_3d_data_t* p_s1,  kat_sensor_3d_data_t* p_s2 ) {
	double magSquared = (p_s1->x - p_s2->x)*(p_s1->x - p_s2->x) + (p_s1->y - p_s2->y)*(p_s1->y - p_s2->y) + (p_s1->z - p_s2->z)*(p_s1->z - p_s2->z);
	return (float)sqrt(magSquared);
}

float kat_data2d_diff_magnitude(kat_sensor_2d_data_t* p_s1,  kat_sensor_2d_data_t* p_s2 ) {
	double magSquared = (p_s1->x - p_s2->x)*(p_s1->x - p_s2->x) + (p_s1->y - p_s2->y)*(p_s1->y - p_s2->y);
	return (float)sqrt(magSquared);
}

float kat_data1d_diff_magnitude(kat_sensor_1d_data_t* p_s1,  kat_sensor_1d_data_t* p_s2 ) {
	double magSquared = (p_s1->x - p_s2->x)*(p_s1->x - p_s2->x);
	return (float)sqrt(magSquared);
}


void kat_feedback_data_init(kat_feedback_data_t* p_feedback, uint8_t pin, app_timer_id_t timer_id) {
	p_feedback->pin 	= pin;
	p_feedback->timer_id = timer_id;
	p_feedback->value 	= KAT_FEEDBACK_VALUE_OFF;
}



uint32_t kat_char_notify_new_data(kat_char_t* p_characteristic) {
	uint32_t err_code = 0;
	ble_gatts_value_t gatts_value;
	ble_gatts_hvx_params_t hvx_params;
	uint16_t value_len;
	ble_kat_t* p_kat;


	if(p_characteristic == NULL) 			return NRF_ERROR_INVALID_PARAM;
	if(p_characteristic->p_kat == NULL) 	return NRF_ERROR_INVALID_PARAM;

	p_kat = p_characteristic->p_kat;
	// Make sure we are connected
	if (p_kat->conn_handle == BLE_CONN_HANDLE_INVALID) {
		return NRF_ERROR_INVALID_STATE;
	}

	value_len = p_characteristic->len;

	/** @todo Fix the references and data structures such that the characteristics belong to KAT's main struct */
	if(p_characteristic->notification_enabled) {
		// If we need to send notification
		memset(&hvx_params, 0, sizeof(hvx_params));
		hvx_params.handle = p_characteristic->handles.value_handle;
		hvx_params.type   = BLE_GATT_HVX_NOTIFICATION;
		hvx_params.offset = 0;
		hvx_params.p_len  = &value_len;
		hvx_params.p_data =	p_characteristic->p_value;

//		app_util_critical_region_enter(&ble_mutex);
		err_code = sd_ble_gatts_hvx(p_kat->conn_handle, &hvx_params);
//		app_util_critical_region_exit(ble_mutex);


		if(err_code == NRF_SUCCESS) {
		} else if( err_code == NRF_ERROR_INVALID_STATE ||
			err_code == NRF_ERROR_BUSY ||
			err_code == BLE_ERROR_GATTS_SYS_ATTR_MISSING ||
			err_code == BLE_ERROR_NO_TX_PACKETS)
		{
			// updated but not sent
		} else {
		}
	} else {
		// Just change locally for the possible READ, probably never used but... whatevs
		memset(&gatts_value, 0, sizeof(gatts_value));
		gatts_value.len     = value_len;
		gatts_value.offset  = 0;
		gatts_value.p_value = p_characteristic->p_value;	// point to my buffer :)


//		app_util_critical_region_enter(&ble_mutex);
		err_code = sd_ble_gatts_value_set(p_kat->conn_handle, p_characteristic->handles.value_handle, &gatts_value);
//		app_util_critical_region_exit(ble_mutex);

	}
	return err_code;

}


void kat_char_init_feedback(
		kat_char_t*							p_char,
		char*								p_name,
		kat_char_uuid_minor_t 				uuid_minor,
		kat_feedback_data_t*				p_feedback_data,
		kat_char_ble_on_write_handler_t 	feedback_value_changed_handler) {


	// Set everything to zero first
	memset(p_char, 0, sizeof(kat_char_t));

	// Direct parameters assignment
	p_char->p_name 					= p_name;
	p_char->uuid_minor 				= uuid_minor;
	p_char->p_value					= (uint8_t*)(p_feedback_data->value);
	p_char->p_feedback_data			= p_feedback_data;
	p_char->on_write_handler		= feedback_value_changed_handler;

	// In-direct
	p_char->access_flags 	= KAT_CHAR_ACCESS_FLAG_READ | KAT_CHAR_ACCESS_FLAG_WRITE ;
	p_char->char_type 		= KAT_CHAR_TYPE_FEEDBACK;
	p_char->len 			= sizeof(kat_feedback_value_t);
	p_char->len_max			= sizeof(kat_feedback_value_t);
	p_char->variable_len	= 0;

	p_char->initialized_flag = 1;

}

void kat_char_init_sensor_3d(
	kat_char_t* 			p_char,
	char* 					p_name,
	kat_char_uuid_minor_t 	uuid_minor,
	kat_sensor_3d_data_t* 	p_sensor_3d_data) {

	// Set everything to zero first
	memset(p_char, 0, sizeof(kat_char_t));

	// Direct parameters assignment
	p_char->p_name 					= p_name;
	p_char->uuid_minor 				= uuid_minor;
	p_char->p_sensor_3d_data 		= p_sensor_3d_data;
	p_char->p_value					= (uint8_t*)p_sensor_3d_data;

	// In-direct
	p_char->access_flags 	= KAT_CHAR_ACCESS_FLAG_READ | KAT_CHAR_ACCESS_FLAG_NOTIFY;
	p_char->char_type 		= KAT_CHAR_TYPE_SENSORS_DATA_3D;
	p_char->len 			= sizeof(kat_sensor_3d_data_t);
	p_char->len_max			= sizeof(kat_sensor_3d_data_t);
	p_char->variable_len	= 0;

	p_char->initialized_flag = 1;
}


void kat_char_init_sensor_2d(
	kat_char_t* 			p_char,
	char* 					p_name,
	kat_char_uuid_minor_t 	uuid_minor,
	kat_sensor_2d_data_t* 	p_sensor_2d_data) {

	// Set everything to zero first
	memset(p_char, 0, sizeof(kat_char_t));

	// Direct parameters assignment
	p_char->p_name 					= p_name;
	p_char->uuid_minor 				= uuid_minor;
	p_char->p_sensor_2d_data 		= p_sensor_2d_data;
	p_char->p_value					= (uint8_t*)p_sensor_2d_data;

	// In-direct
	p_char->access_flags 	= KAT_CHAR_ACCESS_FLAG_READ | KAT_CHAR_ACCESS_FLAG_NOTIFY;
	p_char->char_type 		= KAT_CHAR_TYPE_SENSORS_DATA_2D;
	p_char->len 			= sizeof(kat_sensor_2d_data_t);
	p_char->len_max			= sizeof(kat_sensor_2d_data_t);
	p_char->variable_len	= 0;

	p_char->initialized_flag = 1;
}



void kat_char_init_sampling_rate(
	kat_char_t*	 							p_char,
	char*									p_name,
	kat_char_uuid_minor_t 					uuid_minor,
	kat_sampling_rate_data_t*				p_sampling_rate_data,
	kat_char_ble_on_write_handler_t 		sampling_rate_changed_handler) {

	// Set everything to zero first
	memset(p_char, 0, sizeof(kat_char_t));

	// Direct parameters assignment
	p_char->p_name 							= p_name;
	p_char->uuid_minor 						= uuid_minor;
	p_char->p_value							= &(p_sampling_rate_data->sampling_rate);
	p_char->p_sampling_rate_data			= p_sampling_rate_data;
	p_char->on_write_handler 				= sampling_rate_changed_handler;

	// In-direct
	p_char->access_flags 	= KAT_CHAR_ACCESS_FLAG_READ | KAT_CHAR_ACCESS_FLAG_WRITE ;
	p_char->char_type 		= KAT_CHAR_TYPE_SENSORS_SAMPLING_RATE;
	p_char->len 			= sizeof(kat_sampling_rate_t);
	p_char->len_max 		= sizeof(kat_sampling_rate_t);
	p_char->variable_len	= 0;

	p_char->initialized_flag = 1;

}






static uint32_t kat_char_add(ble_kat_t * p_kat, const ble_kat_init_t * p_kat_init, kat_char_t *p_char) {
    uint32_t      			err_code;
    ble_gatts_char_md_t 	char_md;
    ble_gatts_attr_md_t 	cccd_md;
    ble_gatts_attr_md_t 	p_user_desc_md;
    ble_gatts_attr_t    	attr_char_value;
    ble_uuid_t          	ble_uuid;
    ble_gatts_attr_md_t 	attr_md;
//    uint8_t 				acc_char_uuid_type_ret 	= 0;


    // Set the pointer to the "parent"
    p_char->p_kat = p_kat;

    // CCCD
    memset(&cccd_md, 0, sizeof(cccd_md));
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&cccd_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&cccd_md.write_perm);
    cccd_md.vloc = BLE_GATTS_VLOC_STACK;

    ble_srv_utf8_str_t description;
    ble_srv_ascii_to_utf8( &description, p_char->p_name);				/**< Convert the ASCII name to UTF-8 */
    memset(&p_user_desc_md, 0, sizeof(ble_gatts_attr_md_t));
    p_user_desc_md.vloc = BLE_GATTS_VLOC_STACK;							/**< Locate on stack */
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&p_user_desc_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_NO_ACCESS(&p_user_desc_md.write_perm);


    /**@brief Set the presentation format to define representation of the data for this characteristic
     * @see https://www.safaribooksonline.com/library/view/getting-started-with/9781491900550/ch04.html
     * @see https://developer.bluetooth.org/gatt/descriptors/Pages/DescriptorViewer.aspx?u=org.bluetooth.descriptor.gatt.characteristic_presentation_format.xml
     */
/*
    ble_gatts_char_pf_t p_char_pf;
    memset(&p_char_pf, 0, sizeof(p_char_pf));
    p_char_pf.exponent = 0;
    p_char_pf.name_space = 1;
    p_char_pf.format  = 20;	// 32-bit float
    p_char_pf.desc = 0;
*/


    // Characteristic METADATA
    memset(&char_md, 0, sizeof(char_md));
    char_md.p_char_user_desc         = description.p_str;
    char_md.char_user_desc_size		= description.length;
    char_md.char_user_desc_max_size = description.length;
//    char_md.p_char_pf                = &p_char_pf;
    char_md.p_char_pf                = NULL;
    char_md.p_user_desc_md           = &p_user_desc_md;
    char_md.p_cccd_md         		 = &cccd_md;
    char_md.p_sccd_md                = NULL;

    // Properties
    char_md.char_props.write         = (p_char->access_flags & KAT_CHAR_ACCESS_FLAG_WRITE)? 		1 : 0;
    char_md.char_props.write_wo_resp = (p_char->access_flags & KAT_CHAR_ACCESS_FLAG_WRITE_NORESP)? 	1 : 0;
    char_md.char_props.notify 		 = (p_char->access_flags & KAT_CHAR_ACCESS_FLAG_NOTIFY)? 		1 : 0;
    char_md.char_props.read 		 = (p_char->access_flags & KAT_CHAR_ACCESS_FLAG_READ)? 			1 : 0;
    char_md.char_props.indicate		 = (p_char->access_flags & KAT_CHAR_ACCESS_FLAG_INDICATE)?		1 : 0;

    ble_uuid.type = p_kat->uuid_type;
    ble_uuid.uuid = p_char->uuid_minor;

    // Set the value attribute's location and permissions
    memset(&attr_md, 0, sizeof(attr_md));
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&attr_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&attr_md.write_perm);
    attr_md.vloc    = BLE_GATTS_VLOC_STACK;
    attr_md.rd_auth = 0;
    attr_md.wr_auth = 0;
    attr_md.vlen    = p_char->variable_len;	/**< Constant length attribute (4 byte float) */

    memset(&attr_char_value, 0, sizeof(attr_char_value));
    attr_char_value.p_uuid    	= &ble_uuid;
    attr_char_value.p_attr_md 	= &attr_md;
    attr_char_value.init_len  	= p_char->len;
    attr_char_value.init_offs 	= 0;
    attr_char_value.max_len   	= p_char->len_max;
    attr_char_value.p_value 	= p_char->p_value;

    err_code = sd_ble_gatts_characteristic_add(p_kat->service_handle,
                                           &char_md,
                                           &attr_char_value,
                                           &p_char->handles);
    VERIFY_SUCCESS(err_code);
    return err_code;
}










uint32_t ble_kat_init(ble_kat_t * p_kat, const ble_kat_init_t * p_kat_init) {
	ble_uuid128_t kat_base_uuid = KAT_SERVICE_BASE_UUID_REV;
    ble_uuid_t    ble_uuid;
	uint32_t err_code;
	uint16_t i;

	VERIFY_PARAM_NOT_NULL(p_kat);
	VERIFY_PARAM_NOT_NULL(p_kat_init);

    // Initialize the service structure.
	memset(p_kat, 0, sizeof(ble_kat_t));
    p_kat->conn_handle             	= BLE_CONN_HANDLE_INVALID;
    p_kat->data_handler            	= p_kat_init->data_handler;

    // Pass the characteristics
    p_kat->characteristics_num 		= p_kat_init->characteristics_num;
    p_kat->p_characteristics		= p_kat_init->p_characteristics;

    // Adding the base service UUID and setting its type in p_kat->uuid_type
    err_code = sd_ble_uuid_vs_add(&kat_base_uuid, &p_kat->uuid_type);
    VERIFY_SUCCESS(err_code);

    /**@todo Fix the explicitly stated 12 and 13 byte of the service UUID */
    ble_uuid.type = p_kat->uuid_type;
    ble_uuid.uuid = KAT_SERVICE_UUID_MINOR;

    // Adding the service to the stack
    err_code = sd_ble_gatts_service_add(BLE_GATTS_SRVC_TYPE_PRIMARY,
                                        &ble_uuid,
                                        &p_kat->service_handle);
    /**@snippet [Adding proprietary Service to S110 SoftDevice] */
    VERIFY_SUCCESS(err_code);


    // Create all characteristics
    for(i=0; i<p_kat->characteristics_num; i++) {

    	if(!p_kat->p_characteristics[i].initialized_flag ) {
    		continue;
    	}

		err_code = kat_char_add( p_kat, p_kat_init, &(p_kat->p_characteristics[i]) );
		if(err_code != NRF_SUCCESS) {
			return err_code;
		}
    }

    return NRF_SUCCESS;
}

/**@todo Enter / exit app's critical section */
void kat_timestamp_increment(ble_kat_t *p_kat) {
	uint8_t 				i;
	kat_char_t*				p_char;
	kat_sensor_3d_data_t*	p_3d_data;
	kat_sensor_2d_data_t*	p_2d_data;
	kat_sensor_1d_data_t*	p_1d_data;

	p_kat->timestamp++;

	// Update it in all characteristics
	for(i=0; i<p_kat->characteristics_num; i++) {
		p_char = &( p_kat->p_characteristics[i] );
		switch(p_char->char_type) {
			case KAT_CHAR_TYPE_SENSORS_DATA_1D:
				p_1d_data = p_char->p_sensor_1d_data;
				p_1d_data->timestamp = p_kat->timestamp;
			break;

			case KAT_CHAR_TYPE_SENSORS_DATA_2D:
				p_2d_data = p_char->p_sensor_2d_data;
				p_2d_data->timestamp = p_kat->timestamp;
			break;

			case KAT_CHAR_TYPE_SENSORS_DATA_3D:
				p_3d_data = p_char->p_sensor_3d_data;
				p_3d_data->timestamp = p_kat->timestamp;
			break;

			default:
				break;
				//continue;
		}
	}
}

/**
 * @brief BLE connection handler
 * @note The function sets the status to connected and also adapts to the requested connection params
 */
static uint32_t kat_on_connect(ble_kat_t * p_kat, ble_evt_t * p_ble_evt) {
    p_kat->conn_handle = p_ble_evt->evt.gap_evt.conn_handle;
    ble_gap_evt_connected_t *p_ble_gap_evt_connected = &p_ble_evt->evt.gap_evt.params.connected;
    ble_gap_conn_params_t *p_ble_gap_conn_params = &p_ble_gap_evt_connected->conn_params;
    return sd_ble_gap_ppcp_set(p_ble_gap_conn_params);
}

static void kat_on_disconnect(ble_kat_t * p_kat, ble_evt_t * p_ble_evt) {
    p_kat->conn_handle = BLE_CONN_HANDLE_INVALID;
}

static uint32_t kat_on_conn_param_update(ble_kat_t *p_kat, ble_evt_t *p_ble_evt) {
	ble_gap_conn_params_t *p_gap_conn_params = &p_ble_evt->evt.gap_evt.params.conn_param_update.conn_params;
    return sd_ble_gap_ppcp_set(p_gap_conn_params);
}


static uint8_t kat_send_zero_payload(ble_kat_t * p_kat, ble_evt_t * p_ble_evt, uint16_t handle) {
	uint8_t err_code = 0;
    ble_gatts_hvx_params_t hvx_params;
    VERIFY_PARAM_NOT_NULL(p_kat);
    VERIFY_PARAM_NOT_NULL(p_ble_evt);
    memset(&hvx_params, 0, sizeof(hvx_params));
    hvx_params.handle = handle;
    hvx_params.p_data = NULL;
    hvx_params.p_len  = 0;
    hvx_params.type   = BLE_GATT_HVX_NOTIFICATION;

//    app_util_critical_region_enter(&ble_mutex);
    err_code = sd_ble_gatts_hvx(p_kat->conn_handle, &hvx_params);
//    app_util_critical_region_exit(ble_mutex);

    return err_code;
}

static void kat_on_write(ble_kat_t * p_kat, ble_evt_t * p_ble_evt) {
	uint16_t 				i;
	kat_char_t*				p_char;
    ble_gatts_evt_write_t* 	p_evt_write = &p_ble_evt->evt.gatts_evt.params.write;

    for(i=0; i<p_kat->characteristics_num; i++) {
    	p_char = &(p_kat->p_characteristics[i]);

    	if(!p_char->initialized_flag) {
    		continue;
    	}

    	// Notification
    	if((p_evt_write->handle  == p_char->handles.cccd_handle)&&(p_evt_write->len == 2)) {
    		if(ble_srv_is_notification_enabled(p_evt_write->data)) {
    			p_char->notification_enabled = 1;
    		} else {
    			p_char->notification_enabled = 0;
    		}
    		kat_send_zero_payload(p_kat, p_ble_evt, p_char->handles.value_handle);
    		break;
    	}

    	// Writing the actual characteristic VALUE
    	if((p_evt_write->handle == p_char->handles.value_handle)&&(p_char->on_write_handler != NULL)) {
    		p_char->on_write_handler( p_char, p_evt_write->data, p_evt_write->len );
    	}
    }

}

void ble_kat_on_ble_event(ble_kat_t * p_kat, ble_evt_t * p_ble_evt)
{
    if ((p_kat == NULL) || (p_ble_evt == NULL))
    {
        return;
    }

    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_CONNECTED:
        	kat_on_connect(p_kat, p_ble_evt);
            break;

        case BLE_GAP_EVT_DISCONNECTED:
            kat_on_disconnect(p_kat, p_ble_evt);
            break;

        case BLE_GATTS_EVT_WRITE:
        	kat_on_write(p_kat, p_ble_evt);
            break;

        case BLE_GAP_EVT_CONN_PARAM_UPDATE:
        	kat_on_conn_param_update(p_kat, p_ble_evt);
        	break;

        default:
            // No implementation needed.
            break;
    }
}


