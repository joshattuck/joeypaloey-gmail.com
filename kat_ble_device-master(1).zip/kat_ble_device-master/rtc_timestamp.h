#ifndef _HAVE_RTC_TIMESTAMP_
#define _HAVE_RTC_TIMESTAMP_

#include <stdint.h>
#include "nrf_drv_rtc.h"


void rtc_timestamp_rtc_int_handler(nrf_drv_rtc_int_type_t int_type) ;
void rtc_timestamp_write_to_unsigned_long_pointer(long unsigned int *timestamp);

#endif
